#!/usr/bin/env python3
"""
Simple Interactive Chat Test for Complete Intelligent Triage Agent System
This script provides a simple way to test the system without Jupyter notebook complications
"""

import sys
import os
import json
sys.path.append('shared')

from complete_system_orchestrator import CompleteSystemOrchestrator

def load_demo_credentials():
    """Load demo user credentials for testing."""
    try:
        with open('shared/fixtures/password_reference.json', 'r') as f:
            return json.load(f)
    except:
        return {}

def display_user_menu():
    """Display available demo users."""
    credentials = load_demo_credentials()
    print("\n👥 Available Demo Users:")
    print("-" * 50)
    for i, (user_id, creds) in enumerate(list(credentials.items())[:10], 1):
        print(f"{i:2d}. {user_id} - {creds.get('username', 'N/A')} ({creds.get('email', 'N/A')})")
    print("-" * 50)

def get_user_input(prompt, default=""):
    """Get user input with optional default value."""
    try:
        if default:
            user_input = input(f"{prompt} [{default}]: ").strip()
            return user_input if user_input else default
        else:
            return input(f"{prompt}: ").strip()
    except (EOFError, KeyboardInterrupt):
        print("\n👋 Goodbye!")
        sys.exit(0)

def display_help():
    """Display help information."""
    print("\n📚 Available Commands:")
    print("  help     - Show this help message")
    print("  quit     - Exit the chat")
    print("  stats    - Show system statistics")
    print("  users    - Show available demo users")
    print("  auth     - Show authentication info")
    print("\n💬 Just type your message to interact with the AI agent!")

def display_auth_info(user_id):
    """Display authentication information for a user."""
    try:
        credentials = load_demo_credentials()
        user_creds = credentials.get(user_id, {})
        
        if user_creds:
            print(f"\n🔐 Authentication Info for {user_id}:")
            print("-" * 40)
            print(f"Username: {user_creds.get('username', 'N/A')}")
            print(f"Email: {user_creds.get('email', 'N/A')}")
            print(f"Password: {user_creds.get('plain_password', 'N/A')}")
        else:
            print(f"❌ No credentials found for user {user_id}")
    except Exception as e:
        print(f"❌ Error getting auth info: {e}")

def interactive_chat():
    """Main interactive chat function."""
    print("🚀 Starting Interactive Chat with Complete Intelligent Triage Agent System")
    print("="*80)
    
    # Initialize the system
    print("🔧 Initializing system...")
    try:
        system = CompleteSystemOrchestrator()
        print("✅ System initialized successfully!")
    except Exception as e:
        print(f"❌ Failed to initialize system: {e}")
        return
    
    # Display available users
    display_user_menu()
    
    # Get user selection
    user_id = get_user_input("\n👤 Enter User ID (or number from list)", "u_1001")
    
    # If user entered a number, get the corresponding user ID
    try:
        user_num = int(user_id)
        credentials = load_demo_credentials()
        user_ids = list(credentials.keys())
        if 1 <= user_num <= len(user_ids):
            user_id = user_ids[user_num - 1]
    except ValueError:
        pass  # user_id is already a string
    
    # Initialize session
    session_id = None
    chat_count = 0
    
    print(f"\n💬 INTERACTIVE CHAT SESSION - User: {user_id}")
    print("="*80)
    print("💡 Type 'help' for commands, 'quit' to exit")
    print("-" * 80)
    
    # Main chat loop
    while True:
        try:
            # Get user input
            message = get_user_input("\n💬 You")
            
            # Handle special commands
            if message.lower() in ['quit', 'exit', 'q']:
                print("\n👋 Thanks for testing the system! Goodbye!")
                break
            elif message.lower() == 'help':
                display_help()
                continue
            elif message.lower() == 'stats':
                try:
                    stats = system.get_system_stats()
                    if stats['success']:
                        print("\n📊 SYSTEM STATISTICS")
                        print("-" * 40)
                        print(f"Total Users: {stats['authentication']['total_users']}")
                        print(f"Active Sessions: {stats['authentication']['session_stats']['active_sessions']}")
                        print(f"Total Chats: {stats['chat_history']['total_chats']}")
                        print(f"Total Events: {stats['audit_logging']['total_events']}")
                        print(f"Human Handovers: {stats['human_handovers']['total_handovers']}")
                    else:
                        print("❌ Failed to get system stats")
                except Exception as e:
                    print(f"❌ Error getting stats: {e}")
                continue
            elif message.lower() == 'users':
                display_user_menu()
                continue
            elif message.lower() == 'auth':
                display_auth_info(user_id)
                continue
            elif not message.strip():
                print("💡 Please enter a message or command")
                continue
            
            # Process message through the complete system
            print("\n🤖 Processing your message...")
            print("-" * 40)
            
            # Add authentication parameters if needed
            kwargs = {}
            credentials = load_demo_credentials()
            user_creds = credentials.get(user_id, {})
            if user_creds.get('plain_password'):
                kwargs['password'] = user_creds['plain_password']
            
            # Process the message
            result = system.process_customer_message(user_id, message, session_id=session_id, **kwargs)
            
            # Update session info
            if result.get('session_id'):
                session_id = result['session_id']
            
            # Display response
            print(f"\n🤖 AI Agent Response:")
            print(f"   Intent: {result.get('intent', 'N/A')}")
            print(f"   Confidence: {result.get('confidence', 0):.2f}")
            print(f"   Auth Required: {result.get('auth_required', False)}")
            print(f"   Auth Successful: {result.get('auth_successful', False)}")
            print(f"   Human Agent: {result.get('requires_human_agent', False)}")
            print(f"   Chat ID: {result.get('chat_id', 'N/A')}")
            
            if result.get('reasoning'):
                print(f"\n🧠 AI Reasoning: {result['reasoning']}")
            
            print(f"\n💬 Response: {result['response']}")
            
            # Display follow-up questions if available
            if result.get('follow_up_questions'):
                print(f"\n❓ Follow-up Questions:")
                for i, question in enumerate(result['follow_up_questions'], 1):
                    print(f"   {i}. {question}")
            
            # Display human handover info if needed
            if result.get('human_handover'):
                handover = result['human_handover']
                print(f"\n📞 Human Agent Handover:")
                print(f"   Reason: {handover.get('reason', 'N/A')}")
                print(f"   Contact: {handover.get('contact_number', 'N/A')}")
                print(f"   Reference ID: {handover.get('reference_id', 'N/A')}")
            
            chat_count += 1
            print(f"\n📊 Chat #{chat_count} completed")
            
        except KeyboardInterrupt:
            print("\n\n👋 Chat interrupted. Thanks for testing!")
            break
        except Exception as e:
            print(f"\n❌ Error processing message: {e}")
            print("💡 Please try again or type 'help' for assistance")

if __name__ == "__main__":
    interactive_chat()
