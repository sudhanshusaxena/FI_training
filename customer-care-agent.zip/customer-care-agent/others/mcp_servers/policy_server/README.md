# policy_server (MCP)
**Endpoint:** `policy.check`

## Purpose
Validates actions against company policies and SOPs. Ensures all customer care operations comply with business rules, regulatory requirements, and company guidelines.

## Endpoint: policy.check

### Input Schema
```json
{
  "properties": {
    "action": {"type": "string"},
    "args": {"type": "object"},
    "auth_level": {"type": "integer"}
  }
}
```

### Input Example
```json
{
  "action": "orders.refund_apply",
  "args": {
    "order_id": "o_2001",
    "amount": 89.00,
    "mode": "original"
  },
  "auth_level": 2
}
```

### Output Schema
```json
{
  "properties": {
    "allow": {"type": "boolean"},
    "reason": {"type": "string"},
    "required_clause": {"type": "string"}
  }
}
```

### Output Example
```json
{
  "allow": true,
  "reason": "Matches RF-2.3 within 30 days for damaged item",
  "required_clause": "RF-2.3"
}
```

## Data Source
- Parses SOP MD front matter in `shared/sops/`
- Picks latest `effective_date` for policy versions
- Validates limits/conditions against policy rules
- Returns allow/deny + clause_id for audit trail

## Policy Rules Processing

### Refund Policy (RF-2.3)
**Condition**: `order_status == delivered AND within_days(30) AND reason in ['damaged','not_as_described']`
**Action**: `refund <= 100% to original payment method`
**Requirements**: `["proof_of_purchase"]`

### Shipping Delay Policy (RF-1.2)
**Condition**: `order_status == shipped AND carrier_delay == true`
**Action**: `offer voucher <= 15% OR partial refund <= 20%`
**Requirements**: `[]`

## Business Logic
- **Policy Parsing**: Extracts rules from SOP front-matter
- **Condition Evaluation**: Validates action against policy conditions
- **Auth Level Check**: Ensures user has required permissions
- **Clause Mapping**: Maps actions to specific policy clauses
- **Audit Trail**: Records all policy decisions for compliance

## Example Policy Checks

### Valid Refund Request
**Input**: Refund for delivered order within 30 days, damaged item
**Output**: `{"allow": true, "reason": "Matches RF-2.3", "required_clause": "RF-2.3"}`

### Invalid Refund Request
**Input**: Refund for order older than 30 days
**Output**: `{"allow": false, "reason": "Outside 30-day refund window", "required_clause": null}`

### Shipping Delay Compensation
**Input**: Voucher offer for delayed shipment
**Output**: `{"allow": true, "reason": "Matches RF-1.2 for carrier delay", "required_clause": "RF-1.2"}`

## Action Types Supported
- **orders.refund_apply**: Refund processing validation
- **orders.refund_quote**: Refund eligibility check
- **shipping.compensation**: Delay compensation validation
- **account.modify**: Account modification permissions
- **data.access**: Data access level validation

## Error Handling
- **Policy not found**: Returns error for unknown actions
- **Invalid args**: Returns error for malformed arguments
- **Auth insufficient**: Returns deny with auth level requirement
- **Policy conflict**: Returns deny with conflicting policy explanation

## Security Features
- **Audit Logging**: All policy decisions are logged
- **Version Control**: Uses latest effective policy version
- **Access Control**: Validates user authorization level
- **Compliance**: Ensures regulatory compliance for all actions

## Integration Notes
- **SOP Updates**: Automatically picks up new policy versions
- **Real-time Validation**: No caching, always uses current policy
- **Traceability**: Every decision includes clause ID for audit
- **Escalation**: Complex cases can be flagged for human review
