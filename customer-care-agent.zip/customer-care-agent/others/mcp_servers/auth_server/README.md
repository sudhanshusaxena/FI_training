# auth_server (MCP)
**Endpoint:** `auth.lookup_user`

## Purpose
Provides user authentication and authorization services for the customer care agent system. Handles user lookup, authentication level determination, and access control validation.

## Endpoint: auth.lookup_user

### Input Schema
```json
{
  "oneOf": [
    {"properties": {"email": {"type": "string"}}},
    {"properties": {"user_id": {"type": "string"}}},
    {"properties": {"phone": {"type": "string"}}}
  ]
}
```

### Input Examples
```json
{"email": "a@example.com"}
```
```json
{"user_id": "u_1001"}
```
```json
{"phone": "+1-555-0101"}
```

### Output Schema
```json
{
  "properties": {
    "user": {"type": "object"},
    "auth_level": {"type": "integer"}
  }
}
```

### Output Example
```json
{
  "user": {
    "user_id": "u_1001",
    "email": "a@example.com",
    "name": "Alex Example",
    "phone": "+1-555-0101",
    "address": {
      "street": "123 Main St",
      "city": "Anytown",
      "state": "CA",
      "zip": "12345",
      "country": "US"
    },
    "account_status": "active",
    "registration_date": "2024-01-15",
    "total_orders": 5,
    "lifetime_value": 450.00
  },
  "auth_level": 2
}
```

## Data Source
- Reads from `shared/fixtures/users.json`
- Supports lookup by email, user_id, or phone number
- Returns complete user profile with authentication level

## Authentication Levels
- **Level 0**: Unauthenticated (guest user)
- **Level 1**: Basic authenticated user (can view own orders)
- **Level 2**: Premium authenticated user (can access advanced features)

## Error Handling
- **User not found**: Returns `{"error": "User not found", "auth_level": 0}`
- **Invalid input**: Returns `{"error": "Invalid lookup parameter", "auth_level": 0}`
- **Account disabled**: Returns user data with `auth_level: 0`

## Security Notes
- No password verification (assumes pre-authenticated session)
- Auth level determines access to sensitive operations
- All user data returned is sanitized for logging purposes
