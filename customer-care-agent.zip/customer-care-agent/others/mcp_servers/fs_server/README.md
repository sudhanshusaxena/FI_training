# fs_server (MCP)
**Endpoint:** `fs.read`

## Purpose
Provides read-only file system access to shared resources. Enables the customer care agent to access configuration files, templates, and other shared resources safely.

## Endpoint: fs.read

### Input Schema
```json
{
  "properties": {
    "path": {"type": "string"}
  }
}
```

### Input Example
```json
{
  "path": "shared/sops/refunds_policy_v2024-07-01.md"
}
```

### Output Schema
```json
{
  "properties": {
    "text": {"type": "string"}
  }
}
```

### Output Example
```json
{
  "text": "---\ntitle: Refunds Policy\nversion: 2024-07-01\nowner: Ops\ntags: [refunds, policy]\npolicy_rules:\n  - clause_id: RF-2.3\n    condition: \"order_status == delivered AND within_days(30) AND reason in ['damaged','not_as_described']\"\n    action: \"refund <= 100% to original payment method\"\n    requires: [\"proof_of_purchase\"]\n---\n# Refunds Policy\n\n## Overview\nThis policy governs all refund requests..."
}
```

## Allowed Paths
- **SOPs**: `shared/sops/*.md`
- **FAQs**: `shared/faq/*.md`
- **Schemas**: `shared/schemas/*.json`
- **Templates**: `shared/templates/*.md`
- **Configuration**: `shared/config/*.json`

## Restricted Paths
- **User Data**: `shared/fixtures/users.json` (read-only)
- **Order Data**: `shared/fixtures/orders.json` (read-only)
- **Logs**: `logs/*` (access denied)
- **Memory**: `memory/*` (access denied)
- **System Files**: Any path outside `shared/` directory

## Data Source
- Reads from `shared/` directory only
- No write access to any files
- Supports text files (Markdown, JSON, YAML, TXT)

## Business Logic
- **Path Validation**: Ensures requested path is within allowed directories
- **Content Reading**: Reads file content as plain text
- **Error Handling**: Returns appropriate errors for invalid paths or files
- **Security Checks**: Prevents access to sensitive system files

## Example Usage Scenarios

### Reading SOP Files
**Input**: `"shared/sops/refunds_policy_v2024-07-01.md"`
**Output**: Complete refund policy document with front-matter

### Reading Schema Files
**Input**: `"shared/schemas/tool_schemas.json"`
**Output**: Complete tool schema definitions

### Reading FAQ Files
**Input**: `"shared/faq/general_faq.md"`
**Output**: Complete FAQ document content

## Error Handling
- **File not found**: Returns error for non-existent files
- **Access denied**: Returns error for restricted paths
- **Invalid path**: Returns error for malformed path requests
- **Read error**: Returns error for files that cannot be read

## Security Features
- **Read-only access**: No file modification capabilities
- **Path restrictions**: Limited to `shared/` directory
- **No system access**: Cannot read logs, memory, or system files
- **Audit logging**: All file access is logged for security monitoring

## File Type Support
- **Markdown**: `.md` files for documentation and SOPs
- **JSON**: `.json` files for schemas and configuration
- **YAML**: `.yaml` files for configuration
- **Text**: `.txt` files for plain text content
- **CSV**: `.csv` files for data tables (if needed)

## Performance Considerations
- **Caching**: Frequently accessed files may be cached
- **Size limits**: Large files may be truncated or rejected
- **Concurrent access**: Supports multiple simultaneous reads
- **Memory management**: File content is loaded into memory temporarily
