# shipping_server (MCP)
**Endpoint:** `shipping.status`

## Purpose
Provides shipping and delivery status information for customer orders. Handles carrier integration, tracking updates, and delivery estimates.

## Endpoint: shipping.status

### Input Schema
```json
{
  "properties": {
    "order_id": {"type": "string"}
  }
}
```

### Input Example
```json
{
  "order_id": "o_2001"
}
```

### Output Schema
```json
{
  "properties": {
    "carrier": {"type": "string"},
    "stage": {"type": "string"},
    "eta": {"type": "string"}
  }
}
```

### Output Example
```json
{
  "carrier": "FedEx",
  "stage": "delivered",
  "eta": "2025-09-10T14:30:00Z"
}
```

## Shipping Stages
- **processing**: Order being prepared for shipment
- **shipped**: Package picked up by carrier
- **in_transit**: Package en route to destination
- **out_for_delivery**: Package on delivery vehicle
- **delivered**: Package successfully delivered
- **delayed**: Delivery delayed due to external factors
- **exception**: Delivery issue requiring attention

## Data Source
- Reads from `shared/fixtures/orders.json`
- Integrates with carrier APIs (FedEx, UPS, USPS)
- Provides real-time tracking information

## Business Logic
- **Status Lookup**: Retrieves current shipping status for order
- **ETA Calculation**: Computes estimated delivery time based on carrier data
- **Delay Detection**: Identifies and reports shipping delays
- **Exception Handling**: Flags delivery issues for manual intervention

## Carrier Integration
- **FedEx**: FX tracking number format
- **UPS**: UPS tracking number format
- **USPS**: USPS tracking number format
- **DHL**: DHL tracking number format

## Example Responses

### Delivered Order
```json
{
  "carrier": "FedEx",
  "stage": "delivered",
  "eta": "2025-09-10T14:30:00Z"
}
```

### In Transit Order
```json
{
  "carrier": "UPS",
  "stage": "in_transit",
  "eta": "2025-09-12T16:00:00Z"
}
```

### Delayed Order
```json
{
  "carrier": "FedEx",
  "stage": "delayed",
  "eta": "2025-09-13T18:00:00Z",
  "delay_reason": "Weather conditions"
}
```

## Error Handling
- **Order not found**: Returns error with order not found message
- **No tracking info**: Returns error for orders without tracking
- **Carrier unavailable**: Returns cached status with warning
- **Invalid tracking**: Returns error for malformed tracking numbers

## Security Notes
- No authentication required for public tracking information
- Sensitive address data is not exposed in responses
- All API calls to carriers are logged for audit purposes
