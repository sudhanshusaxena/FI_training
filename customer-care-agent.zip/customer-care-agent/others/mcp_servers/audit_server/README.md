# audit_server (MCP)
**Endpoint:** `audit.log`

## Purpose
Provides comprehensive audit logging and traceability for all customer care operations. Ensures compliance, security monitoring, and operational transparency.

## Endpoint: audit.log

### Input Schema
```json
{
  "properties": {
    "event_type": {"type": "string"},
    "payload": {"type": "object"}
  }
}
```

### Input Example
```json
{
  "event_type": "policy_gate_decision",
  "payload": {
    "action": "orders.refund_apply",
    "order_id": "o_2001",
    "amount": 89.00,
    "decision": "approved",
    "clause_id": "RF-2.3",
    "user_id": "u_1001",
    "timestamp": "2025-01-15T10:30:00Z"
  }
}
```

### Output Schema
```json
{
  "properties": {
    "trace_id": {"type": "string"}
  }
}
```

### Output Example
```json
{
  "trace_id": "trace_2025-01-15_10-30-00_a1b2c3d4"
}
```

## Event Types
- **message_received**: Customer message received
- **triage_result**: Intent classification result
- **guardrails_scan**: Security scan results
- **route_enter/exit**: Agent routing decisions
- **tool_call_start/end**: MCP tool execution
- **policy_gate_decision**: Policy validation results
- **hitl_required/decision**: Human-in-the-loop events
- **memory_write**: Memory update events
- **response_sent**: Final response to customer

## Data Storage
- **Primary Storage**: `logs/runs/<trace_id>/trace.jsonl`
- **Format**: JSON Lines (one event per line)
- **Retention**: 90 days for operational logs, 7 years for compliance logs
- **Backup**: Automated daily backups to secure storage

## Business Logic
- **Trace ID Generation**: Creates unique trace ID for each conversation
- **Event Serialization**: Converts events to JSON Lines format
- **PII Sanitization**: Removes sensitive data before logging
- **Retention Management**: Automatically archives old logs
- **Compliance Reporting**: Generates audit reports for regulatory requirements

## Example Log Entries

### Message Received
```json
{"timestamp": "2025-01-15T10:30:00Z", "trace_id": "trace_2025-01-15_10-30-00_a1b2c3d4", "event": "message_received", "text": "I need help with my order o_2001", "user_id": "u_1001"}
```

### Policy Decision
```json
{"timestamp": "2025-01-15T10:30:15Z", "trace_id": "trace_2025-01-15_10-30-00_a1b2c3d4", "event": "policy_gate_decision", "action": "orders.refund_apply", "clause_id": "RF-2.3", "decision": "approved", "justification": "Matches policy RF-2.3 for damaged item within 30 days"}
```

### Tool Call
```json
{"timestamp": "2025-01-15T10:30:30Z", "trace_id": "trace_2025-01-15_10-30-00_a1b2c3d4", "event": "tool_call_end", "tool": "orders.refund_apply", "result_sanitized": {"status": "processing", "ticket_id": "REF-2024-001"}, "duration_ms": 245}
```

## PII Handling
- **Email Addresses**: Masked to `user***@example.com`
- **Phone Numbers**: Masked to `+1-555-****`
- **Credit Card Info**: Never logged
- **Addresses**: Generalized to city/state level
- **Names**: First name only, last name masked

## Compliance Features
- **GDPR Compliance**: Automatic data anonymization
- **SOX Compliance**: Financial transaction audit trails
- **HIPAA Compliance**: Healthcare data protection (if applicable)
- **PCI Compliance**: Payment data exclusion

## Error Handling
- **Logging Failure**: Returns error if unable to write logs
- **Invalid Event**: Returns error for malformed event data
- **Storage Full**: Returns error if storage quota exceeded
- **Permission Denied**: Returns error if insufficient permissions

## Security Features
- **Encryption**: All logs encrypted at rest
- **Access Control**: Role-based access to audit logs
- **Integrity**: Cryptographic signatures for log integrity
- **Monitoring**: Real-time monitoring for suspicious activity

## Integration Notes
- **Real-time Logging**: Synchronous logging for critical events
- **Batch Logging**: Asynchronous logging for high-volume events
- **Alert Integration**: Triggers alerts for security events
- **Reporting**: Automated compliance report generation
