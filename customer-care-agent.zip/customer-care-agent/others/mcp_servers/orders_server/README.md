# orders_server (MCP)
**Endpoints:** `orders.lookup`, `orders.refund_quote`, `orders.refund_apply`

## Purpose
Provides order management services including order lookup, refund quotation, and refund processing for the customer care agent system.

## Endpoint: orders.lookup

### Input Schema
```json
{
  "properties": {
    "order_id": {"type": "string"},
    "user_id": {"type": "string"}
  }
}
```

### Input Example
```json
{
  "order_id": "o_2001",
  "user_id": "u_1001"
}
```

### Output Schema
```json
{
  "properties": {
    "orders": {"type": "array"}
  }
}
```

### Output Example
```json
{
  "orders": [
    {
      "order_id": "o_2001",
      "user_id": "u_1001",
      "status": "delivered",
      "delivered_at": "2025-09-10",
      "total": 89.00,
      "currency": "USD",
      "items": [
        {
          "product_id": "smart-widget-pro",
          "name": "Smart Widget Pro",
          "quantity": 1,
          "price": 89.00
        }
      ],
      "shipping_address": {
        "street": "123 Main St",
        "city": "Anytown",
        "state": "CA",
        "zip": "12345"
      },
      "payment_method": "credit_card",
      "order_date": "2025-09-05",
      "shipped_date": "2025-09-07",
      "carrier": "FedEx",
      "tracking_number": "FX123456789"
    }
  ]
}
```

## Endpoint: orders.refund_quote

### Input Schema
```json
{
  "properties": {
    "order_id": {"type": "string"},
    "reason": {"type": "string"}
  }
}
```

### Input Example
```json
{
  "order_id": "o_2001",
  "reason": "damaged"
}
```

### Output Schema
```json
{
  "properties": {
    "eligible": {"type": "boolean"},
    "amount": {"type": "number"},
    "clause_id": {"type": "string"}
  }
}
```

### Output Example
```json
{
  "eligible": true,
  "amount": 89.00,
  "clause_id": "RF-2.3"
}
```

## Endpoint: orders.refund_apply

### Input Schema
```json
{
  "properties": {
    "order_id": {"type": "string"},
    "amount": {"type": "number"},
    "mode": {"type": "string"}
  }
}
```

### Input Example
```json
{
  "order_id": "o_2001",
  "amount": 89.00,
  "mode": "original"
}
```

### Output Schema
```json
{
  "properties": {
    "status": {"type": "string"},
    "ticket_id": {"type": "string"}
  }
}
```

### Output Example
```json
{
  "status": "processing",
  "ticket_id": "REF-2024-001"
}
```

## Data Source
- Reads from `shared/fixtures/orders.json`
- Integrates with `shared/sops/refunds_policy_v2024-07-01.md` for policy validation
- Generates unique ticket IDs for refund tracking

## Business Logic
- **Order Lookup**: Returns orders matching user_id and optionally order_id
- **Refund Quote**: Validates eligibility against refund policy clauses
- **Refund Apply**: Processes refund with audit trail and ticket generation

## Error Handling
- **Order not found**: Returns empty orders array
- **Invalid user access**: Returns error for unauthorized order access
- **Policy violation**: Returns `{"eligible": false, "reason": "Policy violation"}`
- **Processing error**: Returns error status with details

## Security Notes
- User authorization required for order access
- All refund operations require audit logging
- Sensitive payment data is masked in responses
