# kb_server (MCP)
**Endpoint:** `kb.search`

## Purpose
Provides knowledge base search functionality for SOPs, FAQs, and policy documents. Enables semantic search across all company knowledge resources.

## Endpoint: kb.search

### Input Schema
```json
{
  "properties": {
    "query": {"type": "string"},
    "top_k": {"type": "integer"}
  }
}
```

### Input Example
```json
{
  "query": "refund policy for damaged items",
  "top_k": 5
}
```

### Output Schema
```json
{
  "properties": {
    "passages": {"type": "array"}
  }
}
```

### Output Example
```json
{
  "passages": [
    {
      "source_path": "shared/sops/refunds_policy_v2024-07-01.md",
      "heading": "RF-2.3: Full Refund for Damaged/Incorrect Items",
      "content": "Order status: Delivered, Time window: Within 30 days of delivery, Reason: Damaged item or not as described, Documentation: Proof of purchase required. Action: Full refund (up to 100%) to original payment method",
      "relevance_score": 0.95,
      "clause_id": "RF-2.3",
      "effective_date": "2024-07-01"
    },
    {
      "source_path": "shared/faq/general_faq.md",
      "heading": "Returns & Exchanges",
      "content": "Return window: 30 days from delivery date, Return shipping: Free return labels provided, Exchange process: Same as returns, new item shipped upon receipt",
      "relevance_score": 0.87,
      "clause_id": null,
      "effective_date": null
    }
  ]
}
```

## Data Sources
- **SOPs**: `shared/sops/` directory (Markdown files with front-matter)
- **FAQs**: `shared/faq/` directory (Markdown files)
- **Policy Documents**: All policy files with clause IDs and effective dates

## Search Capabilities
- **Semantic Search**: Natural language query understanding
- **Clause Matching**: Direct policy clause identification
- **Relevance Scoring**: Ranked results by relevance (0.0-1.0)
- **Metadata Extraction**: Clause IDs, effective dates, and headings

## Query Types
- **Policy Queries**: "refund policy", "shipping delays", "warranty claims"
- **Procedural Queries**: "how to process refund", "escalation procedures"
- **Product Queries**: "Smart Widget compatibility", "installation support"
- **General Queries**: "contact information", "business hours"

## Business Logic
- **Document Parsing**: Extracts front-matter metadata from SOP files
- **Content Indexing**: Creates searchable index of all knowledge base content
- **Relevance Ranking**: Uses semantic similarity for result ranking
- **Clause Resolution**: Maps queries to specific policy clauses when possible

## Example Queries and Results

### Refund Policy Query
**Input**: `"refund policy for damaged items"`
**Output**: Returns RF-2.3 clause with full details and requirements

### Shipping Delay Query
**Input**: `"what to do when order is delayed"`
**Output**: Returns RF-1.2 clause with compensation options

### General FAQ Query
**Input**: `"return window policy"`
**Output**: Returns general FAQ content about returns and exchanges

## Error Handling
- **No results found**: Returns empty passages array
- **Invalid query**: Returns error for malformed search queries
- **Index unavailable**: Returns error if knowledge base is not accessible
- **Permission denied**: Returns error for restricted document access

## Security Notes
- Read-only access to knowledge base documents
- No modification of source documents
- All search queries are logged for analytics
- Sensitive policy details may require authentication level
