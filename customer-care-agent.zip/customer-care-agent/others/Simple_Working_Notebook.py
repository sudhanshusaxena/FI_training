#!/usr/bin/env python3
"""
Simple Working Version of the Customer Care Agent
This is a standalone script that demonstrates the full functionality.
"""

import sys
import os
import json
import uuid
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path
import openai
from openai import OpenAI

def main():
    """Main function demonstrating the complete customer care agent."""
    print("🤖 Simple Working Customer Care Agent")
    print("=" * 60)
    
    # Add paths
    sys.path.append('shared')
    sys.path.append('evaluation')
    
    # Set API key
    OPENAI_API_KEY = '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'
    os.environ['OPENAI_API_KEY'] = OPENAI_API_KEY
    
    print("✅ OpenAI API Key set successfully!")
    
    # Import and initialize systems
    try:
        from memory_manager import MemoryManager
        from policy_gate import PolicyGate
        from hitl_system import HITLSystem
        from guardrails import GuardrailsSystem
        from audit_logger import AuditLogger
        from test_scenarios import TestScenarioSuite
        from evaluation_metrics import EvaluationMetrics
        
        print("✅ All imports successful!")
        
        # Initialize systems
        memory_manager = MemoryManager(base_path="memory")
        policy_gate = PolicyGate(sops_path="shared/sops")
        hitl_system = HITLSystem(storage_path="logs/hitl")
        guardrails_system = GuardrailsSystem()
        audit_logger = AuditLogger(logs_path="logs/audit")
        test_suite = TestScenarioSuite()
        evaluation_metrics = EvaluationMetrics()
        
        print("✅ All systems initialized!")
        
    except Exception as e:
        print(f"❌ System initialization error: {e}")
        return
    
    # Load data files
    try:
        with open('shared/schemas/tool_schemas.json', 'r') as f:
            TOOL_SCHEMAS = json.load(f)
        with open('shared/fixtures/users.json', 'r') as f:
            USERS_DATA = json.load(f)
        with open('shared/fixtures/orders.json', 'r') as f:
            ORDERS_DATA = json.load(f)
        
        print(f"✅ Data loaded: {len(TOOL_SCHEMAS)} schemas, {len(USERS_DATA)} users, {len(ORDERS_DATA)} orders")
    except Exception as e:
        print(f"❌ Data loading error: {e}")
        return
    
    # Initialize LLM Service
    class SimpleLLMService:
        def __init__(self, api_key: str):
            self.client = OpenAI(api_key=api_key)
            self.model = 'gpt-4o-mini'
            print(f"✅ LLM Service initialized with model: {self.model}")
        
        def classify_intent(self, user_message: str) -> dict:
            prompt = f'''Analyze this customer message and classify the intent. Return ONLY valid JSON.

Message: "{user_message}"

Categories: refunds, order_status, troubleshoot, sales, sop_lookup, general

JSON format:
{{
    "intent": "refunds",
    "confidence": 0.95,
    "reasoning": "Customer explicitly requests refund",
    "extracted_entities": {{"order_id": "o_2001"}},
    "urgency": "high"
}}'''
            
            try:
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=[{'role': 'user', 'content': prompt}],
                    temperature=0.1,
                    max_tokens=500
                )
                
                result_text = response.choices[0].message.content.strip()
                
                # Clean up JSON response
                if result_text.startswith('```json'):
                    result_text = result_text.replace('```json', '').replace('```', '').strip()
                elif result_text.startswith('```'):
                    result_text = result_text.replace('```', '').strip()
                
                result = json.loads(result_text)
                return result
                
            except Exception as e:
                print(f'LLM error: {e}')
                return {
                    'intent': 'general',
                    'confidence': 0.3,
                    'reasoning': f'Classification failed: {e}',
                    'extracted_entities': {},
                    'urgency': 'medium'
                }
        
        def generate_response(self, intent: str, context: dict, user_message: str) -> str:
            prompt = f'''You are a professional customer service agent. Generate a helpful response.

Customer Message: "{user_message}"
Intent: {intent}
Context: {json.dumps(context, indent=2)}

Guidelines:
- Be empathetic and professional
- Provide specific, actionable information
- Keep response concise but comprehensive
- Use a friendly, helpful tone

Generate a response that directly addresses the customer's needs:'''
            
            try:
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=[{'role': 'user', 'content': prompt}],
                    temperature=0.7,
                    max_tokens=300
                )
                
                return response.choices[0].message.content.strip()
                
            except Exception as e:
                return "I apologize, but I'm having trouble processing your request right now. Please try again or contact our support team for assistance."
    
    # Initialize LLM Service
    try:
        llm_service = SimpleLLMService(OPENAI_API_KEY)
        print("✅ LLM Service ready!")
    except Exception as e:
        print(f"❌ LLM Service error: {e}")
        return
    
    # Display system status
    print("\n📊 System Status:")
    print("=" * 40)
    
    try:
        memory_stats = memory_manager.get_memory_stats()
        print(f"💾 Memory Manager: {memory_stats.get('session_count', 0)} session, {memory_stats.get('global_count', 0)} global")
    except Exception as e:
        print(f"💾 Memory Manager: Available (error: {e})")
    
    print(f"⚖️  Policy Gate: {len(policy_gate.policy_clauses)} policies")
    print(f"👤 HITL System: {len(hitl_system.pending_requests)} pending")
    print(f"🧪 Test Suite: {len(test_suite.scenarios)} scenarios")
    print(f"🧠 LLM Service: {llm_service.model} - Active")
    
    # Demo scenarios
    print("\n🎬 Demo Scenarios:")
    print("=" * 40)
    
    demo_scenarios = [
        {
            "message": "Hi, my Smart Widget Pro order o_2001 arrived damaged yesterday. Can I get a refund?",
            "user_id": "u_1001",
            "description": "Refund Request"
        },
        {
            "message": "My Smart Widget Pro keeps disconnecting from WiFi. Can you help?",
            "user_id": "u_1002",
            "description": "Troubleshooting"
        },
        {
            "message": "I'm looking for a smart home device for productivity. What do you recommend?",
            "user_id": "u_1003",
            "description": "Sales Inquiry"
        }
    ]
    
    for i, scenario in enumerate(demo_scenarios, 1):
        print(f"\n🎬 Demo {i}: {scenario['description']}")
        print("-" * 40)
        
        try:
            # Classify intent
            intent_result = llm_service.classify_intent(scenario["message"])
            print(f"🧠 Intent: {intent_result['intent']} (confidence: {intent_result['confidence']:.2f})")
            print(f"📊 Reasoning: {intent_result['reasoning']}")
            print(f"🏷️  Entities: {intent_result['extracted_entities']}")
            print(f"⚡ Urgency: {intent_result['urgency']}")
            
            # Generate response
            context = {
                'user_data': {'user_id': scenario['user_id']},
                'order_data': {},
                'policy_info': {}
            }
            
            response = llm_service.generate_response(
                intent_result['intent'], 
                context, 
                scenario["message"]
            )
            
            print(f"\n🤖 Response:")
            print(f"   {response}")
            
        except Exception as e:
            print(f"❌ Demo {i} error: {e}")
    
    print("\n🎉 Simple Working Customer Care Agent Demo Complete!")
    print("📝 This demonstrates the core functionality working correctly.")
    print("🚀 The main notebook should work the same way!")

if __name__ == "__main__":
    main()
