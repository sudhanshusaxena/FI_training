#!/usr/bin/env python3
"""
Setup script for Enhanced Customer Care Agent with LLM Integration
"""

import os
import sys
import subprocess
import json

def check_python_version():
    """Check if Python version is compatible."""
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        return False
    print(f"✅ Python {sys.version_info.major}.{sys.version_info.minor} detected")
    return True

def check_required_packages():
    """Check if required packages are installed."""
    required_packages = [
        'openai',
        'jupyter',
        'dataclasses',
        'pathlib'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"✅ {package} is installed")
        except ImportError:
            missing_packages.append(package)
            print(f"❌ {package} is not installed")
    
    if missing_packages:
        print(f"\n📦 Install missing packages with:")
        print(f"pip install {' '.join(missing_packages)}")
        return False
    
    return True

def check_openai_api_key():
    """Check if OpenAI API key is set."""
    api_key = os.getenv('OPENAI_API_KEY')
    if api_key:
        print("✅ OpenAI API key is set")
        return True
    else:
        print("❌ OpenAI API key is not set")
        print("\n🔑 Set your OpenAI API key:")
        print("export OPENAI_API_KEY='your-api-key-here'")
        print("\nOr add it to your .bashrc/.zshrc file for persistence")
        return False

def check_data_files():
    """Check if required data files exist."""
    required_files = [
        'shared/schemas/tool_schemas.json',
        'shared/fixtures/users.json',
        'shared/fixtures/orders.json',
        'shared/sops/refunds_policy_v2024-07-01.md'
    ]
    
    missing_files = []
    
    for file_path in required_files:
        if os.path.exists(file_path):
            print(f"✅ {file_path} exists")
        else:
            missing_files.append(file_path)
            print(f"❌ {file_path} is missing")
    
    if missing_files:
        print(f"\n📁 Missing required data files. Please ensure the repository is complete.")
        return False
    
    return True

def test_system_initialization():
    """Test if the system can be initialized."""
    try:
        sys.path.append('shared')
        sys.path.append('evaluation')
        
        from memory_manager import MemoryManager
        from policy_gate import PolicyGate
        from hitl_system import HITLSystem
        from guardrails import GuardrailsSystem
        from audit_logger import AuditLogger
        
        # Initialize systems
        memory_manager = MemoryManager(base_path="memory")
        policy_gate = PolicyGate(sops_path="shared/sops")
        hitl_system = HITLSystem(storage_path="logs/hitl")
        guardrails_system = GuardrailsSystem()
        audit_logger = AuditLogger(logs_path="logs/audit")
        
        print("✅ All systems can be initialized successfully")
        return True
        
    except Exception as e:
        print(f"❌ System initialization failed: {e}")
        return False

def main():
    """Main setup check function."""
    print("🔧 Enhanced Customer Care Agent - Setup Check")
    print("=" * 50)
    
    checks = [
        ("Python Version", check_python_version),
        ("Required Packages", check_required_packages),
        ("OpenAI API Key", check_openai_api_key),
        ("Data Files", check_data_files),
        ("System Initialization", test_system_initialization)
    ]
    
    all_passed = True
    
    for check_name, check_func in checks:
        print(f"\n🔍 Checking {check_name}...")
        if not check_func():
            all_passed = False
    
    print("\n" + "=" * 50)
    
    if all_passed:
        print("🎉 All checks passed! System is ready to run.")
        print("\n🚀 Next steps:")
        print("1. Run: jupyter notebook Master_Customer_Care_Agent_LLM.ipynb")
        print("2. Execute all cells in sequence")
        print("3. Test with the provided demo scenarios")
    else:
        print("❌ Some checks failed. Please fix the issues above before running the system.")
    
    return all_passed

if __name__ == "__main__":
    main()
