#!/usr/bin/env python3
"""
Test script for Enhanced Customer Care Agent with LLM Integration
"""

import sys
import os
import json
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Any

# Add paths
sys.path.append('shared')
sys.path.append('evaluation')

# Import required modules
from memory_manager import MemoryManager
from policy_gate import PolicyGate
from hitl_system import HITLSystem
from guardrails import GuardrailsSystem
from audit_logger import AuditLogger
from openai import OpenAI

# Load data files
with open('shared/schemas/tool_schemas.json', 'r') as f:
    TOOL_SCHEMAS = json.load(f)
with open('shared/fixtures/users.json', 'r') as f:
    USERS_DATA = json.load(f)
with open('shared/fixtures/orders.json', 'r') as f:
    ORDERS_DATA = json.load(f)

class LLMService:
    """OpenAI LLM service for intelligent customer care operations."""
    
    def __init__(self, api_key: str = None, model: str = "gpt-4o-mini"):
        """Initialize OpenAI client."""
        self.api_key = api_key or os.getenv('OPENAI_API_KEY')
        if not self.api_key:
            raise ValueError("OpenAI API key not provided.")
        
        self.client = OpenAI(api_key=self.api_key)
        self.model = model
        print(f"✅ LLM Service initialized with model: {model}")
    
    def classify_intent(self, user_message: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Use LLM to classify customer intent."""
        prompt = f'''Analyze this customer message and classify the intent. Return ONLY valid JSON.

Message: "{user_message}"

Categories: refunds, order_status, troubleshoot, sales, sop_lookup, general

JSON format:
{{
    "intent": "refunds",
    "confidence": 0.95,
    "reasoning": "Customer explicitly requests refund for damaged product",
    "extracted_entities": {{
        "order_id": "o_2001",
        "product_name": "Smart Widget Pro",
        "issue_type": "damaged"
    }},
    "urgency": "high"
}}'''
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=500
            )
            
            result = json.loads(response.choices[0].message.content.strip())
            return result
            
        except Exception as e:
            print(f"LLM intent classification failed: {e}")
            return {
                "intent": "general",
                "confidence": 0.3,
                "reasoning": f"Classification failed: {e}",
                "extracted_entities": {},
                "urgency": "medium"
            }
    
    def generate_response(self, intent: str, context: Dict[str, Any], user_message: str) -> str:
        """Generate intelligent customer response using LLM."""
        prompt = f'''You are a professional customer service agent. Generate a helpful, accurate, and empathetic response.

Customer Message: "{user_message}"
Intent: {intent}
Context: {json.dumps(context, indent=2)}

Guidelines:
- Be empathetic and professional
- Provide specific, actionable information
- Keep response concise but comprehensive
- Use a friendly, helpful tone

Generate a response that directly addresses the customer's needs:'''
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=300
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            return "I apologize, but I'm having trouble processing your request right now. Please try again or contact our support team for assistance."

class EnhancedCustomerCareAgent:
    """Enhanced customer care agent with LLM integration."""
    
    def __init__(self, llm_service: LLMService = None):
        self.llm_service = llm_service
        self.trace_id = f"trace_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
        self.session_id = f"session_{uuid.uuid4().hex[:8]}"
        
    def process_customer_message(self, user_input: str, user_id: Optional[str] = None) -> Dict[str, Any]:
        """Process a customer message through the enhanced LLM-powered workflow."""
        try:
            print(f"🔄 Processing: '{user_input}'")
            print(f"📋 Trace ID: {self.trace_id}")
            
            # Step 1: LLM Intent Classification
            print("  Step 1: LLM Intent Classification")
            intent_result = self.llm_service.classify_intent(user_input)
            
            print(f"    🧠 Intent: {intent_result['intent']} (confidence: {intent_result['confidence']:.2f})")
            print(f"    📊 Reasoning: {intent_result['reasoning']}")
            print(f"    🏷️  Entities: {intent_result['extracted_entities']}")
            print(f"    ⚡ Urgency: {intent_result['urgency']}")
            
            # Step 2: Context Enrichment
            print("  Step 2: Context Enrichment")
            context = self._enrich_context(intent_result, user_id)
            print(f"    🔍 Context enriched with user and order data")
            
            # Step 3: Generate LLM Response
            print("  Step 3: LLM Response Generation")
            response = self.llm_service.generate_response(
                intent_result['intent'], 
                context, 
                user_input
            )
            print(f"    🤖 LLM response generated")
            
            return {
                "response": response,
                "intent": intent_result['intent'],
                "confidence": intent_result['confidence'],
                "entities": intent_result['extracted_entities'],
                "urgency": intent_result['urgency'],
                "reasoning": intent_result['reasoning'],
                "trace_id": self.trace_id,
                "session_id": self.session_id
            }
            
        except Exception as e:
            print(f"❌ Error processing message: {e}")
            return {
                "response": "I apologize, but I encountered an error processing your request. Please try again or contact our support team.",
                "error": str(e),
                "trace_id": self.trace_id,
                "session_id": self.session_id
            }
    
    def _enrich_context(self, intent_result: Dict[str, Any], user_id: Optional[str]) -> Dict[str, Any]:
        """Enrich context with relevant data."""
        context = {}
        
        # Add user data if available
        if user_id:
            user_data = next((user for user in USERS_DATA if user["user_id"] == user_id), None)
            if user_data:
                context["user_data"] = user_data
        
        # Add order data if order ID detected
        entities = intent_result.get("extracted_entities", {})
        if "order_id" in entities:
            order_id = entities["order_id"]
            order_data = next((order for order in ORDERS_DATA if order["order_id"] == order_id), None)
            if order_data:
                context["order_data"] = order_data
        
        # Add product info if product mentioned
        if "product_name" in entities:
            context["product_info"] = {
                "name": entities["product_name"],
                "category": "Smart Widget Pro",
                "support_available": True
            }
        
        return context

def main():
    """Main test function."""
    print("🤖 Enhanced Customer Care Agent - LLM Test")
    print("=" * 60)
    
    # Initialize systems
    print("🔧 Initializing systems...")
    memory_manager = MemoryManager(base_path="memory")
    policy_gate = PolicyGate(sops_path="shared/sops")
    hitl_system = HITLSystem(storage_path="logs/hitl")
    guardrails_system = GuardrailsSystem()
    audit_logger = AuditLogger(logs_path="logs/audit")
    
    # Initialize LLM Service
    llm_service = LLMService()
    
    # Initialize Enhanced Agent
    agent = EnhancedCustomerCareAgent(llm_service)
    
    print("✅ All systems initialized successfully!")
    
    # Test scenarios
    test_scenarios = [
        {
            "message": "Hi, my Smart Widget Pro order o_2001 arrived damaged yesterday. The screen is cracked and it won't turn on. Can I get a refund?",
            "user_id": "u_1001",
            "description": "Refund Request for Damaged Product"
        },
        {
            "message": "My Smart Widget Pro keeps disconnecting from WiFi every few minutes. I've tried restarting it but the problem persists.",
            "user_id": "u_1002", 
            "description": "Troubleshooting WiFi Issues"
        },
        {
            "message": "I'm looking for a smart home device that can help with productivity. What would you recommend?",
            "user_id": "u_1003",
            "description": "Sales Inquiry"
        }
    ]
    
    # Run test scenarios
    for i, scenario in enumerate(test_scenarios, 1):
        print(f"\n🎬 Demo Scenario {i}: {scenario['description']}")
        print("-" * 60)
        
        result = agent.process_customer_message(
            scenario["message"], 
            scenario["user_id"]
        )
        
        print(f"\n📝 Customer Response:")
        print(f"   {result['response']}")
        
        print(f"\n📊 Analysis Summary:")
        print(f"   Intent: {result['intent']} (confidence: {result['confidence']:.2f})")
        print(f"   Entities: {result['entities']}")
        print(f"   Urgency: {result['urgency']}")
        print(f"   Reasoning: {result['reasoning']}")
        
        print("\n" + "=" * 60)
    
    print("\n🎉 Enhanced Customer Care Agent with LLM is working perfectly!")
    print("🚀 Ready for production deployment!")

if __name__ == "__main__":
    main()
