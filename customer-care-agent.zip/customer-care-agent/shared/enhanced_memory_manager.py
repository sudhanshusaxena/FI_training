#!/usr/bin/env python3
"""
Enhanced Memory Management System
Handles session memory, global memory, and comprehensive event logging
"""

import json
import os
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import hashlib

class EnhancedMemoryManager:
    """Enhanced memory management with session and global memory capabilities."""
    
    def __init__(self, memory_dir: str = "memory"):
        self.memory_dir = memory_dir
        self.session_dir = os.path.join(memory_dir, "session")
        self.global_dir = os.path.join(memory_dir, "global")
        self.logs_dir = os.path.join(memory_dir, "logs")
        
        # Create directories
        for directory in [self.session_dir, self.global_dir, self.logs_dir]:
            os.makedirs(directory, exist_ok=True)
        
        # Memory limits
        self.max_session_items = 20
        self.max_global_items = 100
        self.session_ttl_hours = 24
        self.global_ttl_days = 30
    
    def generate_memory_id(self, user_id: str, session_id: str = None) -> str:
        """Generate unique memory ID."""
        if session_id:
            return f"session_{user_id}_{session_id}_{uuid.uuid4().hex[:8]}"
        else:
            return f"global_{user_id}_{uuid.uuid4().hex[:8]}"
    
    def store_session_memory(self, user_id: str, session_id: str, memory_type: str, 
                           content: Dict[str, Any], metadata: Dict[str, Any] = None) -> str:
        """Store session-specific memory."""
        memory_id = self.generate_memory_id(user_id, session_id)
        
        memory_item = {
            "memory_id": memory_id,
            "user_id": user_id,
            "session_id": session_id,
            "memory_type": memory_type,
            "content": content,
            "metadata": metadata or {},
            "created_at": datetime.now().isoformat(),
            "expires_at": (datetime.now() + timedelta(hours=self.session_ttl_hours)).isoformat(),
            "access_count": 0,
            "last_accessed": None
        }
        
        # Store in session file
        session_file = os.path.join(self.session_dir, f"session_{user_id}_{session_id}.json")
        
        if os.path.exists(session_file):
            with open(session_file, 'r') as f:
                session_data = json.load(f)
        else:
            session_data = {"memories": [], "user_id": user_id, "session_id": session_id}
        
        # Add new memory
        session_data["memories"].append(memory_item)
        
        # Limit memories per session
        if len(session_data["memories"]) > self.max_session_items:
            session_data["memories"] = session_data["memories"][-self.max_session_items:]
        
        # Save to file
        with open(session_file, 'w') as f:
            json.dump(session_data, f, indent=2)
        
        # Log memory operation
        self.log_event("memory_write", {
            "memory_id": memory_id,
            "user_id": user_id,
            "session_id": session_id,
            "memory_type": memory_type,
            "scope": "session"
        })
        
        return memory_id
    
    def store_global_memory(self, user_id: str, memory_type: str, content: Dict[str, Any], 
                          metadata: Dict[str, Any] = None) -> str:
        """Store global user memory."""
        memory_id = self.generate_memory_id(user_id)
        
        memory_item = {
            "memory_id": memory_id,
            "user_id": user_id,
            "memory_type": memory_type,
            "content": content,
            "metadata": metadata or {},
            "created_at": datetime.now().isoformat(),
            "expires_at": (datetime.now() + timedelta(days=self.global_ttl_days)).isoformat(),
            "access_count": 0,
            "last_accessed": None
        }
        
        # Store in global file
        global_file = os.path.join(self.global_dir, f"global_{user_id}.json")
        
        if os.path.exists(global_file):
            with open(global_file, 'r') as f:
                global_data = json.load(f)
        else:
            global_data = {"memories": [], "user_id": user_id}
        
        # Add new memory
        global_data["memories"].append(memory_item)
        
        # Limit memories per user
        if len(global_data["memories"]) > self.max_global_items:
            global_data["memories"] = global_data["memories"][-self.max_global_items:]
        
        # Save to file
        with open(global_file, 'w') as f:
            json.dump(global_data, f, indent=2)
        
        # Log memory operation
        self.log_event("memory_write", {
            "memory_id": memory_id,
            "user_id": user_id,
            "memory_type": memory_type,
            "scope": "global"
        })
        
        return memory_id
    
    def retrieve_session_memories(self, user_id: str, session_id: str, 
                                memory_type: str = None, limit: int = 10) -> List[Dict[str, Any]]:
        """Retrieve session memories."""
        session_file = os.path.join(self.session_dir, f"session_{user_id}_{session_id}.json")
        
        if not os.path.exists(session_file):
            return []
        
        with open(session_file, 'r') as f:
            session_data = json.load(f)
        
        memories = session_data.get("memories", [])
        
        # Filter by type if specified
        if memory_type:
            memories = [m for m in memories if m.get("memory_type") == memory_type]
        
        # Sort by creation time (newest first)
        memories.sort(key=lambda x: x.get("created_at", ""), reverse=True)
        
        # Limit results
        memories = memories[:limit]
        
        # Update access information
        for memory in memories:
            memory["access_count"] = memory.get("access_count", 0) + 1
            memory["last_accessed"] = datetime.now().isoformat()
        
        # Save updated access info
        with open(session_file, 'w') as f:
            json.dump(session_data, f, indent=2)
        
        return memories
    
    def retrieve_global_memories(self, user_id: str, memory_type: str = None, 
                               limit: int = 10) -> List[Dict[str, Any]]:
        """Retrieve global memories."""
        global_file = os.path.join(self.global_dir, f"global_{user_id}.json")
        
        if not os.path.exists(global_file):
            return []
        
        with open(global_file, 'r') as f:
            global_data = json.load(f)
        
        memories = global_data.get("memories", [])
        
        # Filter by type if specified
        if memory_type:
            memories = [m for m in memories if m.get("memory_type") == memory_type]
        
        # Sort by creation time (newest first)
        memories.sort(key=lambda x: x.get("created_at", ""), reverse=True)
        
        # Limit results
        memories = memories[:limit]
        
        # Update access information
        for memory in memories:
            memory["access_count"] = memory.get("access_count", 0) + 1
            memory["last_accessed"] = datetime.now().isoformat()
        
        # Save updated access info
        with open(global_file, 'w') as f:
            json.dump(global_data, f, indent=2)
        
        return memories
    
    def get_user_context(self, user_id: str, session_id: str = None) -> Dict[str, Any]:
        """Get comprehensive user context from both session and global memory."""
        context = {
            "user_id": user_id,
            "session_id": session_id,
            "session_memories": [],
            "global_memories": [],
            "preferences": {},
            "history_summary": {}
        }
        
        # Get session memories
        if session_id:
            context["session_memories"] = self.retrieve_session_memories(user_id, session_id)
        
        # Get global memories
        context["global_memories"] = self.retrieve_global_memories(user_id)
        
        # Extract preferences from global memories
        preference_memories = [m for m in context["global_memories"] if m.get("memory_type") == "preference"]
        for pref_memory in preference_memories:
            context["preferences"].update(pref_memory.get("content", {}))
        
        # Generate history summary
        context["history_summary"] = self.generate_history_summary(context["session_memories"], context["global_memories"])
        
        return context
    
    def generate_history_summary(self, session_memories: List[Dict], global_memories: List[Dict]) -> Dict[str, Any]:
        """Generate a summary of user interaction history."""
        summary = {
            "total_interactions": len(session_memories) + len(global_memories),
            "common_intents": {},
            "recent_topics": [],
            "user_satisfaction": "neutral",
            "escalation_history": []
        }
        
        # Analyze intents from memories
        all_memories = session_memories + global_memories
        intent_counts = {}
        
        for memory in all_memories:
            memory_type = memory.get("memory_type", "unknown")
            intent_counts[memory_type] = intent_counts.get(memory_type, 0) + 1
            
            # Check for escalations
            if "escalation" in memory_type.lower() or "hitl" in memory_type.lower():
                summary["escalation_history"].append({
                    "timestamp": memory.get("created_at"),
                    "reason": memory.get("content", {}).get("reason", "unknown")
                })
        
        summary["common_intents"] = dict(sorted(intent_counts.items(), key=lambda x: x[1], reverse=True)[:5])
        
        # Extract recent topics
        recent_memories = sorted(all_memories, key=lambda x: x.get("created_at", ""), reverse=True)[:5]
        summary["recent_topics"] = [m.get("content", {}).get("topic", "unknown") for m in recent_memories]
        
        return summary
    
    def log_event(self, event_type: str, event_data: Dict[str, Any], 
                  user_id: str = None, session_id: str = None, chat_id: str = None):
        """Log comprehensive events for analysis."""
        event = {
            "event_id": str(uuid.uuid4()),
            "timestamp": datetime.now().isoformat(),
            "event_type": event_type,
            "user_id": user_id,
            "session_id": session_id,
            "chat_id": chat_id,
            "data": event_data
        }
        
        # Create daily log file
        date_str = datetime.now().strftime("%Y-%m-%d")
        log_file = os.path.join(self.logs_dir, f"events_{date_str}.jsonl")
        
        # Append event to log file
        with open(log_file, 'a') as f:
            f.write(json.dumps(event) + '\n')
        
        # Also log to Matrix.csv for evaluation
        self.log_to_matrix_csv(event)
    
    def log_to_matrix_csv(self, event: Dict[str, Any]):
        """Log event to Matrix.csv for evaluation purposes."""
        matrix_file = "Matrix.csv"
        
        # Check if file exists and has headers
        headers_exist = os.path.exists(matrix_file)
        
        # Prepare row data
        row_data = {
            "timestamp": event["timestamp"],
            "event_id": event["event_id"],
            "event_type": event["event_type"],
            "user_id": event.get("user_id", ""),
            "session_id": event.get("session_id", ""),
            "chat_id": event.get("chat_id", ""),
            "intent": event.get("data", {}).get("intent", ""),
            "auth_required": event.get("data", {}).get("auth_required", False),
            "auth_successful": event.get("data", {}).get("auth_successful", False),
            "agent_called": event.get("data", {}).get("agent_called", ""),
            "response_time_ms": event.get("data", {}).get("response_time_ms", 0),
            "user_satisfaction": event.get("data", {}).get("user_satisfaction", ""),
            "escalation_reason": event.get("data", {}).get("escalation_reason", ""),
            "memory_type": event.get("data", {}).get("memory_type", ""),
            "error_occurred": event.get("data", {}).get("error_occurred", False),
            "error_message": event.get("data", {}).get("error_message", "")
        }
        
        # Write to CSV
        import csv
        
        # If file doesn't exist, create with headers
        if not headers_exist:
            with open(matrix_file, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=row_data.keys())
                writer.writeheader()
        
        # Append row
        with open(matrix_file, 'a', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=row_data.keys())
            writer.writerow(row_data)
    
    def cleanup_expired_memories(self):
        """Clean up expired memories."""
        current_time = datetime.now()
        
        # Clean session memories
        for filename in os.listdir(self.session_dir):
            if filename.endswith('.json'):
                filepath = os.path.join(self.session_dir, filename)
                with open(filepath, 'r') as f:
                    session_data = json.load(f)
                
                # Filter out expired memories
                valid_memories = []
                for memory in session_data.get("memories", []):
                    expires_at = datetime.fromisoformat(memory.get("expires_at", current_time.isoformat()))
                    if expires_at > current_time:
                        valid_memories.append(memory)
                
                session_data["memories"] = valid_memories
                
                # Save cleaned data
                with open(filepath, 'w') as f:
                    json.dump(session_data, f, indent=2)
        
        # Clean global memories
        for filename in os.listdir(self.global_dir):
            if filename.endswith('.json'):
                filepath = os.path.join(self.global_dir, filename)
                with open(filepath, 'r') as f:
                    global_data = json.load(f)
                
                # Filter out expired memories
                valid_memories = []
                for memory in global_data.get("memories", []):
                    expires_at = datetime.fromisoformat(memory.get("expires_at", current_time.isoformat()))
                    if expires_at > current_time:
                        valid_memories.append(memory)
                
                global_data["memories"] = valid_memories
                
                # Save cleaned data
                with open(filepath, 'w') as f:
                    json.dump(global_data, f, indent=2)
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """Get memory system statistics."""
        stats = {
            "total_session_files": 0,
            "total_global_files": 0,
            "total_session_memories": 0,
            "total_global_memories": 0,
            "memory_usage_mb": 0
        }
        
        # Count session files and memories
        for filename in os.listdir(self.session_dir):
            if filename.endswith('.json'):
                stats["total_session_files"] += 1
                filepath = os.path.join(self.session_dir, filename)
                with open(filepath, 'r') as f:
                    session_data = json.load(f)
                stats["total_session_memories"] += len(session_data.get("memories", []))
                stats["memory_usage_mb"] += os.path.getsize(filepath) / (1024 * 1024)
        
        # Count global files and memories
        for filename in os.listdir(self.global_dir):
            if filename.endswith('.json'):
                stats["total_global_files"] += 1
                filepath = os.path.join(self.global_dir, filename)
                with open(filepath, 'r') as f:
                    global_data = json.load(f)
                stats["total_global_memories"] += len(global_data.get("memories", []))
                stats["memory_usage_mb"] += os.path.getsize(filepath) / (1024 * 1024)
        
        return stats

# Global instance
enhanced_memory_manager = EnhancedMemoryManager()
