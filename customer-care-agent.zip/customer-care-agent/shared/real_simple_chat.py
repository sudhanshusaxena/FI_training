#!/usr/bin/env python3
"""
Real Simple Chat System - Uses ACTUAL System Components
No simulation, no fake logic - uses the real TriageAgent and agents
"""

import sys
import os
import json
import time
import random
from datetime import datetime
from typing import Dict, List, Any, Optional

class RealSimpleChat:
    """Simple chat that uses the REAL system components."""
    
    def __init__(self, system_orchestrator):
        """Initialize with the REAL system orchestrator."""
        self.system = system_orchestrator
        self.chat_session = {
            'start_time': None,
            'end_time': None,
            'user_id': None,
            'messages': [],
            'authenticated_user': None,
            'current_chat_id': None
        }
    
    def start_real_simple_chat(self) -> None:
        """Start the simple chat using REAL system components."""
        print("🤖 Hello! I'm your Customer Care Agent.")
        print("How can I help you today?")
        print("\n💡 Just tell me what you need help with!")
        print("💡 Type 'quit' to end our conversation.")
        print("-" * 60)
        
        # Initialize chat session
        self.chat_session['start_time'] = datetime.now()
        self.chat_session['user_id'] = "anonymous_user"  # Start as anonymous
        
        # Main chat loop
        while True:
            try:
                # Get user input
                message = input("\n💬 You: ").strip()
                
                # Handle quit command
                if message.lower() in ['quit', 'exit', 'bye']:
                    print("\n👋 Thank you for chatting with me! Have a great day!")
                    break
                
                # Handle empty message
                if not message.strip():
                    print("💡 Please tell me how I can help you!")
                    continue
                
                # Process the message using REAL system
                self.process_message_with_real_system(message)
                
            except KeyboardInterrupt:
                print("\n\n👋 Chat ended. Thank you!")
                break
            except Exception as e:
                print(f"\n❌ Sorry, something went wrong: {e}")
                print("💡 Please try again or type 'quit' to exit")
        
        # End session
        self.chat_session['end_time'] = datetime.now()
    
    def process_message_with_real_system(self, message: str) -> None:
        """Process message using the REAL system orchestrator."""
        print(f"\n🤖 Let me process your request using our system...")
        
        try:
            # Use the REAL system to process the message
            result = self.system.process_customer_message(
                self.chat_session['user_id'], 
                message
            )
            
            # Show what the REAL TriageAgent decided
            self.show_real_triage_agent_thinking(message, result)
            
            # Handle the REAL system response
            self.handle_real_system_response(message, result)
            
        except Exception as e:
            print(f"❌ System error: {e}")
            print("💡 Let me try to help you directly...")
            self.handle_fallback_response(message)
    
    def show_real_triage_agent_thinking(self, message: str, result: Dict[str, Any]) -> None:
        """Show what the REAL TriageAgent actually decided."""
        print("\n🧠 REAL TriageAgent Analysis:")
        print(f"📝 Your message: \"{message}\"")
        print(f"🎯 Intent: {result.get('intent', 'Unknown')}")
        print(f"📊 Confidence: {result.get('confidence', 0):.1%}")
        print(f"🔐 Authentication required: {'Yes' if result.get('auth_required') else 'No'}")
        print(f"🔐 Authentication successful: {'Yes' if result.get('auth_successful') else 'No'}")
        print(f"👨‍💼 Human agent needed: {'Yes' if result.get('requires_human_agent') else 'No'}")
        
        if result.get('reasoning'):
            print(f"📋 Reasoning: {result['reasoning']}")
        
        print("-" * 50)
    
    def handle_real_system_response(self, message: str, result: Dict[str, Any]) -> None:
        """Handle the response from the REAL system."""
        
        # Check if authentication is required but not successful
        if result.get('auth_required') and not result.get('auth_successful'):
            print("🔐 I need to verify your identity to help with this request.")
            print("Let me authenticate you step by step...")
            
            # Use REAL authentication system
            auth_success = self.handle_real_authentication()
            
            if auth_success:
                # Re-process the original message now that we're authenticated
                print(f"\n🔄 Now that you're authenticated, let me process your request again...")
                authenticated_result = self.system.process_customer_message(
                    self.chat_session['authenticated_user']['user_id'], 
                    message
                )
                self.show_real_triage_agent_thinking(message, authenticated_result)
                self.display_real_agent_response(authenticated_result)
            else:
                # Authentication failed - show human handover
                print("❌ Authentication failed. Let me connect you with a human agent.")
                self.handle_human_handover(result)
        
        elif result.get('requires_human_agent'):
            # Direct human handover
            self.handle_human_handover(result)
        
        else:
            # Direct response from the system
            self.display_real_agent_response(result)
        
        # Store the message
        self.chat_session['messages'].append({
            'user': message,
            'result': result,
            'timestamp': datetime.now()
        })
    
    def handle_real_authentication(self) -> bool:
        """Handle authentication using the REAL authentication system."""
        # Load demo users for reference
        demo_users = self.load_demo_users()
        
        if not demo_users:
            print("❌ No demo users available for testing.")
            return False
        
        # Show available demo users
        print(f"\n💡 Demo users you can try:")
        for i, user in enumerate(demo_users[:5], 1):
            print(f"   {i}. {user['username']} ({user['user_id']})")
        
        # Step 1: Username
        print(f"\n📋 Step 1: Username")
        username = input("👤 Please enter your username: ").strip()
        
        # Find matching user
        matching_user = None
        for user in demo_users:
            if user['username'].lower() == username.lower():
                matching_user = user
                break
        
        if not matching_user:
            print(f"❌ Username '{username}' not found.")
            return False
        
        print(f"✅ Username verified: {matching_user['full_name']}")
        
        # Step 2: Password
        print(f"\n📋 Step 2: Password")
        password = input(f"🔐 Please enter your password: ").strip()
        
        # Use REAL authentication system - first attempt (should require email verification)
        try:
            print(f"\n🔐 Attempting authentication...")
            auth_result = self.system.authenticate_user(
                matching_user['user_id'],
                password
            )
            
            if auth_result.get('requires_email_verification'):
                print(f"\n📧 Email verification required!")
                print(f"✅ Password verified. Please check your email for verification code.")
                
                # Get the email token from the system
                email_token = auth_result.get('email_token')
                print(f"💡 For demo purposes, your verification code is: {email_token}")
                
                # Step 3: Email verification
                print(f"\n📋 Step 3: Email Verification")
                user_token = input(f"📧 Please enter the verification code from your email: ").strip()
                
                # Complete authentication with email token
                complete_auth = self.system.authenticate_user(
                    matching_user['user_id'],
                    password,
                    user_token
                )
                
                if complete_auth.get('success'):
                    print(f"\n🎉 Authentication successful!")
                    print(f"✅ Welcome back, {matching_user['full_name']}!")
                    print(f"⏰ Session valid for 3 minutes")
                    
                    # Store authenticated user
                    self.chat_session['authenticated_user'] = matching_user
                    self.chat_session['user_id'] = matching_user['user_id']
                    self.chat_session['session_id'] = complete_auth.get('session_id')
                    
                    return True
                else:
                    print(f"❌ Email verification failed: {complete_auth.get('error', 'Unknown error')}")
                    return False
                    
            elif auth_result.get('success'):
                print(f"\n🎉 Authentication successful!")
                print(f"✅ Welcome back, {matching_user['full_name']}!")
                print(f"⏰ Session valid for 3 minutes")
                
                # Store authenticated user
                self.chat_session['authenticated_user'] = matching_user
                self.chat_session['user_id'] = matching_user['user_id']
                self.chat_session['session_id'] = auth_result.get('session_id')
                
                return True
            else:
                print(f"❌ Authentication failed: {auth_result.get('error', 'Unknown error')}")
                return False
                
        except Exception as e:
            print(f"❌ Authentication error: {e}")
            return False
    
    def handle_human_handover(self, result: Dict[str, Any]) -> None:
        """Handle human agent handover using REAL system."""
        handover_data = result.get('human_handover', {})
        
        print(f"\n📞 HUMAN AGENT HANDOVER")
        print("-" * 30)
        print(f"📞 Contact: {handover_data.get('contact_number', '+91 998877654321')}")
        print(f"🆔 Reference ID: {handover_data.get('reference_id', 'N/A')}")
        print(f"📝 Reason: {handover_data.get('reason', 'Complex issue requiring human assistance')}")
        
        if handover_data.get('message'):
            print(f"💬 Message: {handover_data['message']}")
    
    def display_real_agent_response(self, result: Dict[str, Any]) -> None:
        """Display the response from the REAL agent system."""
        print(f"\n💬 AGENT RESPONSE:")
        print("-" * 30)
        
        # Show the actual response from the system
        response = result.get('response', 'I apologize, but I couldn\'t process your request.')
        print(f"🤖 {response}")
        
        # Show follow-up questions if any
        follow_ups = result.get('follow_up_questions', [])
        if follow_ups:
            print(f"\n❓ FOLLOW-UP QUESTIONS:")
            for i, question in enumerate(follow_ups, 1):
                print(f"   {i}. {question}")
        
        # Show any additional system information
        if result.get('chat_id'):
            print(f"\n📋 Chat ID: {result['chat_id']}")
        
        if result.get('session_id'):
            print(f"📊 Session ID: {result['session_id']}")
    
    def handle_fallback_response(self, message: str) -> None:
        """Handle fallback when system fails."""
        print(f"🤖 I apologize, but our system is experiencing issues.")
        print(f"I can still try to help you with basic questions.")
        
        # Simple fallback logic
        message_lower = message.lower()
        if any(word in message_lower for word in ['hello', 'hi', 'help']):
            print(f"🤖 Hello! I'm here to help. What do you need assistance with?")
        elif any(word in message_lower for word in ['hours', 'time', 'open']):
            print(f"🤖 Our business hours are Monday-Friday 9 AM - 6 PM.")
        else:
            print(f"🤖 I understand you're looking for help with: {message}")
            print(f"💡 Please try again in a moment, or call our customer care line.")
    
    def load_demo_users(self) -> List[Dict[str, Any]]:
        """Load demo users for testing."""
        try:
            with open('shared/fixtures/password_reference.json', 'r') as f:
                all_users = json.load(f)
            
            # Get random sample
            user_list = list(all_users.items())
            random.shuffle(user_list)
            demo_users = user_list[:10]
            
            formatted_users = []
            for user_id, creds in demo_users:
                formatted_users.append({
                    'user_id': user_id,
                    'username': creds.get('username', 'N/A'),
                    'email': creds.get('email', 'N/A'),
                    'password': creds.get('plain_password', 'N/A'),
                    'full_name': creds.get('full_name', 'N/A')
                })
            
            return formatted_users
            
        except Exception as e:
            print(f"❌ Error loading demo users: {e}")
            return []
