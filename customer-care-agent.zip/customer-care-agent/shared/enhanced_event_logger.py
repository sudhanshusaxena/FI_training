#!/usr/bin/env python3
"""
Enhanced Event Logging System
Comprehensive event tracking and analysis
"""

import json
import os
import uuid
from datetime import datetime
from typing import Dict, List, Any, Optional
import csv

class EnhancedEventLogger:
    """Enhanced event logging with comprehensive tracking and analysis."""
    
    def __init__(self, logs_dir: str = "logs"):
        self.logs_dir = logs_dir
        self.events_dir = os.path.join(logs_dir, "events")
        self.analytics_dir = os.path.join(logs_dir, "analytics")
        
        # Create directories
        os.makedirs(self.events_dir, exist_ok=True)
        os.makedirs(self.analytics_dir, exist_ok=True)
        
        # Event types
        self.event_types = {
            "user_interaction": "User sends message or performs action",
            "intent_classification": "Intent is classified by system",
            "authentication": "User authentication attempt",
            "agent_routing": "Request routed to specialized agent",
            "agent_response": "Agent generates response",
            "memory_operation": "Memory read/write operation",
            "hitl_trigger": "Human-in-the-loop triggered",
            "hitl_decision": "Human makes decision",
            "escalation": "Request escalated to human agent",
            "error": "System error occurred",
            "performance": "Performance metric recorded",
            "security": "Security-related event",
            "policy_check": "Policy compliance check",
            "evaluation": "Evaluation metric recorded"
        }
    
    def log_event(self, event_type: str, event_data: Dict[str, Any], 
                  user_id: str = None, session_id: str = None, chat_id: str = None,
                  trace_id: str = None, parent_event_id: str = None) -> str:
        """Log a comprehensive event."""
        
        # Generate event ID
        event_id = str(uuid.uuid4())
        
        # Create event record
        event = {
            "event_id": event_id,
            "trace_id": trace_id or str(uuid.uuid4()),
            "parent_event_id": parent_event_id,
            "timestamp": datetime.now().isoformat(),
            "event_type": event_type,
            "user_id": user_id,
            "session_id": session_id,
            "chat_id": chat_id,
            "data": event_data,
            "metadata": {
                "event_type_description": self.event_types.get(event_type, "Unknown event type"),
                "logged_at": datetime.now().isoformat()
            }
        }
        
        # Store in daily event file
        self._store_daily_event(event)
        
        # Store in trace file (if trace_id provided)
        if trace_id:
            self._store_trace_event(event)
        
        # Log to Matrix.csv for evaluation
        self._log_to_matrix_csv(event)
        
        # Log to analytics
        self._log_to_analytics(event)
        
        return event_id
    
    def _store_daily_event(self, event: Dict[str, Any]):
        """Store event in daily log file."""
        date_str = datetime.now().strftime("%Y-%m-%d")
        log_file = os.path.join(self.events_dir, f"events_{date_str}.jsonl")
        
        with open(log_file, 'a') as f:
            f.write(json.dumps(event) + '\n')
    
    def _store_trace_event(self, event: Dict[str, Any]):
        """Store event in trace-specific file."""
        trace_id = event["trace_id"]
        trace_file = os.path.join(self.events_dir, f"trace_{trace_id}.jsonl")
        
        with open(trace_file, 'a') as f:
            f.write(json.dumps(event) + '\n')
    
    def _log_to_matrix_csv(self, event: Dict[str, Any]):
        """Log event to Matrix.csv for evaluation."""
        matrix_file = "Matrix.csv"
        
        # Prepare row data
        row_data = {
            "timestamp": event["timestamp"],
            "event_id": event["event_id"],
            "trace_id": event.get("trace_id", ""),
            "event_type": event["event_type"],
            "user_id": event.get("user_id", ""),
            "session_id": event.get("session_id", ""),
            "chat_id": event.get("chat_id", ""),
            "intent": event.get("data", {}).get("intent", ""),
            "confidence": event.get("data", {}).get("confidence", 0.0),
            "auth_required": event.get("data", {}).get("auth_required", False),
            "auth_successful": event.get("data", {}).get("auth_successful", False),
            "agent_called": event.get("data", {}).get("agent_called", ""),
            "response_time_ms": event.get("data", {}).get("response_time_ms", 0),
            "user_satisfaction": event.get("data", {}).get("user_satisfaction", ""),
            "escalation_reason": event.get("data", {}).get("escalation_reason", ""),
            "memory_type": event.get("data", {}).get("memory_type", ""),
            "error_occurred": event.get("data", {}).get("error_occurred", False),
            "error_message": event.get("data", {}).get("error_message", ""),
            "success": event.get("data", {}).get("success", True),
            "performance_score": event.get("data", {}).get("performance_score", 0.0),
            "llm_judge_score": event.get("data", {}).get("llm_judge_score", 0.0),
            "llm_judge_reasoning": event.get("data", {}).get("llm_judge_reasoning", ""),
            "conversation_turn": event.get("data", {}).get("conversation_turn", 1),
            "total_tokens": event.get("data", {}).get("total_tokens", 0),
            "cost_estimate": event.get("data", {}).get("cost_estimate", 0.0)
        }
        
        # Check if file exists
        file_exists = os.path.exists(matrix_file)
        
        # Write to CSV
        with open(matrix_file, 'a', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=row_data.keys())
            if not file_exists:
                writer.writeheader()
            writer.writerow(row_data)
    
    def _log_to_analytics(self, event: Dict[str, Any]):
        """Log event to analytics for real-time monitoring."""
        date_str = datetime.now().strftime("%Y-%m-%d")
        analytics_file = os.path.join(self.analytics_dir, f"analytics_{date_str}.jsonl")
        
        # Create analytics record
        analytics_record = {
            "timestamp": event["timestamp"],
            "event_type": event["event_type"],
            "user_id": event.get("user_id"),
            "session_id": event.get("session_id"),
            "chat_id": event.get("chat_id"),
            "success": event.get("data", {}).get("success", True),
            "response_time_ms": event.get("data", {}).get("response_time_ms", 0),
            "intent": event.get("data", {}).get("intent", ""),
            "confidence": event.get("data", {}).get("confidence", 0.0),
            "agent_called": event.get("data", {}).get("agent_called", ""),
            "error_occurred": event.get("data", {}).get("error_occurred", False)
        }
        
        with open(analytics_file, 'a') as f:
            f.write(json.dumps(analytics_record) + '\n')
    
    def log_user_interaction(self, user_id: str, session_id: str, chat_id: str,
                           message: str, response: str, response_time_ms: int,
                           trace_id: str = None) -> str:
        """Log user interaction event."""
        event_data = {
            "message": message,
            "response": response,
            "response_time_ms": response_time_ms,
            "message_length": len(message),
            "response_length": len(response),
            "interaction_type": "chat_message"
        }
        
        return self.log_event(
            "user_interaction",
            event_data,
            user_id=user_id,
            session_id=session_id,
            chat_id=chat_id,
            trace_id=trace_id
        )
    
    def log_intent_classification(self, user_id: str, session_id: str, chat_id: str,
                                intent: str, confidence: float, reasoning: str,
                                trace_id: str = None) -> str:
        """Log intent classification event."""
        event_data = {
            "intent": intent,
            "confidence": confidence,
            "reasoning": reasoning,
            "classification_method": "llm_enhanced"
        }
        
        return self.log_event(
            "intent_classification",
            event_data,
            user_id=user_id,
            session_id=session_id,
            chat_id=chat_id,
            trace_id=trace_id
        )
    
    def log_authentication(self, user_id: str, session_id: str, chat_id: str,
                         auth_required: bool, auth_successful: bool, 
                         auth_method: str, attempts: int = 1,
                         trace_id: str = None) -> str:
        """Log authentication event."""
        event_data = {
            "auth_required": auth_required,
            "auth_successful": auth_successful,
            "auth_method": auth_method,
            "attempts": attempts,
            "success": auth_successful
        }
        
        return self.log_event(
            "authentication",
            event_data,
            user_id=user_id,
            session_id=session_id,
            chat_id=chat_id,
            trace_id=trace_id
        )
    
    def log_agent_routing(self, user_id: str, session_id: str, chat_id: str,
                         intent: str, agent_called: str, routing_successful: bool,
                         trace_id: str = None) -> str:
        """Log agent routing event."""
        event_data = {
            "intent": intent,
            "agent_called": agent_called,
            "routing_successful": routing_successful,
            "success": routing_successful
        }
        
        return self.log_event(
            "agent_routing",
            event_data,
            user_id=user_id,
            session_id=session_id,
            chat_id=chat_id,
            trace_id=trace_id
        )
    
    def log_agent_response(self, user_id: str, session_id: str, chat_id: str,
                          agent_name: str, response: str, response_time_ms: int,
                          success: bool, trace_id: str = None) -> str:
        """Log agent response event."""
        event_data = {
            "agent_name": agent_name,
            "response": response,
            "response_time_ms": response_time_ms,
            "response_length": len(response),
            "success": success,
            "agent_called": agent_name
        }
        
        return self.log_event(
            "agent_response",
            event_data,
            user_id=user_id,
            session_id=session_id,
            chat_id=chat_id,
            trace_id=trace_id
        )
    
    def log_hitl_trigger(self, user_id: str, session_id: str, chat_id: str,
                        trigger_reason: str, options_presented: List[Dict],
                        trace_id: str = None) -> str:
        """Log HITL trigger event."""
        event_data = {
            "trigger_reason": trigger_reason,
            "options_presented": options_presented,
            "options_count": len(options_presented)
        }
        
        return self.log_event(
            "hitl_trigger",
            event_data,
            user_id=user_id,
            session_id=session_id,
            chat_id=chat_id,
            trace_id=trace_id
        )
    
    def log_hitl_decision(self, user_id: str, session_id: str, chat_id: str,
                         decision: str, selected_option: str, reviewer_notes: str,
                         trace_id: str = None) -> str:
        """Log HITL decision event."""
        event_data = {
            "decision": decision,
            "selected_option": selected_option,
            "reviewer_notes": reviewer_notes,
            "success": decision.lower() in ["approve", "approved"]
        }
        
        return self.log_event(
            "hitl_decision",
            event_data,
            user_id=user_id,
            session_id=session_id,
            chat_id=chat_id,
            trace_id=trace_id
        )
    
    def log_escalation(self, user_id: str, session_id: str, chat_id: str,
                      escalation_reason: str, escalation_method: str,
                      customer_care_number: str, trace_id: str = None) -> str:
        """Log escalation event."""
        event_data = {
            "escalation_reason": escalation_reason,
            "escalation_method": escalation_method,
            "customer_care_number": customer_care_number,
            "success": True  # Escalation is considered successful
        }
        
        return self.log_event(
            "escalation",
            event_data,
            user_id=user_id,
            session_id=session_id,
            chat_id=chat_id,
            trace_id=trace_id
        )
    
    def log_error(self, user_id: str, session_id: str, chat_id: str,
                 error_type: str, error_message: str, error_details: Dict,
                 trace_id: str = None) -> str:
        """Log error event."""
        event_data = {
            "error_type": error_type,
            "error_message": error_message,
            "error_details": error_details,
            "error_occurred": True,
            "success": False
        }
        
        return self.log_event(
            "error",
            event_data,
            user_id=user_id,
            session_id=session_id,
            chat_id=chat_id,
            trace_id=trace_id
        )
    
    def log_performance(self, user_id: str, session_id: str, chat_id: str,
                       metric_name: str, metric_value: float, unit: str,
                       trace_id: str = None) -> str:
        """Log performance metric."""
        event_data = {
            "metric_name": metric_name,
            "metric_value": metric_value,
            "unit": unit,
            "performance_score": metric_value
        }
        
        return self.log_event(
            "performance",
            event_data,
            user_id=user_id,
            session_id=session_id,
            chat_id=chat_id,
            trace_id=trace_id
        )
    
    def log_evaluation(self, user_id: str, session_id: str, chat_id: str,
                      llm_judge_score: float, llm_judge_reasoning: str,
                      performance_score: float, conversation_turn: int,
                      trace_id: str = None) -> str:
        """Log evaluation metrics."""
        event_data = {
            "llm_judge_score": llm_judge_score,
            "llm_judge_reasoning": llm_judge_reasoning,
            "performance_score": performance_score,
            "conversation_turn": conversation_turn,
            "success": llm_judge_score >= 7.0  # Consider 7+ as success
        }
        
        return self.log_event(
            "evaluation",
            event_data,
            user_id=user_id,
            session_id=session_id,
            chat_id=chat_id,
            trace_id=trace_id
        )
    
    def get_analytics_summary(self, date_str: str = None) -> Dict[str, Any]:
        """Get analytics summary for a specific date."""
        if not date_str:
            date_str = datetime.now().strftime("%Y-%m-%d")
        
        analytics_file = os.path.join(self.analytics_dir, f"analytics_{date_str}.jsonl")
        
        if not os.path.exists(analytics_file):
            return {"error": "No analytics data found for date"}
        
        # Read analytics data
        events = []
        with open(analytics_file, 'r') as f:
            for line in f:
                events.append(json.loads(line.strip()))
        
        # Calculate summary statistics
        summary = {
            "date": date_str,
            "total_events": len(events),
            "event_types": {},
            "success_rate": 0.0,
            "average_response_time": 0.0,
            "total_users": 0,
            "total_sessions": 0,
            "total_chats": 0,
            "intents": {},
            "agents_called": {},
            "errors": 0
        }
        
        if not events:
            return summary
        
        # Calculate metrics
        successful_events = 0
        total_response_time = 0
        users = set()
        sessions = set()
        chats = set()
        
        for event in events:
            # Event types
            event_type = event.get("event_type", "unknown")
            summary["event_types"][event_type] = summary["event_types"].get(event_type, 0) + 1
            
            # Success rate
            if event.get("success", False):
                successful_events += 1
            
            # Response time
            if event.get("response_time_ms"):
                total_response_time += event["response_time_ms"]
            
            # Users, sessions, chats
            if event.get("user_id"):
                users.add(event["user_id"])
            if event.get("session_id"):
                sessions.add(event["session_id"])
            if event.get("chat_id"):
                chats.add(event["chat_id"])
            
            # Intents
            if event.get("intent"):
                intent = event["intent"]
                summary["intents"][intent] = summary["intents"].get(intent, 0) + 1
            
            # Agents called
            if event.get("agent_called"):
                agent = event["agent_called"]
                summary["agents_called"][agent] = summary["agents_called"].get(agent, 0) + 1
            
            # Errors
            if event.get("error_occurred", False):
                summary["errors"] += 1
        
        # Final calculations
        summary["success_rate"] = (successful_events / len(events)) * 100 if events else 0
        summary["average_response_time"] = total_response_time / len(events) if events else 0
        summary["total_users"] = len(users)
        summary["total_sessions"] = len(sessions)
        summary["total_chats"] = len(chats)
        
        return summary
    
    def get_trace_events(self, trace_id: str) -> List[Dict[str, Any]]:
        """Get all events for a specific trace."""
        trace_file = os.path.join(self.events_dir, f"trace_{trace_id}.jsonl")
        
        if not os.path.exists(trace_file):
            return []
        
        events = []
        with open(trace_file, 'r') as f:
            for line in f:
                events.append(json.loads(line.strip()))
        
        return sorted(events, key=lambda x: x.get("timestamp", ""))

# Global instance
enhanced_event_logger = EnhancedEventLogger()
