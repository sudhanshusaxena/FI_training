#!/usr/bin/env python3
"""
Enhanced Audit Logger for Customer Care Agent System
User-centric, chat-ID bound audit logging with comprehensive tracking
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Any, Optional
from pathlib import Path

class EnhancedAuditLogger:
    """Enhanced audit logging system with user-centric organization."""
    
    def __init__(self, audit_base_dir: str = "logs/audit"):
        self.audit_base_dir = audit_base_dir
        self.ensure_audit_directory()
    
    def ensure_audit_directory(self):
        """Ensure audit directory structure exists."""
        os.makedirs(self.audit_base_dir, exist_ok=True)
        os.makedirs(f"{self.audit_base_dir}/users", exist_ok=True)
        os.makedirs(f"{self.audit_base_dir}/system", exist_ok=True)
    
    def start_chat_session(self, user_id: str, chat_id: str, session_id: str, 
                          initial_message: str = None) -> Dict[str, Any]:
        """
        Start a new chat session audit log.
        
        Args:
            user_id: User ID
            chat_id: Unique chat ID
            session_id: Session ID
            initial_message: Initial user message
            
        Returns:
            Chat session metadata
        """
        user_dir = f"{self.audit_base_dir}/users/{user_id}"
        os.makedirs(user_dir, exist_ok=True)
        
        chat_metadata = {
            "chat_metadata": {
                "chat_id": chat_id,
                "user_id": user_id,
                "session_id": session_id,
                "start_time": datetime.now().isoformat(),
                "end_time": None,
                "duration_minutes": 0,
                "total_events": 0,
                "auth_required": False,
                "auth_successful": False,
                "intents_discussed": []
            },
            "events": [],
            "summary": {
                "total_events": 0,
                "authentication_events": 0,
                "conversation_events": 0,
                "system_events": 0,
                "data_accessed": [],
                "policies_referenced": [],
                "compliance_status": "compliant"
            }
        }
        
        # Add initial event if message provided
        if initial_message:
            initial_event = {
                "event_id": f"evt_{len(chat_metadata['events']) + 1:03d}",
                "timestamp": datetime.now().isoformat(),
                "event_type": "chat_started",
                "chat_id": chat_id,
                "user_id": user_id,
                "details": {
                    "initial_message": initial_message,
                    "ip_address": "127.0.0.1"  # Demo IP
                }
            }
            chat_metadata["events"].append(initial_event)
        
        # Save chat session log
        chat_file = f"{user_dir}/chat_{chat_id}.json"
        with open(chat_file, 'w') as f:
            json.dump(chat_metadata, f, indent=2)
        
        print(f"✅ Chat session audit started: {chat_id}")
        return chat_metadata
    
    def log_event(self, user_id: str, chat_id: str, event_type: str, 
                  details: Dict[str, Any]) -> bool:
        """
        Log an event to the chat session audit log.
        
        Args:
            user_id: User ID
            chat_id: Chat ID
            event_type: Type of event
            details: Event details
            
        Returns:
            True if logged successfully, False otherwise
        """
        try:
            user_dir = f"{self.audit_base_dir}/users/{user_id}"
            chat_file = f"{user_dir}/chat_{chat_id}.json"
            
            if not os.path.exists(chat_file):
                # Create new chat session if it doesn't exist
                self.start_chat_session(user_id, chat_id, details.get("session_id"))
            
            # Load existing chat log
            with open(chat_file, 'r') as f:
                chat_log = json.load(f)
            
            # Create new event
            event = {
                "event_id": f"evt_{len(chat_log['events']) + 1:03d}",
                "timestamp": datetime.now().isoformat(),
                "event_type": event_type,
                "chat_id": chat_id,
                "user_id": user_id,
                "details": details
            }
            
            # Add event to log
            chat_log["events"].append(event)
            
            # Update metadata
            chat_log["chat_metadata"]["total_events"] = len(chat_log["events"])
            
            # Update summary based on event type
            self._update_chat_summary(chat_log, event_type, details)
            
            # Save updated log
            with open(chat_file, 'w') as f:
                json.dump(chat_log, f, indent=2)
            
            return True
            
        except Exception as e:
            print(f"❌ Failed to log event: {e}")
            return False
    
    def end_chat_session(self, user_id: str, chat_id: str) -> Dict[str, Any]:
        """
        End a chat session and calculate final statistics.
        
        Args:
            user_id: User ID
            chat_id: Chat ID
            
        Returns:
            Final chat session summary
        """
        try:
            user_dir = f"{self.audit_base_dir}/users/{user_id}"
            chat_file = f"{user_dir}/chat_{chat_id}.json"
            
            if not os.path.exists(chat_file):
                return {"error": "Chat session not found"}
            
            # Load chat log
            with open(chat_file, 'r') as f:
                chat_log = json.load(f)
            
            # Calculate duration
            start_time = datetime.fromisoformat(chat_log["chat_metadata"]["start_time"])
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds() / 60
            
            # Update metadata
            chat_log["chat_metadata"]["end_time"] = end_time.isoformat()
            chat_log["chat_metadata"]["duration_minutes"] = round(duration, 2)
            
            # Update user audit summary
            self._update_user_audit_summary(user_id, chat_log)
            
            # Save updated log
            with open(chat_file, 'w') as f:
                json.dump(chat_log, f, indent=2)
            
            print(f"✅ Chat session audit ended: {chat_id}")
            return chat_log["summary"]
            
        except Exception as e:
            print(f"❌ Failed to end chat session: {e}")
            return {"error": str(e)}
    
    def _update_chat_summary(self, chat_log: Dict[str, Any], event_type: str, details: Dict[str, Any]):
        """Update chat summary based on event type."""
        summary = chat_log["summary"]
        
        # Count events by type
        if "auth" in event_type.lower():
            summary["authentication_events"] += 1
        elif event_type in ["conversation", "message", "response"]:
            summary["conversation_events"] += 1
        else:
            summary["system_events"] += 1
        
        # Track data access
        if "data_accessed" in details:
            summary["data_accessed"].extend(details["data_accessed"])
        
        # Track policy references
        if "policy_referenced" in details:
            summary["policies_referenced"].append(details["policy_referenced"])
        
        # Update intents discussed
        if "intent" in details:
            intent = details["intent"]
            if intent not in chat_log["chat_metadata"]["intents_discussed"]:
                chat_log["chat_metadata"]["intents_discussed"].append(intent)
        
        # Update authentication status
        if event_type == "multi_factor_auth":
            chat_log["chat_metadata"]["auth_required"] = True
            if details.get("success"):
                chat_log["chat_metadata"]["auth_successful"] = True
    
    def _update_user_audit_summary(self, user_id: str, chat_log: Dict[str, Any]):
        """Update user audit summary."""
        user_dir = f"{self.audit_base_dir}/users/{user_id}"
        summary_file = f"{user_dir}/user_audit_summary.json"
        
        # Load existing summary or create new one
        if os.path.exists(summary_file):
            with open(summary_file, 'r') as f:
                user_summary = json.load(f)
        else:
            user_summary = {
                "user_id": user_id,
                "audit_summary": {
                    "total_chats": 0,
                    "first_chat": None,
                    "last_chat": None,
                    "total_authentication_attempts": 0,
                    "successful_authentications": 0,
                    "failed_authentications": 0,
                    "average_session_duration": 0,
                    "most_common_intents": [],
                    "compliance_score": 1.0
                },
                "chat_history": [],
                "security_events": [],
                "data_access_patterns": {
                    "orders_accessed": [],
                    "personal_data_accessed": False,
                    "payment_data_accessed": False,
                    "last_data_access": None
                }
            }
        
        # Update summary with new chat data
        chat_metadata = chat_log["chat_metadata"]
        
        # Update basic stats
        user_summary["audit_summary"]["total_chats"] += 1
        user_summary["audit_summary"]["last_chat"] = chat_metadata["start_time"]
        
        if user_summary["audit_summary"]["first_chat"] is None:
            user_summary["audit_summary"]["first_chat"] = chat_metadata["start_time"]
        
        # Update authentication stats
        auth_events = [e for e in chat_log["events"] if "auth" in e["event_type"].lower()]
        user_summary["audit_summary"]["total_authentication_attempts"] += len(auth_events)
        
        if chat_metadata["auth_successful"]:
            user_summary["audit_summary"]["successful_authentications"] += 1
        else:
            user_summary["audit_summary"]["failed_authentications"] += 1
        
        # Update session duration
        duration = chat_metadata["duration_minutes"]
        current_avg = user_summary["audit_summary"]["average_session_duration"]
        total_chats = user_summary["audit_summary"]["total_chats"]
        
        if total_chats == 1:
            user_summary["audit_summary"]["average_session_duration"] = duration
        else:
            user_summary["audit_summary"]["average_session_duration"] = (
                (current_avg * (total_chats - 1) + duration) / total_chats
            )
        
        # Update intents
        for intent in chat_metadata["intents_discussed"]:
            if intent not in user_summary["audit_summary"]["most_common_intents"]:
                user_summary["audit_summary"]["most_common_intents"].append(intent)
        
        # Add chat to history
        chat_history_entry = {
            "chat_id": chat_metadata["chat_id"],
            "date": chat_metadata["start_time"][:10],
            "duration": f"{duration:.1f} minutes",
            "intents": chat_metadata["intents_discussed"],
            "auth_required": chat_metadata["auth_required"],
            "compliance_status": chat_log["summary"]["compliance_status"]
        }
        
        user_summary["chat_history"].insert(0, chat_history_entry)
        
        # Keep only last 10 chats in history
        user_summary["chat_history"] = user_summary["chat_history"][:10]
        
        # Update data access patterns
        data_accessed = chat_log["summary"]["data_accessed"]
        for data_item in data_accessed:
            if data_item.startswith("order_"):
                if data_item not in user_summary["data_access_patterns"]["orders_accessed"]:
                    user_summary["data_access_patterns"]["orders_accessed"].append(data_item)
        
        if data_accessed:
            user_summary["data_access_patterns"]["personal_data_accessed"] = True
            user_summary["data_access_patterns"]["last_data_access"] = datetime.now().isoformat()
        
        # Save updated summary
        with open(summary_file, 'w') as f:
            json.dump(user_summary, f, indent=2)
    
    def get_user_audit_summary(self, user_id: str) -> Dict[str, Any]:
        """Get comprehensive audit summary for a user."""
        user_dir = f"{self.audit_base_dir}/users/{user_id}"
        summary_file = f"{user_dir}/user_audit_summary.json"
        
        if os.path.exists(summary_file):
            with open(summary_file, 'r') as f:
                return json.load(f)
        else:
            return {"error": "User audit summary not found"}
    
    def get_chat_audit_log(self, user_id: str, chat_id: str) -> Dict[str, Any]:
        """Get audit log for a specific chat session."""
        user_dir = f"{self.audit_base_dir}/users/{user_id}"
        chat_file = f"{user_dir}/chat_{chat_id}.json"
        
        if os.path.exists(chat_file):
            with open(chat_file, 'r') as f:
                return json.load(f)
        else:
            return {"error": "Chat audit log not found"}
    
    def get_audit_stats(self) -> Dict[str, Any]:
        """Get overall audit system statistics."""
        stats = {
            "total_users": 0,
            "total_chats": 0,
            "total_events": 0,
            "average_events_per_chat": 0,
            "most_active_users": [],
            "recent_activity": []
        }
        
        try:
            users_dir = f"{self.audit_base_dir}/users"
            if os.path.exists(users_dir):
                user_dirs = [d for d in os.listdir(users_dir) if os.path.isdir(os.path.join(users_dir, d))]
                stats["total_users"] = len(user_dirs)
                
                user_chat_counts = {}
                total_events = 0
                
                for user_dir in user_dirs:
                    user_path = os.path.join(users_dir, user_dir)
                    chat_files = [f for f in os.listdir(user_path) if f.startswith("chat_") and f.endswith(".json")]
                    
                    user_chat_counts[user_dir] = len(chat_files)
                    stats["total_chats"] += len(chat_files)
                    
                    # Count events for this user
                    for chat_file in chat_files:
                        chat_path = os.path.join(user_path, chat_file)
                        try:
                            with open(chat_path, 'r') as f:
                                chat_log = json.load(f)
                                total_events += len(chat_log.get("events", []))
                        except:
                            continue
                
                stats["total_events"] = total_events
                stats["average_events_per_chat"] = (
                    total_events / stats["total_chats"] if stats["total_chats"] > 0 else 0
                )
                
                # Most active users
                stats["most_active_users"] = sorted(
                    user_chat_counts.items(), 
                    key=lambda x: x[1], 
                    reverse=True
                )[:5]
        
        except Exception as e:
            print(f"❌ Failed to get audit stats: {e}")
        
        return stats

def test_enhanced_audit_logger():
    """Test the enhanced audit logger."""
    print("🧪 Testing Enhanced Audit Logger...")
    
    # Initialize audit logger
    audit_logger = EnhancedAuditLogger("logs/audit")
    
    # Test chat session start
    user_id = "u_1001"
    chat_id = "chat_test_001"
    session_id = "sess_test_001"
    
    chat_metadata = audit_logger.start_chat_session(user_id, chat_id, session_id, "Hello, I need help")
    print(f"✅ Chat session started: {chat_metadata['chat_metadata']['chat_id']}")
    
    # Test event logging
    events_to_log = [
        ("llm_triage", {"intent": "order_status", "confidence": 0.9}),
        ("auth_requirement_check", {"auth_required": True, "auth_level_required": 1}),
        ("multi_factor_auth", {"success": True, "attempts": 1}),
        ("intent_routing", {"agent": "order_status_agent", "data_accessed": ["order_o_2001"]}),
        ("response_generation", {"response_length": 150, "follow_up_count": 2})
    ]
    
    for event_type, details in events_to_log:
        details["session_id"] = session_id
        success = audit_logger.log_event(user_id, chat_id, event_type, details)
        print(f"✅ Event logged: {event_type} - {'PASSED' if success else 'FAILED'}")
    
    # Test chat session end
    summary = audit_logger.end_chat_session(user_id, chat_id)
    print(f"✅ Chat session ended: {summary}")
    
    # Test user audit summary
    user_summary = audit_logger.get_user_audit_summary(user_id)
    print(f"✅ User audit summary: {user_summary['audit_summary']['total_chats']} chats")
    
    # Test audit stats
    stats = audit_logger.get_audit_stats()
    print(f"✅ Audit stats: {stats['total_users']} users, {stats['total_chats']} chats")
    
    print("🎉 Enhanced audit logger tests completed!")

if __name__ == "__main__":
    test_enhanced_audit_logger()
