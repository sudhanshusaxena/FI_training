#!/usr/bin/env python3
"""
Specialized Agents for Customer Care System
Real agent implementations that actually process requests
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Any, Optional

class BaseAgent:
    """Base class for all specialized agents."""
    
    def __init__(self, agent_name: str):
        self.agent_name = agent_name
        self.response_history = []
    
    def process_request(self, user_id: str, intent: str, message: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Process a user request and return agent response."""
        raise NotImplementedError("Subclasses must implement process_request")
    
    def log_interaction(self, user_id: str, request: str, response: str, metadata: Dict[str, Any]):
        """Log agent interactions for audit purposes."""
        interaction = {
            "timestamp": datetime.now().isoformat(),
            "user_id": user_id,
            "agent": self.agent_name,
            "request": request,
            "response": response,
            "metadata": metadata
        }
        self.response_history.append(interaction)
        
        # Save to file for audit
        self._save_to_audit_log(interaction)
    
    def _save_to_audit_log(self, interaction: Dict[str, Any]):
        """Save interaction to audit log file."""
        audit_file = f"logs/agent_audit_{self.agent_name}.jsonl"
        os.makedirs(os.path.dirname(audit_file), exist_ok=True)
        
        with open(audit_file, "a") as f:
            f.write(json.dumps(interaction) + "\n")

class OrderStatusAgent(BaseAgent):
    """Specialized agent for handling order status inquiries."""
    
    def __init__(self):
        super().__init__("order_status_agent")
        self.load_order_data()
    
    def load_order_data(self):
        """Load order data from fixtures."""
        try:
            with open('shared/fixtures/orders.json', 'r') as f:
                data = json.load(f)
                # Handle both list and object formats
                if isinstance(data, list):
                    orders_list = data
                else:
                    orders_list = data.get("orders", [])
                self.orders = {order["order_id"]: order for order in orders_list}
        except (FileNotFoundError, json.JSONDecodeError, KeyError) as e:
            print(f"Error loading orders: {e}")
            self.orders = {}
    
    def process_request(self, user_id: str, intent: str, message: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Process order status request."""
        try:
            # Extract order number from message or context
            order_number = self._extract_order_number(message, context)
            
            if not order_number:
                response = self._handle_no_order_number()
            else:
                response = self._handle_order_lookup(order_number, user_id)
            
            # Log the interaction
            self.log_interaction(user_id, message, response["response"], {
                "order_number": order_number,
                "intent": intent
            })
            
            return response
            
        except Exception as e:
            error_response = {
                "response": f"I apologize, but I encountered an error while processing your order status request: {str(e)}",
                "agent": self.agent_name,
                "success": False,
                "metadata": {"error": str(e)}
            }
            
            self.log_interaction(user_id, message, error_response["response"], {"error": str(e)})
            return error_response
    
    def _extract_order_number(self, message: str, context: Dict[str, Any]) -> Optional[str]:
        """Extract order number from message or context."""
        # Check context first
        if context.get("order_number"):
            return context["order_number"]
        
        # Try to extract from message
        import re
        order_patterns = [
            r'order\s*#?(\w+)',
            r'order\s*number\s*(\w+)',
            r'order\s*id\s*(\w+)',
            r'#(\w+)'
        ]
        
        message_lower = message.lower()
        for pattern in order_patterns:
            match = re.search(pattern, message_lower)
            if match:
                return match.group(1).upper()
        
        return None
    
    def _handle_no_order_number(self) -> Dict[str, Any]:
        """Handle case where no order number is provided."""
        return {
            "response": "I'd be happy to help you with your order status! To look up your order, I'll need your order number. You can find it in your order confirmation email or on your account dashboard. Could you please provide your order number?",
            "agent": self.agent_name,
            "success": True,
            "metadata": {"requires_order_number": True},
            "follow_up_questions": [
                "What is your order number?",
                "Do you have your order confirmation email?",
                "Would you like me to check all your recent orders?"
            ]
        }
    
    def _handle_order_lookup(self, order_number: str, user_id: str) -> Dict[str, Any]:
        """Handle order lookup with provided order number."""
        order = self.orders.get(order_number)
        
        if not order:
            return {
                "response": f"I couldn't find an order with number {order_number}. Please double-check the order number and try again. Order numbers are typically 5-8 characters long and can contain letters and numbers.",
                "agent": self.agent_name,
                "success": False,
                "metadata": {"order_not_found": True},
                "follow_up_questions": [
                    "Could you check your order number again?",
                    "Would you like me to search for recent orders?",
                    "Do you have the order confirmation email?"
                ]
            }
        
        # Format order status response
        status = order.get("status", "Unknown")
        tracking = order.get("tracking_number", "Not available")
        estimated_delivery = order.get("estimated_delivery", "Not available")
        
        response_text = f"Here's the status of your order {order_number}:\n\n"
        response_text += f"📦 **Order Status**: {status}\n"
        response_text += f"🚚 **Tracking Number**: {tracking}\n"
        response_text += f"📅 **Estimated Delivery**: {estimated_delivery}\n"
        
        if status.lower() == "shipped":
            response_text += f"\nYour order is on its way! You can track it using the tracking number above."
        elif status.lower() == "delivered":
            response_text += f"\nYour order has been delivered! I hope you're enjoying your purchase."
        elif status.lower() == "processing":
            response_text += f"\nYour order is being prepared for shipment. We'll send you tracking information once it ships."
        
        return {
            "response": response_text,
            "agent": self.agent_name,
            "success": True,
            "metadata": {
                "order_found": True,
                "order_status": status,
                "tracking_number": tracking
            },
            "follow_up_questions": [
                "Is there anything else I can help you with regarding this order?",
                "Would you like to track another order?",
                "Do you have any questions about the delivery?"
            ]
        }

class RefundsAgent(BaseAgent):
    """Specialized agent for handling refund requests."""
    
    def __init__(self):
        super().__init__("refunds_agent")
        self.load_refund_policy()
    
    def load_refund_policy(self):
        """Load refund policy from SOPs."""
        try:
            with open('shared/sops/refunds_policy_v2024-07-01.md', 'r') as f:
                self.refund_policy = f.read()
        except FileNotFoundError:
            self.refund_policy = "Standard 30-day refund policy applies."
    
    def process_request(self, user_id: str, intent: str, message: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Process refund request."""
        try:
            # Extract refund details
            refund_details = self._extract_refund_details(message, context)
            
            if not refund_details.get("order_number"):
                response = self._handle_no_order_number()
            else:
                response = self._handle_refund_request(refund_details, user_id)
            
            # Log the interaction
            self.log_interaction(user_id, message, response["response"], {
                "refund_details": refund_details,
                "intent": intent
            })
            
            return response
            
        except Exception as e:
            error_response = {
                "response": f"I apologize, but I encountered an error while processing your refund request: {str(e)}",
                "agent": self.agent_name,
                "success": False,
                "metadata": {"error": str(e)}
            }
            
            self.log_interaction(user_id, message, error_response["response"], {"error": str(e)})
            return error_response
    
    def _extract_refund_details(self, message: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Extract refund details from message."""
        details = {
            "order_number": context.get("order_number"),
            "reason": context.get("reason"),
            "items": context.get("items", [])
        }
        
        # Try to extract from message
        import re
        
        # Extract order number
        if not details["order_number"]:
            order_match = re.search(r'order\s*#?(\w+)', message.lower())
            if order_match:
                details["order_number"] = order_match.group(1).upper()
        
        # Extract reason
        if not details["reason"]:
            reason_keywords = ["defective", "wrong", "damaged", "not working", "broken", "change mind"]
            for keyword in reason_keywords:
                if keyword in message.lower():
                    details["reason"] = keyword
                    break
        
        return details
    
    def _handle_no_order_number(self) -> Dict[str, Any]:
        """Handle case where no order number is provided."""
        return {
            "response": "I'd be happy to help you with your refund request! To process a refund, I'll need some information from you:\n\n1. **Order number** - You can find this in your order confirmation email\n2. **Reason for refund** - Please let me know why you'd like to return the item\n3. **Items to return** - Which specific items from the order?\n\nCould you please provide your order number to get started?",
            "agent": self.agent_name,
            "success": True,
            "metadata": {"requires_order_number": True},
            "follow_up_questions": [
                "What is your order number?",
                "What is the reason for the refund?",
                "Which items would you like to return?"
            ]
        }
    
    def _handle_refund_request(self, refund_details: Dict[str, Any], user_id: str) -> Dict[str, Any]:
        """Handle refund request with provided details."""
        order_number = refund_details["order_number"]
        reason = refund_details.get("reason", "Not specified")
        
        # Check refund eligibility
        eligibility = self._check_refund_eligibility(order_number, reason)
        
        if eligibility["eligible"]:
            response_text = f"Thank you for your refund request for order {order_number}.\n\n"
            response_text += f"📋 **Refund Details**:\n"
            response_text += f"   • Order: {order_number}\n"
            response_text += f"   • Reason: {reason}\n"
            response_text += f"   • Status: Approved\n\n"
            response_text += f"🔄 **Next Steps**:\n"
            response_text += f"   1. Return label will be sent to your email within 24 hours\n"
            response_text += f"   2. Please package the item securely\n"
            response_text += f"   3. Drop off at any authorized location\n"
            response_text += f"   4. Refund will be processed within 5-7 business days after receipt\n\n"
            response_text += f"📧 **Confirmation**: Refund request #{order_number}-REF has been created."
            
            return {
                "response": response_text,
                "agent": self.agent_name,
                "success": True,
                "metadata": {
                    "refund_approved": True,
                    "refund_id": f"{order_number}-REF",
                    "reason": reason
                },
                "follow_up_questions": [
                    "Do you have any questions about the return process?",
                    "Would you like me to send you the return label now?",
                    "Is there anything else I can help you with?"
                ]
            }
        else:
            return {
                "response": f"I'm sorry, but order {order_number} is not eligible for a refund. {eligibility['reason']}",
                "agent": self.agent_name,
                "success": False,
                "metadata": {
                    "refund_denied": True,
                    "reason": eligibility["reason"]
                },
                "follow_up_questions": [
                    "Would you like to speak with a supervisor?",
                    "Is there anything else I can help you with?",
                    "Would you like to exchange the item instead?"
                ]
            }
    
    def _check_refund_eligibility(self, order_number: str, reason: str) -> Dict[str, Any]:
        """Check if order is eligible for refund."""
        # Simulate refund eligibility check
        # In a real system, this would check order date, status, etc.
        
        if reason.lower() in ["defective", "damaged", "not working", "broken"]:
            return {"eligible": True, "reason": "Product defect refund approved."}
        elif reason.lower() == "change mind":
            return {"eligible": True, "reason": "30-day return policy applies."}
        else:
            return {"eligible": False, "reason": "Order is outside the 30-day refund window."}

class TroubleshootingAgent(BaseAgent):
    """Specialized agent for handling technical troubleshooting."""
    
    def __init__(self):
        super().__init__("troubleshooting_agent")
        self.load_troubleshooting_kb()
    
    def load_troubleshooting_kb(self):
        """Load troubleshooting knowledge base."""
        try:
            with open('shared/faq/general_faq.md', 'r') as f:
                self.knowledge_base = f.read()
        except FileNotFoundError:
            self.knowledge_base = "Basic troubleshooting information available."
    
    def process_request(self, user_id: str, intent: str, message: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Process troubleshooting request."""
        try:
            # Extract problem details
            problem_details = self._extract_problem_details(message, context)
            
            # Generate troubleshooting steps
            response = self._generate_troubleshooting_steps(problem_details, user_id)
            
            # Log the interaction
            self.log_interaction(user_id, message, response["response"], {
                "problem_details": problem_details,
                "intent": intent
            })
            
            return response
            
        except Exception as e:
            error_response = {
                "response": f"I apologize, but I encountered an error while processing your troubleshooting request: {str(e)}",
                "agent": self.agent_name,
                "success": False,
                "metadata": {"error": str(e)}
            }
            
            self.log_interaction(user_id, message, error_response["response"], {"error": str(e)})
            return error_response
    
    def _extract_problem_details(self, message: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Extract problem details from message."""
        details = {
            "device_type": context.get("device_type"),
            "problem": context.get("problem"),
            "error_message": context.get("error_message"),
            "symptoms": context.get("symptoms", [])
        }
        
        # Try to extract from message
        message_lower = message.lower()
        
        # Extract device type
        if not details["device_type"]:
            device_keywords = {
                "phone": ["phone", "mobile", "cellphone"],
                "laptop": ["laptop", "computer", "pc"],
                "tablet": ["tablet", "ipad"],
                "watch": ["watch", "smartwatch"],
                "headphones": ["headphones", "earbuds", "headset"]
            }
            
            for device_type, keywords in device_keywords.items():
                if any(keyword in message_lower for keyword in keywords):
                    details["device_type"] = device_type
                    break
        
        # Extract problem description
        if not details["problem"]:
            problem_keywords = ["not working", "broken", "frozen", "slow", "crashing", "error", "issue"]
            for keyword in problem_keywords:
                if keyword in message_lower:
                    details["problem"] = keyword
                    break
        
        return details
    
    def _generate_troubleshooting_steps(self, problem_details: Dict[str, Any], user_id: str) -> Dict[str, Any]:
        """Generate troubleshooting steps based on problem details."""
        device_type = problem_details.get("device_type", "device")
        problem = problem_details.get("problem", "issue")
        
        # Generate device-specific troubleshooting steps
        if device_type == "phone":
            steps = self._get_phone_troubleshooting_steps(problem)
        elif device_type == "laptop":
            steps = self._get_laptop_troubleshooting_steps(problem)
        elif device_type == "tablet":
            steps = self._get_tablet_troubleshooting_steps(problem)
        else:
            steps = self._get_general_troubleshooting_steps(problem)
        
        response_text = f"I'll help you troubleshoot your {device_type} issue!\n\n"
        response_text += f"🔧 **Troubleshooting Steps**:\n\n"
        
        for i, step in enumerate(steps, 1):
            response_text += f"{i}. {step}\n"
        
        response_text += f"\n💡 **Additional Tips**:\n"
        response_text += f"   • Try each step in order\n"
        response_text += f"   • Wait 30 seconds between steps\n"
        response_text += f"   • Let me know if any step doesn't work\n\n"
        response_text += f"Did any of these steps resolve your issue?"
        
        return {
            "response": response_text,
            "agent": self.agent_name,
            "success": True,
            "metadata": {
                "device_type": device_type,
                "problem": problem,
                "steps_provided": len(steps)
            },
            "follow_up_questions": [
                "Did the troubleshooting steps help?",
                "Are you still experiencing the same issue?",
                "Would you like me to escalate this to technical support?",
                "Do you need help with any specific step?"
            ]
        }
    
    def _get_phone_troubleshooting_steps(self, problem: str) -> List[str]:
        """Get phone-specific troubleshooting steps."""
        if problem in ["not working", "frozen"]:
            return [
                "Try restarting your phone by holding the power button for 10 seconds",
                "Check if your phone has sufficient battery (at least 20%)",
                "Remove and reinsert the SIM card if applicable",
                "Try connecting to a different Wi-Fi network",
                "Check for available software updates in Settings"
            ]
        elif problem == "slow":
            return [
                "Close all background apps by swiping up and closing them",
                "Restart your phone to clear temporary files",
                "Check available storage space (should be at least 1GB free)",
                "Disable unnecessary notifications and background app refresh",
                "Update to the latest software version"
            ]
        else:
            return [
                "Restart your phone by holding the power button",
                "Check your internet connection",
                "Update your apps from the app store",
                "Clear app cache in Settings > Apps",
                "Reset network settings if connectivity is the issue"
            ]
    
    def _get_laptop_troubleshooting_steps(self, problem: str) -> List[str]:
        """Get laptop-specific troubleshooting steps."""
        if problem in ["not working", "crashing"]:
            return [
                "Perform a hard restart by holding the power button for 10 seconds",
                "Check if the laptop is properly plugged in and charging",
                "Try booting in Safe Mode (hold Shift while restarting)",
                "Run a system diagnostic check",
                "Check for Windows/Mac updates"
            ]
        elif problem == "slow":
            return [
                "Close unnecessary programs and browser tabs",
                "Restart your laptop to clear memory",
                "Check available disk space (should be at least 10GB free)",
                "Run disk cleanup and defragmentation",
                "Disable startup programs you don't need"
            ]
        else:
            return [
                "Restart your laptop completely",
                "Check all cable connections",
                "Update your operating system",
                "Run antivirus scan",
                "Check device manager for hardware issues"
            ]
    
    def _get_tablet_troubleshooting_steps(self, problem: str) -> List[str]:
        """Get tablet-specific troubleshooting steps."""
        return [
            "Restart your tablet by holding the power button for 10 seconds",
            "Check battery level and ensure it's charging properly",
            "Close all apps by swiping up from the bottom",
            "Check available storage space",
            "Update your tablet's software to the latest version"
        ]
    
    def _get_general_troubleshooting_steps(self, problem: str) -> List[str]:
        """Get general troubleshooting steps."""
        return [
            "Turn the device off and on again",
            "Check all connections and cables",
            "Ensure the device has sufficient power",
            "Try using the device in a different location",
            "Contact technical support if the issue persists"
        ]

class SalesAgent(BaseAgent):
    """Specialized agent for handling sales and upsell requests."""
    
    def __init__(self):
        super().__init__("sales_agent")
        self.load_product_catalog()
    
    def load_product_catalog(self):
        """Load product catalog data."""
        # Simulate product catalog
        self.products = {
            "phone": {
                "name": "Premium Smartphone",
                "price": 699.99,
                "features": ["5G connectivity", "128GB storage", "Triple camera"]
            },
            "laptop": {
                "name": "Professional Laptop",
                "price": 1299.99,
                "features": ["Intel i7 processor", "16GB RAM", "512GB SSD"]
            },
            "tablet": {
                "name": "High-Performance Tablet",
                "price": 499.99,
                "features": ["10-inch display", "64GB storage", "All-day battery"]
            }
        }
    
    def process_request(self, user_id: str, intent: str, message: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Process sales request."""
        try:
            # Extract product interest
            product_interest = self._extract_product_interest(message, context)
            
            # Generate sales response
            response = self._generate_sales_response(product_interest, user_id)
            
            # Log the interaction
            self.log_interaction(user_id, message, response["response"], {
                "product_interest": product_interest,
                "intent": intent
            })
            
            return response
            
        except Exception as e:
            error_response = {
                "response": f"I apologize, but I encountered an error while processing your sales inquiry: {str(e)}",
                "agent": self.agent_name,
                "success": False,
                "metadata": {"error": str(e)}
            }
            
            self.log_interaction(user_id, message, error_response["response"], {"error": str(e)})
            return error_response
    
    def _extract_product_interest(self, message: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Extract product interest from message."""
        interest = {
            "product_type": context.get("product_type"),
            "budget": context.get("budget"),
            "features": context.get("features", [])
        }
        
        # Try to extract from message
        message_lower = message.lower()
        
        # Extract product type
        if not interest["product_type"]:
            for product_type in self.products.keys():
                if product_type in message_lower:
                    interest["product_type"] = product_type
                    break
        
        return interest
    
    def _generate_sales_response(self, product_interest: Dict[str, Any], user_id: str) -> Dict[str, Any]:
        """Generate sales response based on interest."""
        product_type = product_interest.get("product_type")
        
        if product_type and product_type in self.products:
            product = self.products[product_type]
            
            response_text = f"Great choice! I'd love to tell you about our {product['name']}.\n\n"
            response_text += f"💰 **Price**: ${product['price']}\n\n"
            response_text += f"✨ **Key Features**:\n"
            for feature in product['features']:
                response_text += f"   • {feature}\n"
            
            response_text += f"\n🎯 **Why Choose This Product**:\n"
            response_text += f"   • Premium quality and performance\n"
            response_text += f"   • 2-year manufacturer warranty\n"
            response_text += f"   • Free shipping and setup\n"
            response_text += f"   • 30-day return policy\n\n"
            response_text += f"Would you like me to check availability or answer any questions about this product?"
            
            return {
                "response": response_text,
                "agent": self.agent_name,
                "success": True,
                "metadata": {
                    "product_recommended": product_type,
                    "price": product['price']
                },
                "follow_up_questions": [
                    "Would you like to purchase this product?",
                    "Do you have any questions about the features?",
                    "Would you like to compare with other models?",
                    "Are you interested in our financing options?"
                ]
            }
        else:
            # General sales response
            response_text = "I'd be happy to help you find the perfect product! We have a great selection of:\n\n"
            response_text += "📱 **Smartphones** - Latest models with 5G connectivity\n"
            response_text += "💻 **Laptops** - Professional and gaming options\n"
            response_text += "📱 **Tablets** - Perfect for work and entertainment\n"
            response_text += "⌚ **Smartwatches** - Health and fitness tracking\n"
            response_text += "🎧 **Audio** - Headphones and speakers\n\n"
            response_text += "What type of device are you looking for? I can provide detailed information and help you choose the best option for your needs and budget."
            
            return {
                "response": response_text,
                "agent": self.agent_name,
                "success": True,
                "metadata": {"general_inquiry": True},
                "follow_up_questions": [
                    "What type of device are you interested in?",
                    "What's your budget range?",
                    "What features are most important to you?",
                    "Are you looking for something specific?"
                ]
            }

# Agent Registry
AGENT_REGISTRY = {
    "order_status": OrderStatusAgent(),
    "refunds": RefundsAgent(),
    "troubleshooting": TroubleshootingAgent(),
    "sales": SalesAgent()
}

def get_agent(agent_name: str) -> Optional[BaseAgent]:
    """Get agent instance by name."""
    return AGENT_REGISTRY.get(agent_name)

def list_available_agents() -> List[str]:
    """List all available agents."""
    return list(AGENT_REGISTRY.keys())
