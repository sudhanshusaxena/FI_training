# Audit Logger - Customer Care Agent
"""
Comprehensive audit logging system for compliance, monitoring, and replay capabilities.
Handles event logging, PII sanitization, and trace management.
"""

import json
import logging
import hashlib
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict
from pathlib import Path
from enum import Enum
import threading
import queue

class EventType(Enum):
    """Audit event types."""
    MESSAGE_RECEIVED = "message_received"
    MESSAGE_SENT = "message_sent"
    TRIAGE_RESULT = "triage_result"
    AUTH_ATTEMPT = "auth_attempt"
    AUTH_SUCCESS = "auth_success"
    AUTH_FAILURE = "auth_failure"
    TOOL_CALL_START = "tool_call_start"
    TOOL_CALL_END = "tool_call_end"
    POLICY_CHECK = "policy_check"
    POLICY_DECISION = "policy_decision"
    HITL_REQUEST = "hitl_request"
    HITL_DECISION = "hitl_decision"
    GUARDRAILS_SCAN = "guardrails_scan"
    MEMORY_READ = "memory_read"
    MEMORY_WRITE = "memory_write"
    ERROR = "error"
    SYSTEM_START = "system_start"
    SYSTEM_STOP = "system_stop"

class SeverityLevel(Enum):
    """Log severity levels."""
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"

@dataclass
class AuditEvent:
    """Individual audit event structure."""
    event_id: str
    event_type: EventType
    severity: SeverityLevel
    timestamp: str
    trace_id: str
    session_id: Optional[str]
    user_id: Optional[str]
    message: str
    data: Dict[str, Any]
    sanitized_data: Dict[str, Any]
    hash: str

class AuditLogger:
    """
    Comprehensive audit logging system for customer care operations.
    Handles event logging, PII sanitization, and trace management.
    """
    
    def __init__(self, 
                 logs_path: str = "logs/audit",
                 retention_days: int = 90,
                 max_file_size: int = 100 * 1024 * 1024,  # 100MB
                 batch_size: int = 100,
                 flush_interval: float = 5.0):
        """
        Initialize audit logger.
        
        Args:
            logs_path: Base path for log files
            retention_days: Log retention period in days
            max_file_size: Maximum size per log file in bytes
            batch_size: Number of events to batch before writing
            flush_interval: Time interval for flushing batches in seconds
        """
        self.logs_path = Path(logs_path)
        self.logs_path.mkdir(parents=True, exist_ok=True)
        
        self.retention_days = retention_days
        self.max_file_size = max_file_size
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        
        self.logger = logging.getLogger(__name__)
        
        # Event queue for batching
        self.event_queue = queue.Queue()
        self.batch_lock = threading.Lock()
        self.current_batch = []
        
        # Background thread for processing events
        self.worker_thread = threading.Thread(target=self._process_events, daemon=True)
        self.worker_thread.start()
        
        # PII patterns for sanitization
        self.pii_patterns = {
            'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'phone': r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',
            'ssn': r'\b\d{3}-\d{2}-\d{4}\b',
            'credit_card': r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b',
            'address': r'\b\d+\s+[A-Za-z0-9\s]+(?:Street|St|Avenue|Ave|Road|Rd|Drive|Dr|Lane|Ln|Boulevard|Blvd)\b'
        }
    
    def log_event(self,
                  event_type: EventType,
                  message: str,
                  data: Dict[str, Any],
                  trace_id: str,
                  session_id: Optional[str] = None,
                  user_id: Optional[str] = None,
                  severity: SeverityLevel = SeverityLevel.INFO) -> str:
        """
        Log an audit event.
        
        Args:
            event_type: Type of event being logged
            message: Human-readable event message
            data: Event data dictionary
            trace_id: Unique trace identifier
            session_id: Session identifier
            user_id: User identifier
            severity: Event severity level
            
        Returns:
            Event ID for tracking
        """
        try:
            event_id = str(uuid.uuid4())
            
            # Sanitize data
            sanitized_data = self._sanitize_data(data)
            
            # Create audit event
            event = AuditEvent(
                event_id=event_id,
                event_type=event_type,
                severity=severity,
                timestamp=datetime.now().isoformat(),
                trace_id=trace_id,
                session_id=session_id,
                user_id=user_id,
                message=message,
                data=data,
                sanitized_data=sanitized_data,
                hash=self._calculate_event_hash(event_id, event_type, message, sanitized_data)
            )
            
            # Add to queue for processing
            self.event_queue.put(event)
            
            # Log to application logger
            log_level = getattr(logging, severity.value.upper())
            self.logger.log(log_level, f"[{trace_id}] {event_type.value}: {message}")
            
            return event_id
            
        except Exception as e:
            self.logger.error(f"Failed to log event: {e}")
            return ""
    
    def _sanitize_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Sanitize data by removing or masking PII."""
        try:
            sanitized = {}
            
            for key, value in data.items():
                if isinstance(value, str):
                    sanitized[key] = self._sanitize_string(value)
                elif isinstance(value, dict):
                    sanitized[key] = self._sanitize_data(value)
                elif isinstance(value, list):
                    sanitized[key] = [
                        self._sanitize_data(item) if isinstance(item, dict)
                        else self._sanitize_string(item) if isinstance(item, str)
                        else item
                        for item in value
                    ]
                else:
                    sanitized[key] = value
            
            return sanitized
            
        except Exception as e:
            self.logger.error(f"Failed to sanitize data: {e}")
            return data
    
    def _sanitize_string(self, text: str) -> str:
        """Sanitize a string by masking PII patterns."""
        try:
            import re
            
            sanitized_text = text
            
            # Email addresses
            sanitized_text = re.sub(
                self.pii_patterns['email'], 
                lambda m: self._mask_email(m.group()), 
                sanitized_text
            )
            
            # Phone numbers
            sanitized_text = re.sub(
                self.pii_patterns['phone'], 
                '***-***-****', 
                sanitized_text
            )
            
            # SSN
            sanitized_text = re.sub(
                self.pii_patterns['ssn'], 
                '***-**-****', 
                sanitized_text
            )
            
            # Credit cards
            sanitized_text = re.sub(
                self.pii_patterns['credit_card'], 
                '****-****-****-****', 
                sanitized_text
            )
            
            # Addresses
            sanitized_text = re.sub(
                self.pii_patterns['address'], 
                '*** [Address Redacted]', 
                sanitized_text
            )
            
            return sanitized_text
            
        except Exception as e:
            self.logger.error(f"Failed to sanitize string: {e}")
            return text
    
    def _mask_email(self, email: str) -> str:
        """Mask email address while preserving domain."""
        try:
            username, domain = email.split('@', 1)
            if len(username) > 2:
                return f"{username[:2]}***@{domain}"
            else:
                return f"***@{domain}"
        except:
            return "***@***.***"
    
    def _calculate_event_hash(self, 
                            event_id: str, 
                            event_type: EventType, 
                            message: str, 
                            data: Dict[str, Any]) -> str:
        """Calculate hash for event integrity verification."""
        try:
            content = f"{event_id}:{event_type.value}:{message}:{json.dumps(data, sort_keys=True)}"
            return hashlib.sha256(content.encode()).hexdigest()
        except:
            return ""
    
    def _process_events(self):
        """Background thread for processing audit events."""
        while True:
            try:
                # Wait for events or timeout
                try:
                    event = self.event_queue.get(timeout=self.flush_interval)
                except queue.Empty:
                    # Timeout - flush current batch
                    self._flush_batch()
                    continue
                
                # Add to current batch
                with self.batch_lock:
                    self.current_batch.append(event)
                    
                    # Flush if batch is full
                    if len(self.current_batch) >= self.batch_size:
                        self._flush_batch()
                
                self.event_queue.task_done()
                
            except Exception as e:
                self.logger.error(f"Error processing audit events: {e}")
    
    def _flush_batch(self):
        """Flush current batch of events to disk."""
        try:
            with self.batch_lock:
                if not self.current_batch:
                    return
                
                batch = self.current_batch.copy()
                self.current_batch.clear()
            
            # Group events by trace_id for organized logging
            trace_groups = {}
            for event in batch:
                trace_id = event.trace_id
                if trace_id not in trace_groups:
                    trace_groups[trace_id] = []
                trace_groups[trace_id].append(event)
            
            # Write each trace group to separate file
            for trace_id, events in trace_groups.items():
                self._write_trace_events(trace_id, events)
            
            self.logger.debug(f"Flushed {len(batch)} audit events")
            
        except Exception as e:
            self.logger.error(f"Failed to flush audit batch: {e}")
    
    def _write_trace_events(self, trace_id: str, events: List[AuditEvent]):
        """Write events for a specific trace to file."""
        try:
            # Determine file path
            date_str = datetime.now().strftime("%Y-%m-%d")
            trace_file = self.logs_path / date_str / f"{trace_id}.jsonl"
            trace_file.parent.mkdir(parents=True, exist_ok=True)
            
            # Check file size and rotate if needed
            if trace_file.exists() and trace_file.stat().st_size > self.max_file_size:
                self._rotate_trace_file(trace_file)
            
            # Write events to file
            with open(trace_file, 'a', encoding='utf-8') as f:
                for event in events:
                    event_dict = asdict(event)
                    # Convert enums to strings
                    event_dict['event_type'] = event.event_type.value
                    event_dict['severity'] = event.severity.value
                    
                    f.write(json.dumps(event_dict, ensure_ascii=False) + '\n')
            
        except Exception as e:
            self.logger.error(f"Failed to write trace events for {trace_id}: {e}")
    
    def _rotate_trace_file(self, trace_file: Path):
        """Rotate trace file when it exceeds size limit."""
        try:
            timestamp = datetime.now().strftime("%H%M%S")
            rotated_name = f"{trace_file.stem}_{timestamp}.jsonl"
            rotated_path = trace_file.parent / rotated_name
            
            trace_file.rename(rotated_path)
            
        except Exception as e:
            self.logger.error(f"Failed to rotate trace file {trace_file}: {e}")
    
    def get_trace_events(self, trace_id: str, date: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Retrieve all events for a specific trace.
        
        Args:
            trace_id: Trace identifier
            date: Date string (YYYY-MM-DD), uses today if None
            
        Returns:
            List of event dictionaries
        """
        try:
            if date is None:
                date = datetime.now().strftime("%Y-%m-%d")
            
            trace_file = self.logs_path / date / f"{trace_id}.jsonl"
            
            if not trace_file.exists():
                return []
            
            events = []
            with open(trace_file, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        event = json.loads(line)
                        events.append(event)
            
            # Sort by timestamp
            events.sort(key=lambda x: x['timestamp'])
            
            return events
            
        except Exception as e:
            self.logger.error(f"Failed to get trace events for {trace_id}: {e}")
            return []
    
    def search_events(self,
                     event_type: Optional[EventType] = None,
                     user_id: Optional[str] = None,
                     session_id: Optional[str] = None,
                     start_date: Optional[datetime] = None,
                     end_date: Optional[datetime] = None,
                     severity: Optional[SeverityLevel] = None,
                     limit: int = 1000) -> List[Dict[str, Any]]:
        """
        Search audit events with filters.
        
        Args:
            event_type: Filter by event type
            user_id: Filter by user ID
            session_id: Filter by session ID
            start_date: Filter events after this date
            end_date: Filter events before this date
            severity: Filter by severity level
            limit: Maximum number of results
            
        Returns:
            List of matching event dictionaries
        """
        try:
            # Flush current batch to ensure all events are written
            self._flush_batch()
            
            events = []
            current_date = start_date or datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            end_date = end_date or datetime.now()
            
            # Search through date range
            while current_date <= end_date and len(events) < limit:
                date_str = current_date.strftime("%Y-%m-%d")
                date_path = self.logs_path / date_str
                
                if date_path.exists():
                    # Search all trace files for this date
                    for trace_file in date_path.glob("*.jsonl"):
                        events.extend(self._search_trace_file(
                            trace_file, event_type, user_id, session_id, 
                            start_date, end_date, severity, limit - len(events)
                        ))
                
                current_date += timedelta(days=1)
            
            # Sort by timestamp (newest first)
            events.sort(key=lambda x: x['timestamp'], reverse=True)
            
            return events[:limit]
            
        except Exception as e:
            self.logger.error(f"Failed to search events: {e}")
            return []
    
    def _search_trace_file(self,
                          trace_file: Path,
                          event_type: Optional[EventType],
                          user_id: Optional[str],
                          session_id: Optional[str],
                          start_date: Optional[datetime],
                          end_date: Optional[datetime],
                          severity: Optional[SeverityLevel],
                          limit: int) -> List[Dict[str, Any]]:
        """Search events in a single trace file."""
        try:
            events = []
            
            with open(trace_file, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        event = json.loads(line)
                        
                        # Apply filters
                        if event_type and event.get('event_type') != event_type.value:
                            continue
                        if user_id and event.get('user_id') != user_id:
                            continue
                        if session_id and event.get('session_id') != session_id:
                            continue
                        if severity and event.get('severity') != severity.value:
                            continue
                        
                        # Date filter
                        event_time = datetime.fromisoformat(event['timestamp'])
                        if start_date and event_time < start_date:
                            continue
                        if end_date and event_time > end_date:
                            continue
                        
                        events.append(event)
                        
                        if len(events) >= limit:
                            break
            
            return events
            
        except Exception as e:
            self.logger.error(f"Failed to search trace file {trace_file}: {e}")
            return []
    
    def cleanup_old_logs(self):
        """Remove log files older than retention period."""
        try:
            cutoff_date = datetime.now() - timedelta(days=self.retention_days)
            
            for date_path in self.logs_path.iterdir():
                if date_path.is_dir():
                    try:
                        date_str = date_path.name
                        log_date = datetime.strptime(date_str, "%Y-%m-%d")
                        
                        if log_date < cutoff_date:
                            import shutil
                            shutil.rmtree(date_path)
                            self.logger.info(f"Removed old log directory: {date_path}")
                            
                    except ValueError:
                        # Skip non-date directories
                        continue
            
        except Exception as e:
            self.logger.error(f"Failed to cleanup old logs: {e}")
    
    def get_audit_stats(self) -> Dict[str, Any]:
        """Get audit logging system statistics."""
        try:
            stats = {
                "total_events": 0,
                "events_by_type": {},
                "events_by_severity": {},
                "events_by_date": {},
                "queue_size": self.event_queue.qsize(),
                "batch_size": len(self.current_batch),
                "log_files": 0,
                "total_log_size": 0
            }
            
            # Count events in recent log files
            for date_path in self.logs_path.iterdir():
                if date_path.is_dir():
                    date_str = date_path.name
                    daily_events = 0
                    
                    for trace_file in date_path.glob("*.jsonl"):
                        try:
                            file_size = trace_file.stat().st_size
                            stats["total_log_size"] += file_size
                            stats["log_files"] += 1
                            
                            with open(trace_file, 'r') as f:
                                for line in f:
                                    if line.strip():
                                        daily_events += 1
                                        event = json.loads(line)
                                        
                                        # Count by type
                                        event_type = event.get('event_type', 'unknown')
                                        stats["events_by_type"][event_type] = stats["events_by_type"].get(event_type, 0) + 1
                                        
                                        # Count by severity
                                        severity = event.get('severity', 'unknown')
                                        stats["events_by_severity"][severity] = stats["events_by_severity"].get(severity, 0) + 1
                                        
                        except Exception as e:
                            self.logger.error(f"Failed to process trace file {trace_file}: {e}")
                    
                    stats["events_by_date"][date_str] = daily_events
                    stats["total_events"] += daily_events
            
            return stats
            
        except Exception as e:
            self.logger.error(f"Failed to get audit stats: {e}")
            return {}
    
    def shutdown(self):
        """Shutdown audit logger and flush remaining events."""
        try:
            # Flush remaining events
            self._flush_batch()
            
            # Wait for queue to empty
            self.event_queue.join()
            
            self.logger.info("Audit logger shutdown complete")
            
        except Exception as e:
            self.logger.error(f"Error during audit logger shutdown: {e}")

# Example usage and testing
if __name__ == "__main__":
    # Initialize audit logger
    audit_logger = AuditLogger()
    
    # Generate test trace ID
    trace_id = str(uuid.uuid4())
    
    # Log various events
    audit_logger.log_event(
        EventType.MESSAGE_RECEIVED,
        "Customer message received",
        {"text": "Hi, I need help with my order o_2001", "user_email": "john.doe@example.com"},
        trace_id,
        session_id="session_001",
        user_id="u_1001"
    )
    
    audit_logger.log_event(
        EventType.TRIAGE_RESULT,
        "Intent classified as refunds",
        {"intent": "refunds", "confidence": 0.85},
        trace_id,
        session_id="session_001",
        user_id="u_1001"
    )
    
    audit_logger.log_event(
        EventType.POLICY_DECISION,
        "Refund approved under policy RF-2.3",
        {"action": "refund", "amount": 89.00, "clause_id": "RF-2.3"},
        trace_id,
        session_id="session_001",
        user_id="u_1001",
        severity=SeverityLevel.INFO
    )
    
    # Wait for events to be processed
    import time
    time.sleep(2)
    
    # Retrieve trace events
    events = audit_logger.get_trace_events(trace_id)
    print(f"Retrieved {len(events)} events for trace {trace_id}")
    
    for event in events:
        print(f"- {event['event_type']}: {event['message']}")
    
    # Get audit stats
    stats = audit_logger.get_audit_stats()
    print(f"\nAudit stats: {stats}")
    
    # Shutdown
    audit_logger.shutdown()
