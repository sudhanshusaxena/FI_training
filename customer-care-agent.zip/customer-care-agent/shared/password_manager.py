#!/usr/bin/env python3
"""
Password Manager for Customer Care Agent System
Handles password hashing, verification, and security utilities
"""

import bcrypt
import secrets
import hashlib
from typing import Tuple
from datetime import datetime

class PasswordManager:
    """Manages password operations with bcrypt hashing."""
    
    @staticmethod
    def hash_password(password: str) -> str:
        """
        Hash a password using bcrypt.
        
        Args:
            password: Plain text password
            
        Returns:
            Hashed password string
        """
        salt = bcrypt.gensalt(rounds=12)
        hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
        return hashed.decode('utf-8')
    
    @staticmethod
    def verify_password(password: str, hashed_password: str) -> bool:
        """
        Verify a password against its hash.
        
        Args:
            password: Plain text password to verify
            hashed_password: Hashed password to compare against
            
        Returns:
            True if password matches, False otherwise
        """
        try:
            return bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8'))
        except Exception as e:
            print(f"Password verification error: {e}")
            return False
    
    @staticmethod
    def generate_secure_password(length: int = 12) -> str:
        """
        Generate a secure random password.
        
        Args:
            length: Length of password to generate
            
        Returns:
            Secure random password
        """
        characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"
        return ''.join(secrets.choice(characters) for _ in range(length))
    
    @staticmethod
    def validate_password_strength(password: str) -> Tuple[bool, str]:
        """
        Validate password strength.
        
        Args:
            password: Password to validate
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        if len(password) < 8:
            return False, "Password must be at least 8 characters long"
        
        if len(password) > 128:
            return False, "Password must be less than 128 characters long"
        
        has_lower = any(c.islower() for c in password)
        has_upper = any(c.isupper() for c in password)
        has_digit = any(c.isdigit() for c in password)
        has_special = any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password)
        
        if not has_lower:
            return False, "Password must contain at least one lowercase letter"
        
        if not has_upper:
            return False, "Password must contain at least one uppercase letter"
        
        if not has_digit:
            return False, "Password must contain at least one digit"
        
        if not has_special:
            return False, "Password must contain at least one special character"
        
        return True, "Password is strong"
    
    @staticmethod
    def create_password_hash_with_timestamp(password: str) -> dict:
        """
        Create password hash with metadata.
        
        Args:
            password: Plain text password
            
        Returns:
            Dictionary with hash and metadata
        """
        hashed_password = PasswordManager.hash_password(password)
        
        return {
            "password_hash": hashed_password,
            "created_at": datetime.now().isoformat(),
            "algorithm": "bcrypt",
            "salt_rounds": 12
        }
    
    @staticmethod
    def generate_session_token() -> str:
        """
        Generate a secure session token.
        
        Returns:
            Secure session token
        """
        return secrets.token_urlsafe(32)
    
    @staticmethod
    def generate_email_verification_token() -> str:
        """
        Generate a secure email verification token.
        
        Returns:
            Secure verification token
        """
        return secrets.token_urlsafe(16)
    
    @staticmethod
    def create_password_reset_token() -> str:
        """
        Generate a secure password reset token.
        
        Returns:
            Secure reset token
        """
        return secrets.token_urlsafe(24)

def test_password_manager():
    """Test the password manager functionality."""
    print("🧪 Testing Password Manager...")
    
    # Test password hashing and verification
    test_password = "TestPassword123!"
    hashed = PasswordManager.hash_password(test_password)
    print(f"✅ Password hashed successfully")
    
    # Test verification
    is_valid = PasswordManager.verify_password(test_password, hashed)
    print(f"✅ Password verification: {'PASSED' if is_valid else 'FAILED'}")
    
    # Test invalid password
    is_invalid = PasswordManager.verify_password("WrongPassword", hashed)
    print(f"✅ Invalid password rejection: {'PASSED' if not is_invalid else 'FAILED'}")
    
    # Test password strength validation
    weak_password = "123"
    is_strong, message = PasswordManager.validate_password_strength(weak_password)
    print(f"✅ Weak password detection: {'PASSED' if not is_strong else 'FAILED'} - {message}")
    
    strong_password = "StrongPassword123!"
    is_strong, message = PasswordManager.validate_password_strength(strong_password)
    print(f"✅ Strong password validation: {'PASSED' if is_strong else 'FAILED'} - {message}")
    
    # Test token generation
    session_token = PasswordManager.generate_session_token()
    email_token = PasswordManager.generate_email_verification_token()
    reset_token = PasswordManager.create_password_reset_token()
    
    print(f"✅ Session token generated: {session_token[:20]}...")
    print(f"✅ Email token generated: {email_token[:20]}...")
    print(f"✅ Reset token generated: {reset_token[:20]}...")
    
    print("🎉 Password Manager tests completed!")

if __name__ == "__main__":
    test_password_manager()
