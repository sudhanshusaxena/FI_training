#!/usr/bin/env python3
"""
Session Manager for Customer Care Agent System
Handles 3-minute session management with JSON storage
"""

import json
import os
import secrets
from datetime import datetime, timedelta
from typing import Dict, Optional, List, Any
from pathlib import Path

class SessionManager:
    """Manages user sessions with 3-minute expiry and JSON storage."""
    
    def __init__(self, sessions_file: str = "logs/sessions/active_sessions.json"):
        self.sessions_file = sessions_file
        self.session_duration_minutes = 3
        self.ensure_sessions_directory()
    
    def ensure_sessions_directory(self):
        """Ensure the sessions directory exists."""
        os.makedirs(os.path.dirname(self.sessions_file), exist_ok=True)
    
    def load_sessions(self) -> Dict[str, Dict]:
        """Load existing sessions from file."""
        if os.path.exists(self.sessions_file):
            try:
                with open(self.sessions_file, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                return {}
        return {}
    
    def save_sessions(self, sessions: Dict[str, Dict]):
        """Save sessions to file."""
        with open(self.sessions_file, 'w') as f:
            json.dump(sessions, f, indent=2)
    
    def generate_session_id(self) -> str:
        """Generate a unique session ID."""
        return f"sess_{secrets.token_urlsafe(12)}"
    
    def generate_chat_id(self, user_id: str) -> str:
        """Generate a unique chat ID."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        random_suffix = secrets.token_urlsafe(6)
        return f"chat_{user_id}_{timestamp}_{random_suffix}"
    
    def create_session(self, user_id: str, auth_method: str = "multi_factor", 
                      auth_level: int = 2, ip_address: str = "127.0.0.1") -> Dict[str, Any]:
        """
        Create a new session for a user.
        
        Args:
            user_id: User ID to create session for
            auth_method: Authentication method used
            auth_level: Authentication level achieved
            ip_address: IP address of the user
            
        Returns:
            Session data dictionary
        """
        session_id = self.generate_session_id()
        chat_id = self.generate_chat_id(user_id)
        current_time = datetime.now()
        expiry_time = current_time + timedelta(minutes=self.session_duration_minutes)
        
        session_data = {
            "session_id": session_id,
            "user_id": user_id,
            "chat_id": chat_id,
            "created_at": current_time.isoformat(),
            "expires_at": expiry_time.isoformat(),
            "last_activity": current_time.isoformat(),
            "auth_method": auth_method,
            "auth_level": auth_level,
            "is_active": True,
            "ip_address": ip_address,
            "session_data": {
                "intent_history": [],
                "auth_attempts": 0,
                "email_verified": True,
                "conversation_count": 0,
                "last_intent": None
            }
        }
        
        # Load existing sessions
        sessions = self.load_sessions()
        
        # Add new session
        sessions[session_id] = session_data
        
        # Save sessions
        self.save_sessions(sessions)
        
        print(f"✅ Session created: {session_id} for user {user_id}")
        print(f"   Chat ID: {chat_id}")
        print(f"   Expires at: {expiry_time.strftime('%H:%M:%S')}")
        
        return session_data
    
    def validate_session(self, session_id: str) -> Dict[str, Any]:
        """
        Validate a session and check if it's still active.
        
        Args:
            session_id: Session ID to validate
            
        Returns:
            Dictionary with validation result
        """
        sessions = self.load_sessions()
        
        if session_id not in sessions:
            return {
                "valid": False,
                "error": "Session not found"
            }
        
        session = sessions[session_id]
        
        # Check if session is marked as inactive
        if not session["is_active"]:
            return {
                "valid": False,
                "error": "Session is inactive"
            }
        
        # Check if session has expired
        expiry_time = datetime.fromisoformat(session["expires_at"])
        current_time = datetime.now()
        
        if current_time > expiry_time:
            # Mark session as expired
            session["is_active"] = False
            session["expired_at"] = current_time.isoformat()
            sessions[session_id] = session
            self.save_sessions(sessions)
            
            return {
                "valid": False,
                "error": "Session has expired",
                "expired_at": session["expired_at"]
            }
        
        # Update last activity
        session["last_activity"] = current_time.isoformat()
        sessions[session_id] = session
        self.save_sessions(sessions)
        
        return {
            "valid": True,
            "session": session,
            "time_remaining": (expiry_time - current_time).total_seconds()
        }
    
    def extend_session(self, session_id: str, minutes: int = 3) -> bool:
        """
        Extend a session's expiry time.
        
        Args:
            session_id: Session ID to extend
            minutes: Minutes to extend by
            
        Returns:
            True if extended successfully, False otherwise
        """
        sessions = self.load_sessions()
        
        if session_id not in sessions:
            return False
        
        session = sessions[session_id]
        
        if not session["is_active"]:
            return False
        
        # Extend expiry time
        current_expiry = datetime.fromisoformat(session["expires_at"])
        new_expiry = current_expiry + timedelta(minutes=minutes)
        session["expires_at"] = new_expiry.isoformat()
        
        # Save updated session
        sessions[session_id] = session
        self.save_sessions(sessions)
        
        print(f"✅ Session {session_id} extended by {minutes} minutes")
        return True
    
    def end_session(self, session_id: str) -> bool:
        """
        End a session.
        
        Args:
            session_id: Session ID to end
            
        Returns:
            True if ended successfully, False otherwise
        """
        sessions = self.load_sessions()
        
        if session_id not in sessions:
            return False
        
        session = sessions[session_id]
        session["is_active"] = False
        session["ended_at"] = datetime.now().isoformat()
        
        sessions[session_id] = session
        self.save_sessions(sessions)
        
        print(f"✅ Session {session_id} ended")
        return True
    
    def get_user_sessions(self, user_id: str) -> List[Dict[str, Any]]:
        """
        Get all sessions for a user.
        
        Args:
            user_id: User ID to get sessions for
            
        Returns:
            List of session data dictionaries
        """
        sessions = self.load_sessions()
        user_sessions = []
        
        for session_id, session_data in sessions.items():
            if session_data["user_id"] == user_id:
                user_sessions.append(session_data)
        
        # Sort by creation time (newest first)
        user_sessions.sort(key=lambda x: x["created_at"], reverse=True)
        
        return user_sessions
    
    def cleanup_expired_sessions(self) -> int:
        """
        Clean up expired sessions.
        
        Returns:
            Number of sessions cleaned up
        """
        sessions = self.load_sessions()
        current_time = datetime.now()
        cleaned_count = 0
        
        for session_id, session in sessions.items():
            expiry_time = datetime.fromisoformat(session["expires_at"])
            
            if current_time > expiry_time and session["is_active"]:
                session["is_active"] = False
                session["expired_at"] = current_time.isoformat()
                sessions[session_id] = session
                cleaned_count += 1
        
        if cleaned_count > 0:
            self.save_sessions(sessions)
            print(f"🧹 Cleaned up {cleaned_count} expired sessions")
        
        return cleaned_count
    
    def get_session_stats(self) -> Dict[str, Any]:
        """
        Get statistics about active sessions.
        
        Returns:
            Dictionary with session statistics
        """
        sessions = self.load_sessions()
        current_time = datetime.now()
        
        total_sessions = len(sessions)
        active_sessions = 0
        expired_sessions = 0
        unique_users = set()
        
        for session in sessions.values():
            unique_users.add(session["user_id"])
            
            if session["is_active"]:
                expiry_time = datetime.fromisoformat(session["expires_at"])
                if current_time > expiry_time:
                    expired_sessions += 1
                else:
                    active_sessions += 1
            else:
                expired_sessions += 1
        
        return {
            "total_sessions": total_sessions,
            "active_sessions": active_sessions,
            "expired_sessions": expired_sessions,
            "unique_users": len(unique_users),
            "session_duration_minutes": self.session_duration_minutes
        }
    
    def display_session_summary(self):
        """Display a summary of all sessions."""
        stats = self.get_session_stats()
        
        print("\n📊 SESSION MANAGEMENT SUMMARY")
        print("="*50)
        print(f"Total sessions: {stats['total_sessions']}")
        print(f"Active sessions: {stats['active_sessions']}")
        print(f"Expired sessions: {stats['expired_sessions']}")
        print(f"Unique users: {stats['unique_users']}")
        print(f"Session duration: {stats['session_duration_minutes']} minutes")
        print("-"*50)
        
        # Show recent active sessions
        sessions = self.load_sessions()
        recent_sessions = []
        
        for session in sessions.values():
            if session["is_active"]:
                expiry_time = datetime.fromisoformat(session["expires_at"])
                if datetime.now() < expiry_time:
                    recent_sessions.append(session)
        
        recent_sessions.sort(key=lambda x: x["created_at"], reverse=True)
        
        if recent_sessions:
            print("Recent active sessions:")
            for session in recent_sessions[:5]:
                expiry_time = datetime.fromisoformat(session["expires_at"])
                time_remaining = expiry_time - datetime.now()
                print(f"  {session['session_id'][:12]}... - {session['user_id']} - {time_remaining.total_seconds():.0f}s remaining")
        else:
            print("No active sessions")
        
        print("="*50 + "\n")

def test_session_manager():
    """Test the session manager functionality."""
    print("🧪 Testing Session Manager...")
    
    # Initialize session manager
    session_mgr = SessionManager("logs/sessions/test_sessions.json")
    
    # Test session creation
    user_id = "u_1001"
    session_data = session_mgr.create_session(user_id)
    session_id = session_data["session_id"]
    print(f"✅ Session created: {session_id}")
    
    # Test session validation
    validation_result = session_mgr.validate_session(session_id)
    print(f"✅ Session validation: {'PASSED' if validation_result['valid'] else 'FAILED'}")
    
    # Test session extension
    extended = session_mgr.extend_session(session_id, 2)
    print(f"✅ Session extension: {'PASSED' if extended else 'FAILED'}")
    
    # Test user sessions
    user_sessions = session_mgr.get_user_sessions(user_id)
    print(f"✅ User sessions retrieved: {len(user_sessions)} sessions")
    
    # Test session stats
    stats = session_mgr.get_session_stats()
    print(f"✅ Session stats: {stats}")
    
    # Display summary
    session_mgr.display_session_summary()
    
    # Test session ending
    ended = session_mgr.end_session(session_id)
    print(f"✅ Session ending: {'PASSED' if ended else 'FAILED'}")
    
    print("🎉 Session manager tests completed!")

if __name__ == "__main__":
    test_session_manager()
