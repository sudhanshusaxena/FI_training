# Policy Gate - Customer Care Agent
"""
Policy enforcement system for validating actions against company SOPs.
Handles policy checking, compliance validation, and decision routing.
"""

import json
import logging
import re
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from pathlib import Path
import yaml

@dataclass
class PolicyClause:
    """Individual policy clause structure."""
    id: str
    title: str
    conditions: List[str]
    actions: List[str]
    requirements: List[str]
    restrictions: List[str]
    effective_date: str
    version: str
    source_path: str

@dataclass
class PolicyDecision:
    """Policy decision result."""
    action_id: str
    decision: str  # 'approved', 'denied', 'requires_hitl'
    clause_id: Optional[str]
    reasoning: str
    requirements: List[str]
    restrictions: List[str]
    confidence: float
    needs_hitl: bool
    hitl_reason: Optional[str]

@dataclass
class ActionProposal:
    """Proposed action for policy validation."""
    id: str
    action_type: str
    args: Dict[str, Any]
    rationale: str
    user_id: Optional[str]
    auth_level: int

class PolicyGate:
    """
    Policy enforcement system that validates proposed actions against company SOPs.
    """
    
    def __init__(self, sops_path: str = "shared/sops"):
        self.sops_path = Path(sops_path)
        self.logger = logging.getLogger(__name__)
        
        # Policy cache
        self.policy_clauses: Dict[str, PolicyClause] = {}
        self.policy_versions: Dict[str, str] = {}
        
        # Decision thresholds
        self.hitl_thresholds = {
            "high_value_refund": 500.0,
            "account_modification": 0.0,
            "policy_override": 0.0,
            "ambiguous_situation": 0.6  # confidence threshold
        }
        
        # Load policies on initialization
        self._load_policies()
    
    def _load_policies(self):
        """Load all policy documents and extract clauses."""
        try:
            for policy_file in self.sops_path.glob("*.md"):
                self._parse_policy_file(policy_file)
            
            self.logger.info(f"Loaded {len(self.policy_clauses)} policy clauses")
            
        except Exception as e:
            self.logger.error(f"Failed to load policies: {e}")
    
    def _parse_policy_file(self, policy_file: Path):
        """Parse a single policy file and extract clauses."""
        try:
            with open(policy_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Extract front-matter
            front_matter, content = self._extract_front_matter(content)
            
            # Extract policy version
            version = front_matter.get('version', 'unknown')
            effective_date = front_matter.get('effective_date', 'unknown')
            
            # Extract clauses from content
            clauses = self._extract_clauses(content, policy_file.name, version, effective_date)
            
            # Store clauses
            for clause in clauses:
                self.policy_clauses[clause.id] = clause
            
            self.policy_versions[policy_file.stem] = version
            
        except Exception as e:
            self.logger.error(f"Failed to parse policy file {policy_file}: {e}")
    
    def _extract_front_matter(self, content: str) -> Tuple[Dict, str]:
        """Extract YAML front-matter from markdown content."""
        if content.startswith('---'):
            parts = content.split('---', 2)
            if len(parts) >= 3:
                try:
                    front_matter = yaml.safe_load(parts[1])
                    return front_matter or {}, parts[2].strip()
                except yaml.YAMLError:
                    pass
        
        return {}, content
    
    def _extract_clauses(self, content: str, filename: str, version: str, effective_date: str) -> List[PolicyClause]:
        """Extract policy clauses from markdown content."""
        clauses = []
        
        # Split content into sections
        sections = re.split(r'\n#{2,3}\s+', content)
        
        for section in sections:
            if not section.strip():
                continue
            
            lines = section.strip().split('\n')
            if not lines:
                continue
            
            # First line is the heading
            heading = lines[0].strip()
            if not heading:
                continue
            
            # Extract clause ID from heading
            clause_id = self._extract_clause_id(heading, filename)
            if not clause_id:
                continue
            
            # Parse section content
            section_content = '\n'.join(lines[1:])
            conditions, actions, requirements, restrictions = self._parse_clause_content(section_content)
            
            clause = PolicyClause(
                id=clause_id,
                title=heading,
                conditions=conditions,
                actions=actions,
                requirements=requirements,
                restrictions=restrictions,
                effective_date=effective_date,
                version=version,
                source_path=str(self.sops_path / filename)
            )
            
            clauses.append(clause)
        
        return clauses
    
    def _extract_clause_id(self, heading: str, filename: str) -> Optional[str]:
        """Extract clause ID from heading."""
        # Look for patterns like "RF-2.3", "UP-1.1", etc.
        match = re.search(r'([A-Z]{2,3}-\d+\.\d+)', heading)
        if match:
            return match.group(1)
        
        # Fallback to filename-based ID
        filename_base = filename.replace('.md', '').replace('_policy', '').replace('_', '-')
        return f"{filename_base}-unknown"
    
    def _parse_clause_content(self, content: str) -> Tuple[List[str], List[str], List[str], List[str]]:
        """Parse clause content to extract conditions, actions, requirements, and restrictions."""
        conditions = []
        actions = []
        requirements = []
        restrictions = []
        
        lines = content.split('\n')
        current_section = None
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Detect section headers
            if line.lower().startswith('conditions:'):
                current_section = 'conditions'
                continue
            elif line.lower().startswith('actions:'):
                current_section = 'actions'
                continue
            elif line.lower().startswith('requirements:'):
                current_section = 'requirements'
                continue
            elif line.lower().startswith('restrictions:'):
                current_section = 'restrictions'
                continue
            
            # Add content to appropriate section
            if current_section == 'conditions' and line.startswith('-'):
                conditions.append(line[1:].strip())
            elif current_section == 'actions' and line.startswith('-'):
                actions.append(line[1:].strip())
            elif current_section == 'requirements' and line.startswith('-'):
                requirements.append(line[1:].strip())
            elif current_section == 'restrictions' and line.startswith('-'):
                restrictions.append(line[1:].strip())
        
        return conditions, actions, requirements, restrictions
    
    def validate_action(self, proposal: ActionProposal) -> PolicyDecision:
        """
        Validate a proposed action against applicable policies.
        
        Args:
            proposal: ActionProposal to validate
            
        Returns:
            PolicyDecision with validation result
        """
        try:
            # Find applicable policy clauses
            applicable_clauses = self._find_applicable_clauses(proposal)
            
            if not applicable_clauses:
                return PolicyDecision(
                    action_id=proposal.id,
                    decision="denied",
                    clause_id=None,
                    reasoning="No applicable policy clauses found",
                    requirements=[],
                    restrictions=[],
                    confidence=0.0,
                    needs_hitl=True,
                    hitl_reason="No policy guidance available"
                )
            
            # Evaluate each applicable clause
            best_match = None
            best_confidence = 0.0
            
            for clause in applicable_clauses:
                confidence = self._evaluate_clause_match(proposal, clause)
                if confidence > best_confidence:
                    best_confidence = confidence
                    best_match = clause
            
            if not best_match:
                return PolicyDecision(
                    action_id=proposal.id,
                    decision="denied",
                    clause_id=None,
                    reasoning="No policy clauses match the proposed action",
                    requirements=[],
                    restrictions=[],
                    confidence=0.0,
                    needs_hitl=True,
                    hitl_reason="Ambiguous policy situation"
                )
            
            # Determine decision based on best match
            decision = self._make_decision(proposal, best_match, best_confidence)
            
            return decision
            
        except Exception as e:
            self.logger.error(f"Failed to validate action {proposal.id}: {e}")
            return PolicyDecision(
                action_id=proposal.id,
                decision="denied",
                clause_id=None,
                reasoning=f"Policy validation error: {str(e)}",
                requirements=[],
                restrictions=[],
                confidence=0.0,
                needs_hitl=True,
                hitl_reason="System error during validation"
            )
    
    def _find_applicable_clauses(self, proposal: ActionProposal) -> List[PolicyClause]:
        """Find policy clauses applicable to the proposed action."""
        applicable = []
        
        for clause in self.policy_clauses.values():
            if self._is_clause_applicable(proposal, clause):
                applicable.append(clause)
        
        return applicable
    
    def _is_clause_applicable(self, proposal: ActionProposal, clause: PolicyClause) -> bool:
        """Check if a clause is applicable to the proposed action."""
        # Simple keyword matching - in production, use more sophisticated NLP
        action_type = proposal.action_type.lower()
        clause_actions = [action.lower() for action in clause.actions]
        
        # Check for action type matches
        for clause_action in clause_actions:
            if action_type in clause_action or clause_action in action_type:
                return True
        
        # Check for specific action patterns
        if 'refund' in action_type and any('refund' in action.lower() for action in clause.actions):
            return True
        elif 'order' in action_type and any('order' in action.lower() for action in clause.actions):
            return True
        elif 'cancel' in action_type and any('cancel' in action.lower() for action in clause.actions):
            return True
        
        return False
    
    def _evaluate_clause_match(self, proposal: ActionProposal, clause: PolicyClause) -> float:
        """Evaluate how well a clause matches the proposed action."""
        confidence = 0.0
        
        # Check conditions match
        conditions_met = self._check_conditions(proposal, clause)
        if conditions_met > 0:
            confidence += 0.5 * conditions_met
        
        # Check action type match
        action_match = self._check_action_match(proposal, clause)
        confidence += 0.3 * action_match
        
        # Check user authorization
        auth_match = self._check_authorization(proposal, clause)
        confidence += 0.2 * auth_match
        
        return min(confidence, 1.0)
    
    def _check_conditions(self, proposal: ActionProposal, clause: PolicyClause) -> float:
        """Check how many clause conditions are met."""
        if not clause.conditions:
            return 1.0  # No conditions means always applicable
        
        met_conditions = 0
        total_conditions = len(clause.conditions)
        
        for condition in clause.conditions:
            if self._evaluate_condition(proposal, condition):
                met_conditions += 1
        
        return met_conditions / total_conditions if total_conditions > 0 else 0.0
    
    def _evaluate_condition(self, proposal: ActionProposal, condition: str) -> bool:
        """Evaluate a single policy condition against the proposal."""
        condition_lower = condition.lower()
        args = proposal.args
        
        # Time-based conditions
        if 'within' in condition_lower and 'days' in condition_lower:
            # Extract number of days
            days_match = re.search(r'within[^\d]*(\d+)[^\d]*days', condition_lower)
            if days_match:
                max_days = int(days_match.group(1))
                # Check if action is within time limit
                if 'order_date' in args:
                    order_date = datetime.fromisoformat(args['order_date'])
                    days_ago = (datetime.now() - order_date).days
                    return days_ago <= max_days
        
        # Amount-based conditions
        if 'amount' in condition_lower or 'value' in condition_lower:
            if 'amount' in args:
                amount = float(args['amount'])
                # Check amount thresholds
                if 'less than' in condition_lower:
                    threshold_match = re.search(r'less than[^\d]*(\d+)', condition_lower)
                    if threshold_match:
                        threshold = float(threshold_match.group(1))
                        return amount < threshold
                elif 'more than' in condition_lower:
                    threshold_match = re.search(r'more than[^\d]*(\d+)', condition_lower)
                    if threshold_match:
                        threshold = float(threshold_match.group(1))
                        return amount > threshold
        
        # Status-based conditions
        if 'status' in condition_lower:
            if 'order_status' in args:
                required_status = condition_lower.split('status')[1].strip()
                return args['order_status'].lower() in required_status
        
        # Default to True for conditions we can't evaluate
        return True
    
    def _check_action_match(self, proposal: ActionProposal, clause: PolicyClause) -> float:
        """Check how well the action type matches the clause."""
        action_type = proposal.action_type.lower()
        
        for clause_action in clause.actions:
            clause_action_lower = clause_action.lower()
            if action_type == clause_action_lower:
                return 1.0
            elif action_type in clause_action_lower:
                return 0.8
            elif clause_action_lower in action_type:
                return 0.8
        
        return 0.0
    
    def _check_authorization(self, proposal: ActionProposal, clause: PolicyClause) -> float:
        """Check if user has sufficient authorization for the action."""
        # Simple authorization check based on auth level
        auth_level = proposal.auth_level
        
        # Higher auth levels can perform more actions
        if auth_level >= 2:
            return 1.0
        elif auth_level >= 1:
            return 0.7
        else:
            return 0.3
    
    def _make_decision(self, proposal: ActionProposal, clause: PolicyClause, confidence: float) -> PolicyDecision:
        """Make final decision based on clause evaluation."""
        
        # Check if HITL is required
        needs_hitl, hitl_reason = self._check_hitl_requirements(proposal, clause, confidence)
        
        if needs_hitl:
            decision = "requires_hitl"
        elif confidence >= 0.8:
            decision = "approved"
        elif confidence >= 0.6:
            decision = "approved"  # Approved but with monitoring
        else:
            decision = "denied"
        
        reasoning = f"Action matches clause {clause.id} with {confidence:.1%} confidence"
        
        return PolicyDecision(
            action_id=proposal.id,
            decision=decision,
            clause_id=clause.id,
            reasoning=reasoning,
            requirements=clause.requirements.copy(),
            restrictions=clause.restrictions.copy(),
            confidence=confidence,
            needs_hitl=needs_hitl,
            hitl_reason=hitl_reason
        )
    
    def _check_hitl_requirements(self, proposal: ActionProposal, clause: PolicyClause, confidence: float) -> Tuple[bool, Optional[str]]:
        """Check if human-in-the-loop approval is required."""
        
        # High-value refunds
        if 'refund' in proposal.action_type.lower():
            amount = proposal.args.get('amount', 0)
            if amount > self.hitl_thresholds['high_value_refund']:
                return True, f"High-value refund (${amount}) exceeds threshold"
        
        # Account modifications
        if proposal.action_type in ['account_modify', 'password_reset', 'billing_change']:
            return True, "Account modification requires human approval"
        
        # Policy overrides
        if 'override' in proposal.args or 'exception' in proposal.args:
            return True, "Policy override requires human approval"
        
        # Low confidence decisions
        if confidence < self.hitl_thresholds['ambiguous_situation']:
            return True, f"Low confidence decision ({confidence:.1%})"
        
        # Specific clause requirements
        if any('hitl' in req.lower() or 'human' in req.lower() for req in clause.requirements):
            return True, "Policy clause requires human review"
        
        return False, None
    
    def get_policy_info(self, clause_id: str) -> Optional[PolicyClause]:
        """Get information about a specific policy clause."""
        return self.policy_clauses.get(clause_id)
    
    def list_applicable_policies(self, action_type: str) -> List[PolicyClause]:
        """List all policies applicable to an action type."""
        applicable = []
        action_type_lower = action_type.lower()
        
        for clause in self.policy_clauses.values():
            for clause_action in clause.actions:
                if action_type_lower in clause_action.lower():
                    applicable.append(clause)
                    break
        
        return applicable
    
    def get_policy_stats(self) -> Dict[str, Any]:
        """Get policy system statistics."""
        return {
            "total_clauses": len(self.policy_clauses),
            "policy_files": len(self.policy_versions),
            "latest_versions": self.policy_versions,
            "hitl_thresholds": self.hitl_thresholds
        }

# Example usage and testing
if __name__ == "__main__":
    # Initialize policy gate
    policy_gate = PolicyGate()
    
    # Create test action proposal
    proposal = ActionProposal(
        id="refund_001",
        action_type="orders.refund_apply",
        args={
            "order_id": "o_2001",
            "amount": 89.00,
            "reason": "damaged_item",
            "order_date": "2025-01-10T10:00:00Z",
            "order_status": "delivered"
        },
        rationale="Customer received damaged item within 30 days",
        user_id="u_1001",
        auth_level=2
    )
    
    # Validate action
    decision = policy_gate.validate_action(proposal)
    
    print(f"Action: {proposal.id}")
    print(f"Decision: {decision.decision}")
    print(f"Clause: {decision.clause_id}")
    print(f"Reasoning: {decision.reasoning}")
    print(f"Confidence: {decision.confidence:.1%}")
    print(f"Needs HITL: {decision.needs_hitl}")
    if decision.needs_hitl:
        print(f"HITL Reason: {decision.hitl_reason}")
    
    # Get policy stats
    stats = policy_gate.get_policy_stats()
    print(f"\nPolicy stats: {stats}")
