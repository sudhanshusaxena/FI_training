#!/usr/bin/env python3
"""
LLM-as-a-Judge Evaluation System
Uses GPT-4 to evaluate the customer care agent's performance on various metrics
"""

import os
import json
import time
from datetime import datetime
from typing import Dict, List, Any, Tuple
import csv

try:
    from openai import OpenAI
    OPENAI_NEW_VERSION = True
except ImportError:
    import openai
    OPENAI_NEW_VERSION = False

class LLMJudgeEvaluator:
    """LLM-as-a-Judge evaluation system for customer care agent performance."""
    
    def __init__(self, api_key: str = None):
        """Initialize the LLM judge evaluator."""
        self.api_key = api_key or os.getenv('OPENAI_API_KEY')
        
        if OPENAI_NEW_VERSION:
            self.client = OpenAI(api_key=self.api_key) if self.api_key else None
        else:
            if self.api_key:
                openai.api_key = self.api_key
                self.client = None
        
        # Evaluation criteria
        self.evaluation_criteria = {
            "intent_classification_accuracy": {
                "description": "How accurately did the system classify the user's intent?",
                "scale": "1-10 (1=completely wrong, 10=perfect classification)"
            },
            "response_relevance": {
                "description": "How relevant and helpful is the system's response to the user's query?",
                "scale": "1-10 (1=completely irrelevant, 10=perfectly relevant and helpful)"
            },
            "auth_decision_correctness": {
                "description": "Was the authentication requirement decision correct for this type of query?",
                "scale": "1-10 (1=completely wrong decision, 10=perfect decision)"
            },
            "handover_appropriateness": {
                "description": "Was the human handover decision appropriate for this situation?",
                "scale": "1-10 (1=shouldn't handover, 10=perfect handover decision)"
            },
            "follow_up_quality": {
                "description": "How helpful and relevant are the generated follow-up questions?",
                "scale": "1-10 (1=unhelpful questions, 10=excellent follow-up questions)"
            },
            "overall_satisfaction": {
                "description": "Overall customer satisfaction with the interaction quality",
                "scale": "1-10 (1=very dissatisfied, 10=extremely satisfied)"
            }
        }
    
    def evaluate_interaction(self, 
                           user_message: str,
                           detected_intent: str,
                           intent_confidence: float,
                           auth_required: bool,
                           auth_successful: bool,
                           human_handover: bool,
                           agent_response: str,
                           follow_up_questions: List[str] = None,
                           response_time: float = None) -> Dict[str, Any]:
        """
        Evaluate a single interaction using LLM-as-a-Judge.
        
        Args:
            user_message: The user's original message
            detected_intent: The intent classified by the system
            intent_confidence: Confidence score from the system
            auth_required: Whether authentication was required
            auth_successful: Whether authentication was successful
            human_handover: Whether human handover occurred
            agent_response: The agent's response
            follow_up_questions: List of follow-up questions generated
            response_time: Time taken to respond (optional)
        
        Returns:
            Dictionary with evaluation scores and reasoning
        """
        
        if not self.api_key:
            return self._get_fallback_evaluation()
        
        try:
            # Prepare evaluation prompt
            evaluation_prompt = self._create_evaluation_prompt(
                user_message, detected_intent, intent_confidence,
                auth_required, auth_successful, human_handover,
                agent_response, follow_up_questions, response_time
            )
            
            # Call LLM for evaluation
            if OPENAI_NEW_VERSION:
                response = self.client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[
                        {"role": "system", "content": "You are an expert evaluator of customer service AI systems. Evaluate the interaction objectively and provide scores from 1-10 with one-line reasoning for each metric."},
                        {"role": "user", "content": evaluation_prompt}
                    ],
                    temperature=0.3,
                    max_tokens=1000
                )
                evaluation_text = response.choices[0].message.content
            else:
                response = openai.ChatCompletion.create(
                    model="gpt-4o-mini",
                    messages=[
                        {"role": "system", "content": "You are an expert evaluator of customer service AI systems. Evaluate the interaction objectively and provide scores from 1-10 with one-line reasoning for each metric."},
                        {"role": "user", "content": evaluation_prompt}
                    ],
                    temperature=0.3,
                    max_tokens=1000
                )
                evaluation_text = response.choices[0].message.content
            
            # Parse evaluation results
            evaluation_results = self._parse_evaluation_response(evaluation_text)
            
            return {
                "success": True,
                "evaluation_timestamp": datetime.now().isoformat(),
                "scores": evaluation_results,
                "raw_evaluation": evaluation_text,
                "model_used": "gpt-4o-mini"
            }
            
        except Exception as e:
            print(f"LLM Judge evaluation failed: {e}")
            return self._get_fallback_evaluation()
    
    def _create_evaluation_prompt(self, user_message, detected_intent, intent_confidence,
                                auth_required, auth_successful, human_handover,
                                agent_response, follow_up_questions, response_time):
        """Create the evaluation prompt for the LLM judge."""
        
        follow_up_text = "\n".join([f"- {q}" for q in follow_up_questions]) if follow_up_questions else "None"
        
        prompt = f"""
Evaluate this customer service AI interaction on the following metrics (1-10 scale):

USER MESSAGE: "{user_message}"

SYSTEM PERFORMANCE:
- Detected Intent: {detected_intent}
- Intent Confidence: {intent_confidence:.2f}
- Authentication Required: {auth_required}
- Authentication Successful: {auth_successful}
- Human Handover: {human_handover}
- Response Time: {response_time:.2f}s (if available)

AGENT RESPONSE: "{agent_response}"

FOLLOW-UP QUESTIONS:
{follow_up_text}

EVALUATION CRITERIA:
1. Intent Classification Accuracy (1-10): {self.evaluation_criteria['intent_classification_accuracy']['description']}
2. Response Relevance (1-10): {self.evaluation_criteria['response_relevance']['description']}
3. Authentication Decision Correctness (1-10): {self.evaluation_criteria['auth_decision_correctness']['description']}
4. Human Handover Appropriateness (1-10): {self.evaluation_criteria['handover_appropriateness']['description']}
5. Follow-up Question Quality (1-10): {self.evaluation_criteria['follow_up_quality']['description']}
6. Overall Customer Satisfaction (1-10): {self.evaluation_criteria['overall_satisfaction']['description']}

Please provide your evaluation in the following JSON format:
{{
    "intent_classification_accuracy": {{
        "score": <1-10>,
        "reasoning": "<one-line explanation>"
    }},
    "response_relevance": {{
        "score": <1-10>,
        "reasoning": "<one-line explanation>"
    }},
    "auth_decision_correctness": {{
        "score": <1-10>,
        "reasoning": "<one-line explanation>"
    }},
    "handover_appropriateness": {{
        "score": <1-10>,
        "reasoning": "<one-line explanation>"
    }},
    "follow_up_quality": {{
        "score": <1-10>,
        "reasoning": "<one-line explanation>"
    }},
    "overall_satisfaction": {{
        "score": <1-10>,
        "reasoning": "<one-line explanation>"
    }}
}}
"""
        return prompt
    
    def _parse_evaluation_response(self, evaluation_text: str) -> Dict[str, Any]:
        """Parse the LLM evaluation response."""
        try:
            # Try to extract JSON from the response
            start_idx = evaluation_text.find('{')
            end_idx = evaluation_text.rfind('}') + 1
            
            if start_idx != -1 and end_idx != 0:
                json_str = evaluation_text[start_idx:end_idx]
                return json.loads(json_str)
            else:
                # Fallback parsing if JSON format is not found
                return self._parse_text_evaluation(evaluation_text)
                
        except Exception as e:
            print(f"Failed to parse evaluation response: {e}")
            return self._get_fallback_evaluation()["scores"]
    
    def _parse_text_evaluation(self, text: str) -> Dict[str, Any]:
        """Fallback text parsing for evaluation results."""
        scores = {}
        
        for metric in self.evaluation_criteria.keys():
            # Look for metric name and score in the text
            metric_key = metric.replace('_', ' ').title()
            if metric_key in text:
                # Extract score (look for number 1-10)
                import re
                score_match = re.search(rf'{metric_key}.*?(\d+)', text, re.IGNORECASE)
                if score_match:
                    scores[metric] = {
                        "score": int(score_match.group(1)),
                        "reasoning": "Parsed from text evaluation"
                    }
                else:
                    scores[metric] = {
                        "score": 5,  # Default middle score
                        "reasoning": "Could not parse score, using default"
                    }
            else:
                scores[metric] = {
                    "score": 5,
                    "reasoning": "Metric not found in evaluation"
                }
        
        return scores
    
    def _get_fallback_evaluation(self) -> Dict[str, Any]:
        """Get fallback evaluation when LLM judge is not available."""
        fallback_scores = {}
        for metric in self.evaluation_criteria.keys():
            fallback_scores[metric] = {
                "score": 5,
                "reasoning": "LLM judge not available, using default score"
            }
        
        return {
            "success": False,
            "evaluation_timestamp": datetime.now().isoformat(),
            "scores": fallback_scores,
            "raw_evaluation": "LLM judge not available",
            "model_used": "fallback"
        }
    
    def evaluate_batch(self, interactions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Evaluate a batch of interactions."""
        results = []
        
        for i, interaction in enumerate(interactions):
            print(f"Evaluating interaction {i+1}/{len(interactions)}...")
            
            evaluation = self.evaluate_interaction(**interaction)
            results.append(evaluation)
            
            # Small delay to avoid rate limiting
            time.sleep(0.5)
        
        return results
