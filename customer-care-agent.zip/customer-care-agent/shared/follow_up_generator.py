#!/usr/bin/env python3
"""
Follow-up Question Generator for Customer Care Agent System
Uses LLM to generate intelligent follow-up questions based on chat context
"""

import json
import os
from typing import List, Dict, Optional, Any
from datetime import datetime

# Import OpenAI with compatibility for both old and new versions
try:
    from openai import OpenAI
    OPENAI_NEW_VERSION = True
except ImportError:
    import openai
    OPENAI_NEW_VERSION = False

class FollowUpGenerator:
    """Generates intelligent follow-up questions using LLM."""
    
    def __init__(self, api_key: str = None):
        """
        Initialize the follow-up generator.
        
        Args:
            api_key: OpenAI API key
        """
        self.api_key = api_key or os.getenv('OPENAI_API_KEY')
        
        if OPENAI_NEW_VERSION:
            self.client = OpenAI(api_key=self.api_key) if self.api_key else None
        else:
            if self.api_key:
                openai.api_key = self.api_key
    
    def generate_follow_up_questions(self, chat_context: Dict[str, Any], 
                                   user_profile: Dict[str, Any] = None) -> List[str]:
        """
        Generate follow-up questions based on chat context.
        
        Args:
            chat_context: Current chat session context
            user_profile: User profile information
            
        Returns:
            List of generated follow-up questions
        """
        try:
            # Prepare context for LLM
            context_prompt = self._prepare_context_prompt(chat_context, user_profile)
            
            # Generate follow-up questions using LLM
            if OPENAI_NEW_VERSION and self.client:
                response = self.client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=[
                        {
                            "role": "system",
                            "content": "You are an intelligent customer care assistant. Generate 2-3 relevant, helpful follow-up questions based on the conversation context. Questions should be natural, empathetic, and help ensure customer satisfaction. Return only the questions, one per line."
                        },
                        {
                            "role": "user",
                            "content": context_prompt
                        }
                    ],
                    max_tokens=200,
                    temperature=0.7
                )
                questions_text = response.choices[0].message.content.strip()
            else:
                # Fallback for old version
                response = openai.ChatCompletion.create(
                    model="gpt-4o-mini",
                    messages=[
                        {
                            "role": "system",
                            "content": "You are an intelligent customer care assistant. Generate 2-3 relevant, helpful follow-up questions based on the conversation context. Questions should be natural, empathetic, and help ensure customer satisfaction. Return only the questions, one per line."
                        },
                        {
                            "role": "user",
                            "content": context_prompt
                        }
                    ],
                    max_tokens=200,
                    temperature=0.7
                )
                questions_text = response.choices[0].message.content.strip()
            
            # Parse response
            questions = [q.strip() for q in questions_text.split('\n') if q.strip()]
            
            # Filter and validate questions
            validated_questions = self._validate_questions(questions)
            
            return validated_questions[:3]  # Return max 3 questions
            
        except Exception as e:
            print(f"⚠️ LLM follow-up generation failed: {e}")
            return self._get_fallback_questions(chat_context)
    
    def _prepare_context_prompt(self, chat_context: Dict[str, Any], 
                               user_profile: Dict[str, Any] = None) -> str:
        """Prepare context prompt for LLM."""
        
        # Extract conversation history
        conversation = chat_context.get("conversation", [])
        conversation_text = ""
        for msg in conversation[-5:]:  # Last 5 messages
            role = "Customer" if msg["role"] == "user" else "Assistant"
            conversation_text += f"{role}: {msg['message']}\n"
        
        # Extract topics and intents
        topics = chat_context.get("topics", [])
        intents = chat_context.get("intents", [])
        
        # Extract user info
        user_info = ""
        if user_profile:
            user_info = f"Customer: {user_profile.get('first_name', '')} {user_profile.get('last_name', '')}\n"
            user_info += f"Previous topics: {', '.join(user_profile.get('recent_topics', []))}\n"
            user_info += f"Previous intents: {', '.join(user_profile.get('recent_intents', []))}\n"
        
        # Build context prompt
        prompt = f"""Recent conversation:
{conversation_text}

Current topics discussed: {', '.join(topics) if topics else 'None'}
Current intents: {', '.join(intents) if intents else 'None'}

{user_info}

Based on this conversation, generate 2-3 helpful follow-up questions that:
1. Show empathy and care for the customer
2. Ensure their issue is fully resolved
3. Gather feedback on service quality
4. Offer additional help if needed

Generate questions that feel natural and conversational."""
        
        return prompt
    
    def _validate_questions(self, questions: List[str]) -> List[str]:
        """Validate and clean generated questions."""
        validated = []
        
        for question in questions:
            # Remove question marks if they're at the beginning
            question = question.strip()
            if question.startswith('?'):
                question = question[1:].strip()
            
            # Ensure question ends with question mark
            if not question.endswith('?'):
                question += '?'
            
            # Basic validation
            if len(question) > 10 and len(question) < 150:
                validated.append(question)
        
        return validated
    
    def _get_fallback_questions(self, chat_context: Dict[str, Any]) -> List[str]:
        """Generate fallback questions when LLM fails."""
        
        # Get topics and intents for context-aware fallbacks
        topics = chat_context.get("topics", [])
        intents = chat_context.get("intents", [])
        
        # Default questions
        fallback_questions = [
            "Is there anything else I can help you with today?",
            "How would you rate our service today?",
            "Do you have any other questions or concerns?"
        ]
        
        # Context-specific fallbacks
        if "order_status" in intents or "order" in topics:
            fallback_questions = [
                "Did this information help with your order inquiry?",
                "Is there anything else you'd like to know about your order?",
                "How would you rate our order support today?"
            ]
        elif "troubleshooting" in intents or "problem" in topics:
            fallback_questions = [
                "Did the troubleshooting steps help resolve your issue?",
                "Are you still experiencing any problems?",
                "How would you rate our technical support?"
            ]
        elif "refund" in intents or "refund" in topics:
            fallback_questions = [
                "Was the refund process clear and helpful?",
                "Do you have any questions about the refund timeline?",
                "How would you rate our refund support?"
            ]
        
        return fallback_questions
    
    def generate_contextual_questions(self, current_intent: str, 
                                    previous_topics: List[str] = None,
                                    user_satisfaction: Optional[int] = None) -> List[str]:
        """
        Generate contextual follow-up questions based on current intent and history.
        
        Args:
            current_intent: Current conversation intent
            previous_topics: Previous conversation topics
            user_satisfaction: User satisfaction rating (1-5)
            
        Returns:
            List of contextual questions
        """
        
        # Intent-specific question templates
        intent_questions = {
            "order_status": [
                "Is there anything else you'd like to know about your order?",
                "Would you like to set up notifications for order updates?",
                "How satisfied are you with our order tracking system?"
            ],
            "troubleshooting": [
                "Did the troubleshooting steps resolve your issue?",
                "Would you like me to follow up on this issue?",
                "How would you rate our technical support today?"
            ],
            "refunds": [
                "Was the refund process clear and easy to understand?",
                "Do you have any questions about the refund timeline?",
                "How satisfied are you with our refund policy?"
            ],
            "general_inquiry": [
                "Did I answer all your questions today?",
                "Is there anything else I can help you with?",
                "How would you rate our customer service?"
            ],
            "product_info": [
                "Would you like more information about our other products?",
                "Are you considering making a purchase today?",
                "How helpful was the product information I provided?"
            ]
        }
        
        # Get base questions for current intent
        questions = intent_questions.get(current_intent, intent_questions["general_inquiry"])
        
        # Modify based on user satisfaction
        if user_satisfaction is not None:
            if user_satisfaction >= 4:
                # High satisfaction - focus on additional help
                questions = [
                    "Is there anything else I can help you with today?",
                    "Would you like to hear about our other services?",
                    "Thank you for the positive feedback! Anything else?"
                ]
            elif user_satisfaction <= 2:
                # Low satisfaction - focus on improvement
                questions = [
                    "I apologize for any inconvenience. How can we improve?",
                    "Would you like to speak with a supervisor?",
                    "What could we have done better to help you?"
                ]
        
        # Add context from previous topics
        if previous_topics and len(previous_topics) > 0:
            if "order" in previous_topics and current_intent != "order_status":
                questions.insert(0, "I noticed you've asked about orders before. Any updates on that?")
            elif "problem" in previous_topics and current_intent != "troubleshooting":
                questions.insert(0, "Since our last conversation, has the issue been resolved?")
        
        return questions[:3]  # Return max 3 questions
    
    def generate_feedback_questions(self, chat_duration: float, 
                                  conversation_length: int) -> List[str]:
        """
        Generate feedback-focused questions based on chat metrics.
        
        Args:
            chat_duration: Chat duration in minutes
            conversation_length: Number of messages exchanged
            
        Returns:
            List of feedback questions
        """
        
        # Duration-based questions
        if chat_duration > 10:
            # Long conversation - focus on comprehensive feedback
            questions = [
                "We've had a detailed conversation today. How satisfied are you overall?",
                "Did we address all your concerns thoroughly?",
                "Would you recommend our service to others?"
            ]
        elif chat_duration < 2:
            # Quick conversation - focus on efficiency
            questions = [
                "Was your question answered quickly and clearly?",
                "Did we resolve your issue efficiently?",
                "How would you rate our response time?"
            ]
        else:
            # Medium conversation - balanced feedback
            questions = [
                "How would you rate our customer service today?",
                "Was your issue resolved to your satisfaction?",
                "Is there anything we could improve?"
            ]
        
        return questions

def test_follow_up_generator():
    """Test the follow-up generator functionality."""
    print("🧪 Testing Follow-up Question Generator...")
    
    # Initialize generator
    generator = FollowUpGenerator()
    
    # Test context preparation
    chat_context = {
        "conversation": [
            {"role": "user", "message": "I need help with my order"},
            {"role": "assistant", "message": "I'd be happy to help with your order. What's your order number?"}
        ],
        "topics": ["order_status"],
        "intents": ["order_inquiry"]
    }
    
    user_profile = {
        "first_name": "John",
        "last_name": "Doe",
        "recent_topics": ["order_status", "shipping"],
        "recent_intents": ["order_inquiry", "tracking"]
    }
    
    # Test LLM-based generation (if API key available)
    try:
        questions = generator.generate_follow_up_questions(chat_context, user_profile)
        print(f"✅ LLM-generated questions: {len(questions)} questions")
        for i, q in enumerate(questions, 1):
            print(f"   {i}. {q}")
    except Exception as e:
        print(f"⚠️ LLM generation failed (expected if no API key): {e}")
    
    # Test fallback questions
    fallback_questions = generator._get_fallback_questions(chat_context)
    print(f"✅ Fallback questions: {len(fallback_questions)} questions")
    for i, q in enumerate(fallback_questions, 1):
        print(f"   {i}. {q}")
    
    # Test contextual questions
    contextual_questions = generator.generate_contextual_questions("order_status", ["shipping"])
    print(f"✅ Contextual questions: {len(contextual_questions)} questions")
    for i, q in enumerate(contextual_questions, 1):
        print(f"   {i}. {q}")
    
    # Test feedback questions
    feedback_questions = generator.generate_feedback_questions(5.5, 8)
    print(f"✅ Feedback questions: {len(feedback_questions)} questions")
    for i, q in enumerate(feedback_questions, 1):
        print(f"   {i}. {q}")
    
    print("🎉 Follow-up generator tests completed!")

if __name__ == "__main__":
    test_follow_up_generator()
