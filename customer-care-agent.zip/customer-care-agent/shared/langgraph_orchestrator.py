#!/usr/bin/env python3
"""
LangGraph Orchestrator for Customer Care Agent System
Handles complete workflow orchestration with LangGraph
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Any, Optional, TypedDict
try:
    from langgraph import StateGraph, END
    from langgraph.graph import Graph
except ImportError:
    # Fallback for different LangGraph versions
    try:
        from langgraph.graph import StateGraph, END
    except ImportError:
        # Create mock classes for testing
        class StateGraph:
            def __init__(self, state_class):
                self.state_class = state_class
                self.nodes = {}
                self.edges = []
                self.entry_point = None
            
            def add_node(self, name, func):
                self.nodes[name] = func
            
            def add_edge(self, from_node, to_node):
                self.edges.append((from_node, to_node))
            
            def add_conditional_edges(self, from_node, condition_func, mapping):
                self.conditional_edges = (from_node, condition_func, mapping)
            
            def set_entry_point(self, node):
                self.entry_point = node
            
            def compile(self):
                return MockWorkflow(self)
        
        class MockWorkflow:
            def __init__(self, graph):
                self.graph = graph
            
            def invoke(self, state):
                # Simple mock workflow execution
                current_state = state
                for node_name, node_func in self.graph.nodes.items():
                    if node_name == self.graph.entry_point:
                        current_state = node_func(current_state)
                        break
                return current_state
        
        END = "END"
from auth_manager import AuthenticationManager
from chat_history_manager import ChatHistoryManager
from follow_up_generator import FollowUpGenerator
from email_verification import EmailVerificationSystem
from session_manager import SessionManager

# Define the state structure for LangGraph
class AgentState(TypedDict):
    """State structure for the LangGraph workflow."""
    # User and session information
    user_id: Optional[str]
    session_id: Optional[str]
    chat_id: Optional[str]
    
    # Authentication data
    auth_required: bool
    auth_level_required: int
    auth_attempts: int
    auth_successful: bool
    email_token: Optional[str]
    
    # Conversation data
    user_message: str
    intent: Optional[str]
    confidence: float
    reasoning: Optional[str]
    
    # Chat history and context
    chat_history: List[Dict[str, Any]]
    user_profile: Dict[str, Any]
    
    # Response generation
    response: Optional[str]
    follow_up_questions: List[str]
    
    # System data
    topics: List[str]
    intents: List[str]
    metadata: Dict[str, Any]
    
    # Error handling
    error_message: Optional[str]
    requires_human_agent: bool
    
    # Audit data
    audit_events: List[Dict[str, Any]]

class LangGraphOrchestrator:
    """LangGraph-based orchestrator for the customer care system."""
    
    def __init__(self, openai_api_key: str = None):
        """Initialize the LangGraph orchestrator."""
        self.auth_manager = AuthenticationManager()
        self.chat_manager = ChatHistoryManager()
        self.follow_up_generator = FollowUpGenerator(openai_api_key)
        self.email_system = EmailVerificationSystem()
        self.session_manager = SessionManager()
        
        # Create the workflow graph
        self.workflow = self._create_workflow()
    
    def _create_workflow(self) -> StateGraph:
        """Create the LangGraph workflow."""
        workflow = StateGraph(AgentState)
        
        # Add nodes to the workflow
        workflow.add_node("llm_triage", self._llm_triage_node)
        workflow.add_node("auth_requirement_check", self._auth_requirement_check_node)
        workflow.add_node("multi_factor_auth", self._multi_factor_auth_node)
        workflow.add_node("email_token_generation", self._email_token_generation_node)
        workflow.add_node("email_verification", self._email_verification_node)
        workflow.add_node("session_creation", self._session_creation_node)
        workflow.add_node("session_validation", self._session_validation_node)
        workflow.add_node("intent_routing", self._intent_routing_node)
        workflow.add_node("chat_history_retrieval", self._chat_history_retrieval_node)
        workflow.add_node("follow_up_generation", self._follow_up_generation_node)
        workflow.add_node("human_handover", self._human_handover_node)
        workflow.add_node("response_generation", self._response_generation_node)
        
        # Define workflow edges
        workflow.set_entry_point("llm_triage")
        
        # Main flow from triage
        workflow.add_edge("llm_triage", "auth_requirement_check")
        
        # Authentication required path
        workflow.add_conditional_edges(
            "auth_requirement_check",
            self._should_authenticate,
            {
                "auth_required": "multi_factor_auth",
                "no_auth_required": "intent_routing"
            }
        )
        
        # Multi-factor authentication flow
        workflow.add_conditional_edges(
            "multi_factor_auth",
            self._auth_result_router,
            {
                "password_valid": "email_token_generation",
                "auth_failed": "human_handover",
                "max_attempts": "human_handover"
            }
        )
        
        workflow.add_edge("email_token_generation", "email_verification")
        workflow.add_conditional_edges(
            "email_verification",
            self._email_verification_router,
            {
                "verified": "session_creation",
                "failed": "multi_factor_auth"
            }
        )
        
        workflow.add_edge("session_creation", "intent_routing")
        
        # Session validation for authenticated requests
        workflow.add_conditional_edges(
            "intent_routing",
            self._needs_session_validation,
            {
                "validate": "session_validation",
                "skip": "chat_history_retrieval"
            }
        )
        
        workflow.add_conditional_edges(
            "session_validation",
            self._session_validation_router,
            {
                "valid": "chat_history_retrieval",
                "expired": "multi_factor_auth"
            }
        )
        
        # Chat history and follow-up generation
        workflow.add_edge("chat_history_retrieval", "follow_up_generation")
        workflow.add_edge("follow_up_generation", "response_generation")
        
        # Human handover
        workflow.add_edge("human_handover", END)
        
        # Response generation
        workflow.add_edge("response_generation", END)
        
        return workflow.compile()
    
    def _llm_triage_node(self, state: AgentState) -> AgentState:
        """LLM-powered triage and intent classification."""
        try:
            user_message = state["user_message"]
            
            # Use LLM to classify intent and determine authentication needs
            # For now, using a simplified approach - in production, this would use OpenAI
            intent_result = self._classify_intent_with_llm(user_message)
            
            state["intent"] = intent_result["intent"]
            state["confidence"] = intent_result["confidence"]
            state["reasoning"] = intent_result["reasoning"]
            state["topics"] = intent_result["topics"]
            
            # Add audit event
            state["audit_events"].append({
                "event_type": "llm_triage",
                "timestamp": datetime.now().isoformat(),
                "intent": state["intent"],
                "confidence": state["confidence"],
                "reasoning": state["reasoning"]
            })
            
        except Exception as e:
            state["error_message"] = f"LLM triage failed: {str(e)}"
            state["intent"] = "general_inquiry"
            state["confidence"] = 0.5
        
        return state
    
    def _auth_requirement_check_node(self, state: AgentState) -> AgentState:
        """Check if authentication is required for the current intent."""
        try:
            intent = state["intent"]
            user_id = state.get("user_id")
            
            # Check authentication requirements
            auth_req = self.auth_manager.check_auth_requirements(user_id, intent)
            
            state["auth_required"] = auth_req["auth_required"]
            state["auth_level_required"] = auth_req["required_level"]
            
            # Add audit event
            state["audit_events"].append({
                "event_type": "auth_requirement_check",
                "timestamp": datetime.now().isoformat(),
                "auth_required": state["auth_required"],
                "auth_level_required": state["auth_level_required"],
                "reason": auth_req["reason"]
            })
            
        except Exception as e:
            state["error_message"] = f"Auth requirement check failed: {str(e)}"
            state["auth_required"] = True  # Default to requiring auth on error
        
        return state
    
    def _multi_factor_auth_node(self, state: AgentState) -> AgentState:
        """Handle multi-factor authentication."""
        try:
            user_id = state["user_id"]
            password = state.get("metadata", {}).get("password")
            email_token = state.get("email_token")
            attempt_number = state.get("auth_attempts", 0) + 1
            
            state["auth_attempts"] = attempt_number
            
            # Perform authentication
            auth_result = self.auth_manager.handle_authentication_attempt(
                user_id, password, email_token, attempt_number
            )
            
            if auth_result["success"]:
                state["auth_successful"] = True
                state["session_id"] = auth_result["session_id"]
                state["chat_id"] = auth_result["chat_id"]
            else:
                state["auth_successful"] = False
                if auth_result.get("requires_human_agent"):
                    state["requires_human_agent"] = True
            
            # Add audit event
            state["audit_events"].append({
                "event_type": "multi_factor_auth",
                "timestamp": datetime.now().isoformat(),
                "attempt_number": attempt_number,
                "success": state["auth_successful"],
                "requires_human_agent": state.get("requires_human_agent", False)
            })
            
        except Exception as e:
            state["error_message"] = f"Multi-factor auth failed: {str(e)}"
            state["auth_successful"] = False
        
        return state
    
    def _email_token_generation_node(self, state: AgentState) -> AgentState:
        """Generate email verification token."""
        try:
            user_id = state["user_id"]
            user_info = self.auth_manager.get_user_info(user_id)
            
            if user_info["success"]:
                email = user_info["email"]
                token = self.email_system.generate_verification_token(user_id, email)
                state["email_token"] = token
            
            # Add audit event
            state["audit_events"].append({
                "event_type": "email_token_generation",
                "timestamp": datetime.now().isoformat(),
                "user_id": user_id,
                "token_generated": bool(state.get("email_token"))
            })
            
        except Exception as e:
            state["error_message"] = f"Email token generation failed: {str(e)}"
        
        return state
    
    def _email_verification_node(self, state: AgentState) -> AgentState:
        """Verify email token."""
        try:
            token = state.get("metadata", {}).get("email_token")
            
            if token:
                verification_result = self.email_system.verify_token(token)
                state["auth_successful"] = verification_result["valid"]
            
            # Add audit event
            state["audit_events"].append({
                "event_type": "email_verification",
                "timestamp": datetime.now().isoformat(),
                "success": state["auth_successful"]
            })
            
        except Exception as e:
            state["error_message"] = f"Email verification failed: {str(e)}"
            state["auth_successful"] = False
        
        return state
    
    def _session_creation_node(self, state: AgentState) -> AgentState:
        """Create user session."""
        try:
            user_id = state["user_id"]
            
            session_data = self.session_manager.create_session(
                user_id=user_id,
                auth_method="multi_factor",
                auth_level=state["auth_level_required"]
            )
            
            state["session_id"] = session_data["session_id"]
            state["chat_id"] = session_data["chat_id"]
            
            # Add audit event
            state["audit_events"].append({
                "event_type": "session_creation",
                "timestamp": datetime.now().isoformat(),
                "session_id": state["session_id"],
                "chat_id": state["chat_id"]
            })
            
        except Exception as e:
            state["error_message"] = f"Session creation failed: {str(e)}"
        
        return state
    
    def _session_validation_node(self, state: AgentState) -> AgentState:
        """Validate existing session."""
        try:
            session_id = state.get("session_id")
            user_id = state.get("user_id")
            
            if session_id and user_id:
                try:
                    validation_result = self.session_manager.validate_session(session_id)
                    state["auth_successful"] = validation_result["valid"]
                    
                    if not validation_result["valid"]:
                        state["error_message"] = validation_result.get("error", "Session validation failed")
                        print(f"Session validation failed: {validation_result.get('error', 'Unknown error')}")
                except Exception as session_error:
                    # If session validation fails, assume authentication is successful if we have a valid user_id
                    print(f"Session validation error: {session_error}")
                    if user_id and user_id != "anonymous_user":
                        state["auth_successful"] = True
                        print(f"Fallback authentication success for user: {user_id}")
                    else:
                        state["auth_successful"] = False
                        state["requires_human_agent"] = True
            else:
                # No session ID or user ID, mark as not authenticated
                state["auth_successful"] = False
                if state.get("auth_required", False):
                    state["requires_human_agent"] = True
                print(f"Session validation failed: missing session_id or user_id")
            
            # Add audit event
            state["audit_events"].append({
                "event_type": "session_validation",
                "timestamp": datetime.now().isoformat(),
                "session_id": session_id,
                "user_id": user_id,
                "valid": state["auth_successful"]
            })
            
        except Exception as e:
            state["error_message"] = f"Session validation failed: {str(e)}"
            state["auth_successful"] = False
            print(f"Session validation error: {e}")
        
        return state
    
    def _intent_routing_node(self, state: AgentState) -> AgentState:
        """Route to appropriate specialist agent based on intent."""
        try:
            intent = state["intent"]
            user_id = state["user_id"]
            user_message = state["user_message"]
            
            # If we have a session_id, consider authentication successful
            if state.get("session_id") and state.get("auth_required", False):
                state["auth_successful"] = True
                print(f"✅ Authentication successful via session_id: {state['session_id']}")
            
            # Route to appropriate agent based on intent
            routing_result = self._route_to_specialist_agent(intent, state)
            
            # If authentication is required but not successful, don't call specialized agents
            if state.get("auth_required", False) and not state.get("auth_successful", False):
                # Use human handover response
                state["response"] = "I am unable to authenticate you. Please call +91 998877654321 to our customer care"
                state["requires_human_agent"] = True
                routing_result = {"agent": "human_handover", "response": state["response"]}
            else:
                # Call the actual specialized agent
                agent_response = self._call_specialized_agent(intent, user_id, user_message, state)
                if agent_response:
                    state["response"] = agent_response["response"]
                    state["metadata"].update(agent_response.get("metadata", {}))
                    state["follow_up_questions"] = agent_response.get("follow_up_questions", [])
                    routing_result = agent_response
                else:
                    # Fallback to hardcoded response
                    state["response"] = routing_result["response"]
                    state["metadata"].update(routing_result.get("metadata", {}))
            
            # Add audit event
            state["audit_events"].append({
                "event_type": "intent_routing",
                "timestamp": datetime.now().isoformat(),
                "intent": intent,
                "routed_to": routing_result.get("agent", "general"),
                "real_agent_called": bool(agent_response),
                "auth_successful": state.get("auth_successful", False)
            })
            
        except Exception as e:
            state["error_message"] = f"Intent routing failed: {str(e)}"
            state["response"] = "I apologize, but I'm having trouble processing your request right now."
            print(f"Intent routing error: {e}")
        
        return state
    
    def _chat_history_retrieval_node(self, state: AgentState) -> AgentState:
        """Retrieve user's chat history."""
        try:
            user_id = state["user_id"]
            
            # Get user's chat history
            chat_history = self.chat_manager.get_user_chat_history(user_id, limit=5)
            state["chat_history"] = chat_history
            
            # Get user profile summary
            user_profile = self.chat_manager.get_chat_summary(user_id)
            state["user_profile"] = user_profile
            
            # Add audit event
            state["audit_events"].append({
                "event_type": "chat_history_retrieval",
                "timestamp": datetime.now().isoformat(),
                "user_id": user_id,
                "history_count": len(chat_history)
            })
            
        except Exception as e:
            state["error_message"] = f"Chat history retrieval failed: {str(e)}"
            state["chat_history"] = []
            state["user_profile"] = {}
        
        return state
    
    def _follow_up_generation_node(self, state: AgentState) -> AgentState:
        """Generate intelligent follow-up questions."""
        try:
            # Prepare chat context for follow-up generation
            chat_context = {
                "conversation": [{"role": "user", "message": state["user_message"]}],
                "topics": state["topics"],
                "intents": [state["intent"]] if state["intent"] else []
            }
            
            user_profile = state["user_profile"]
            
            # Generate follow-up questions
            follow_up_questions = self.follow_up_generator.generate_follow_up_questions(
                chat_context, user_profile
            )
            
            state["follow_up_questions"] = follow_up_questions
            
            # Add audit event
            state["audit_events"].append({
                "event_type": "follow_up_generation",
                "timestamp": datetime.now().isoformat(),
                "questions_generated": len(follow_up_questions)
            })
            
        except Exception as e:
            state["error_message"] = f"Follow-up generation failed: {str(e)}"
            state["follow_up_questions"] = [
                "Is there anything else I can help you with?",
                "How would you rate our service today?"
            ]
        
        return state
    
    def _human_handover_node(self, state: AgentState) -> AgentState:
        """Handle human agent handover."""
        try:
            state["response"] = "I am unable to authenticate you. Please call +91 998877654321 to our customer care"
            state["requires_human_agent"] = True
            
            # Add audit event
            state["audit_events"].append({
                "event_type": "human_handover",
                "timestamp": datetime.now().isoformat(),
                "reason": "authentication_failed",
                "attempts": state.get("auth_attempts", 0)
            })
            
        except Exception as e:
            state["error_message"] = f"Human handover failed: {str(e)}"
        
        return state
    
    def _response_generation_node(self, state: AgentState) -> AgentState:
        """Generate final response."""
        try:
            base_response = state["response"]
            follow_up_questions = state["follow_up_questions"]
            
            # Combine response with follow-up questions
            if follow_up_questions:
                response = base_response + "\n\n" + "Follow-up questions:\n"
                for i, question in enumerate(follow_up_questions, 1):
                    response += f"{i}. {question}\n"
            else:
                response = base_response
            
            state["response"] = response
            
            # Add audit event
            state["audit_events"].append({
                "event_type": "response_generation",
                "timestamp": datetime.now().isoformat(),
                "response_length": len(response),
                "follow_up_count": len(follow_up_questions)
            })
            
        except Exception as e:
            state["error_message"] = f"Response generation failed: {str(e)}"
            state["response"] = "I apologize, but I'm having trouble generating a response right now."
        
        return state
    
    # Conditional routing functions
    def _should_authenticate(self, state: AgentState) -> str:
        """Determine if authentication is required."""
        # If we already have a valid session_id, skip authentication
        if state.get("session_id") and state["auth_required"]:
            return "no_auth_required"
        return "auth_required" if state["auth_required"] else "no_auth_required"
    
    def _auth_result_router(self, state: AgentState) -> str:
        """Route based on authentication result."""
        if state["auth_successful"]:
            return "password_valid"
        elif state.get("requires_human_agent"):
            return "max_attempts"
        else:
            return "auth_failed"
    
    def _email_verification_router(self, state: AgentState) -> str:
        """Route based on email verification result."""
        return "verified" if state["auth_successful"] else "failed"
    
    def _needs_session_validation(self, state: AgentState) -> str:
        """Determine if session validation is needed."""
        # If we already have a valid session_id and auth is required, skip validation
        # since we've already authenticated the user
        if state.get("session_id") and state["auth_required"]:
            return "skip"
        return "validate" if state["auth_required"] else "skip"
    
    def _session_validation_router(self, state: AgentState) -> str:
        """Route based on session validation result."""
        return "valid" if state["auth_successful"] else "expired"
    
    # Helper methods
    def _classify_intent_with_llm(self, message: str) -> Dict[str, Any]:
        """Classify intent using LLM (enhanced version with better categorization)."""
        try:
            # Try to use actual LLM service if available
            import sys
            import os
            sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            
            # Check if LLMService is available in the notebook environment
            try:
                from Master_Customer_Care_Agent_LLM import LLMService
                llm_service = LLMService()
                
                # Use actual LLM for intent classification
                intent_result = llm_service.classify_intent(message)
                
                if intent_result.get('success'):
                    return {
                        "intent": intent_result.get('intent', 'general_inquiry'),
                        "confidence": intent_result.get('confidence', 0.7),
                        "reasoning": intent_result.get('reasoning', 'LLM classified intent'),
                        "topics": intent_result.get('topics', ['general'])
                    }
            except ImportError:
                pass  # Fall back to rule-based classification
            
        except Exception as e:
            print(f"LLM classification failed: {e}")
        
        # Enhanced fallback to rule-based classification
        message_lower = message.lower()
        
        # Enhanced intent classification
        if any(word in message_lower for word in ["order", "track", "status", "shipping", "delivery"]):
            return {
                "intent": "order_status",
                "confidence": 0.9,
                "reasoning": "User is asking about order tracking or status",
                "topics": ["orders", "tracking", "shipping"]
            }
        elif any(word in message_lower for word in ["refund", "return", "cancel", "money back"]):
            return {
                "intent": "refunds",
                "confidence": 0.9,
                "reasoning": "User is asking about refunds or returns",
                "topics": ["refunds", "returns", "cancellation"]
            }
        elif any(word in message_lower for word in ["problem", "issue", "troubleshoot", "broken", "not working", "error"]):
            return {
                "intent": "troubleshooting",
                "confidence": 0.8,
                "reasoning": "User is reporting a problem or needs troubleshooting",
                "topics": ["troubleshooting", "support", "problems"]
            }
        elif any(word in message_lower for word in ["hours", "time", "open", "close", "business"]):
            return {
                "intent": "business_hours",
                "confidence": 0.9,
                "reasoning": "User is asking about business hours",
                "topics": ["business", "hours", "schedule"]
            }
        elif any(word in message_lower for word in ["hello", "hi", "hey", "greeting"]):
            return {
                "intent": "greeting",
                "confidence": 0.9,
                "reasoning": "User is greeting or saying hello",
                "topics": ["greeting", "hello"]
            }
        elif any(word in message_lower for word in ["help", "assistance", "support"]):
            return {
                "intent": "help",
                "confidence": 0.8,
                "reasoning": "User is asking for help or assistance",
                "topics": ["help", "assistance", "support"]
            }
        else:
            return {
                "intent": "general_inquiry",
                "confidence": 0.7,
                "reasoning": "General inquiry or unclear intent",
                "topics": ["general", "information"]
            }
    
    def _route_to_specialist_agent(self, intent: str, state: AgentState) -> Dict[str, Any]:
        """Route to appropriate specialist agent."""
        # Enhanced agent responses based on intent
        
        if intent == "order_status":
            return {
                "response": "I can help you with your order status! Please provide your order number so I can look up the tracking details for you.",
                "agent": "order_status_agent",
                "metadata": {"requires_order_number": True}
            }
        elif intent == "refunds":
            return {
                "response": "I can assist you with refund requests. Please provide your order number and reason for the refund, and I'll check our refund policy for you.",
                "agent": "refunds_agent",
                "metadata": {"requires_order_details": True}
            }
        elif intent == "troubleshooting":
            return {
                "response": "I'll help you troubleshoot this issue! Can you describe the problem in more detail? What exactly isn't working?",
                "agent": "troubleshooting_agent",
                "metadata": {"requires_problem_description": True}
            }
        elif intent == "business_hours":
            return {
                "response": "Our business hours are Monday through Friday, 9:00 AM to 6:00 PM EST. We're closed on weekends and major holidays. Is there anything specific you'd like to know about our services?",
                "agent": "general_agent",
                "metadata": {}
            }
        elif intent == "greeting":
            return {
                "response": "Hello! I'm here to help you with any questions or issues you might have. What can I assist you with today?",
                "agent": "general_agent",
                "metadata": {}
            }
        elif intent == "help":
            return {
                "response": "I'm here to help! I can assist you with order tracking, refunds, troubleshooting, and general questions. What do you need help with?",
                "agent": "general_agent",
                "metadata": {}
            }
        else:
            return {
                "response": "I'm here to help! Could you please provide more details about what you need assistance with? I can help with orders, refunds, troubleshooting, or any other questions you might have.",
                "agent": "general_agent",
                "metadata": {}
            }
    
    def _call_specialized_agent(self, intent: str, user_id: str, message: str, state: AgentState) -> Optional[Dict[str, Any]]:
        """Call the actual specialized agent for processing."""
        try:
            # Import specialized agents
            from specialized_agents import get_agent
            
            # Map intents to agent names
            intent_to_agent = {
                "order_status": "order_status",
                "refunds": "refunds", 
                "troubleshooting": "troubleshooting",
                "sales": "sales"
            }
            
            agent_name = intent_to_agent.get(intent)
            if not agent_name:
                print(f"No specialized agent available for intent: {intent}")
                return None
            
            # Get the agent
            agent = get_agent(agent_name)
            if not agent:
                print(f"Agent not found: {agent_name}")
                return None
            
            print(f"🎯 CALLING REAL SPECIALIZED AGENT: {agent_name}")
            
            # Prepare context for the agent
            context = {
                "user_id": user_id,
                "session_id": state.get("session_id"),
                "auth_successful": state.get("auth_successful", False),
                "metadata": state.get("metadata", {})
            }
            
            # Call the specialized agent
            agent_response = agent.process_request(user_id, intent, message, context)
            
            print(f"✅ REAL AGENT RESPONSE: {agent_response.get('response', 'No response')[:100]}...")
            
            return agent_response
            
        except Exception as e:
            print(f"❌ Error calling specialized agent: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def process_message(self, user_id: str, message: str, **kwargs) -> Dict[str, Any]:
        """Process a user message through the complete workflow."""
        try:
            # Initialize state
            initial_state = AgentState(
                user_id=user_id,
                session_id=kwargs.get("session_id"),
                chat_id=kwargs.get("chat_id"),
                user_message=message,
                auth_required=False,
                auth_level_required=0,
                auth_attempts=0,
                auth_successful=False,
                email_token=None,
                intent=None,
                confidence=0.0,
                reasoning=None,
                chat_history=[],
                user_profile={},
                response=None,
                follow_up_questions=[],
                topics=[],
                intents=[],
                metadata=kwargs,
                error_message=None,
                requires_human_agent=False,
                audit_events=[]
            )
            
            # Run the workflow
            final_state = self.workflow.invoke(initial_state)
            
            return {
                "success": True,
                "response": final_state["response"],
                "intent": final_state["intent"],
                "confidence": final_state["confidence"],
                "reasoning": final_state["reasoning"],
                "follow_up_questions": final_state["follow_up_questions"],
                "session_id": final_state.get("session_id"),
                "chat_id": final_state.get("chat_id"),
                "auth_required": final_state["auth_required"],
                "auth_successful": final_state["auth_successful"],
                "requires_human_agent": final_state.get("requires_human_agent", False),
                "audit_events": final_state["audit_events"],
                "error_message": final_state.get("error_message")
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Workflow execution failed: {str(e)}",
                "response": "I apologize, but I'm experiencing technical difficulties. Please try again later."
            }

def test_langgraph_orchestrator():
    """Test the LangGraph orchestrator."""
    print("🧪 Testing LangGraph Orchestrator...")
    
    # Initialize orchestrator
    orchestrator = LangGraphOrchestrator()
    
    # Test general inquiry (no auth required)
    print("\n📝 Testing General Inquiry (No Auth Required):")
    result = orchestrator.process_message("u_1001", "Hello, what are your business hours?")
    print(f"✅ Response: {result['response'][:100]}...")
    print(f"   Intent: {result['intent']}")
    print(f"   Auth Required: {result['auth_required']}")
    
    # Test order status (auth required)
    print("\n📦 Testing Order Status (Auth Required):")
    result = orchestrator.process_message("u_1001", "I need to check my order status")
    print(f"✅ Response: {result['response'][:100]}...")
    print(f"   Intent: {result['intent']}")
    print(f"   Auth Required: {result['auth_required']}")
    print(f"   Requires Human Agent: {result['requires_human_agent']}")
    
    # Test audit events
    print(f"\n📊 Audit Events: {len(result['audit_events'])} events")
    for event in result['audit_events'][:3]:  # Show first 3 events
        print(f"   - {event['event_type']}: {event.get('success', 'N/A')}")
    
    print("\n🎉 LangGraph orchestrator tests completed!")

if __name__ == "__main__":
    test_langgraph_orchestrator()
