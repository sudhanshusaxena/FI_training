#!/usr/bin/env python3
"""
Enhanced Evaluation Runner with Authentication Tracking
Logs detailed authentication data to Matrix.csv
"""

import os
import csv
import json
import time
import random
from datetime import datetime
from typing import Dict, List, Any, Optional
import sys

# Add shared directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from llm_judge_evaluator import LLMJudgeEvaluator
from test_scenario_generator import TestScenarioGenerator
from enhanced_auth_manager import EnhancedAuthenticationManager

class EnhancedEvaluationRunner:
    """Enhanced evaluation runner with comprehensive authentication tracking."""
    
    def __init__(self, system_orchestrator, api_key: str = None):
        """Initialize the enhanced evaluation runner."""
        self.system = system_orchestrator
        self.llm_judge = LLMJudgeEvaluator(api_key)
        self.scenario_generator = TestScenarioGenerator()
        self.enhanced_auth_manager = EnhancedAuthenticationManager()
        self.matrix_file = "Matrix.csv"
        
        # Load demo users
        self.demo_users = self._load_demo_users()
        
        # Initialize CSV file with enhanced headers
        self._initialize_enhanced_matrix_csv()
    
    def _load_demo_users(self) -> List[str]:
        """Load demo user IDs for testing."""
        try:
            with open('shared/fixtures/password_reference.json', 'r') as f:
                credentials = json.load(f)
                return list(credentials.keys())
        except:
            return ['u_1001', 'u_1002', 'u_1003', 'u_1004', 'u_1005']
    
    def _initialize_enhanced_matrix_csv(self):
        """Initialize the Matrix.csv file with enhanced authentication headers."""
        if not os.path.exists(self.matrix_file):
            headers = [
                # Basic test information
                'timestamp', 'test_id', 'user_id', 'scenario_type', 'persona',
                'user_message', 'detected_intent', 'intent_confidence',
                
                # Authentication flow tracking
                'auth_required', 'auth_successful', 'auth_session_started',
                'auth_attempts', 'username_correct', 'password_correct', 'email_correct',
                'auth_failure_reason', 'auth_retry_count', 'auth_step_failed',
                'auth_session_duration', 'session_expired', 're_authentication_required',
                
                # System response
                'human_handover', 'response_time', 'agent_response', 'follow_up_questions',
                
                # LLM Judge scores
                'intent_classification_accuracy_score', 'intent_classification_accuracy_reasoning',
                'response_relevance_score', 'response_relevance_reasoning',
                'auth_decision_correctness_score', 'auth_decision_correctness_reasoning',
                'handover_appropriateness_score', 'handover_appropriateness_reasoning',
                'follow_up_quality_score', 'follow_up_quality_reasoning',
                'overall_satisfaction_score', 'overall_satisfaction_reasoning',
                
                # Business metrics
                'resolution_achieved', 'customer_care_handover', 'handover_reason',
                'contact_number', 'reference_id', 'error_occurred',
                
                # Analytics data
                'llm_judge_reasoning', 'model_used', 'credential_failure_details',
                'authentication_flow_completed', 'total_auth_time'
            ]
            
            with open(self.matrix_file, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(headers)
    
    def run_enhanced_evaluation(self, scenario: Dict[str, Any], user_id: str = None) -> Dict[str, Any]:
        """Run enhanced evaluation with detailed authentication tracking."""
        if user_id is None:
            user_id = random.choice(self.demo_users)
        
        test_id = scenario.get('test_id', f"test_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        user_message = scenario.get('user_message', '')
        scenario_type = scenario.get('scenario_type', 'unknown')
        persona = scenario.get('persona', 'unknown')
        
        print(f"🧪 Running enhanced test: {test_id} - {scenario_type} ({persona})")
        print(f"👤 User: {user_id}")
        print(f"💬 Message: {user_message}")
        
        start_time = time.time()
        auth_session_started = False
        auth_attempts = 0
        auth_successful = False
        auth_failure_reason = None
        auth_step_failed = None
        auth_session_duration = 0
        session_expired = False
        re_authentication_required = False
        customer_care_handover = False
        handover_reason = None
        contact_number = None
        reference_id = None
        credential_failure_details = []
        authentication_flow_completed = False
        total_auth_time = 0
        
        try:
            # Determine if authentication is required
            auth_required = scenario_type in ['order_status', 'refunds', 'troubleshooting', 'account_issues']
            
            if auth_required:
                print(f"🔐 Authentication required for {scenario_type}")
                
                # Start authentication flow
                auth_start_time = time.time()
                auth_result = self.enhanced_auth_manager.start_authentication_flow(user_id)
                auth_session_started = True
                
                if auth_result['success']:
                    print(f"✅ Authentication flow started")
                    
                    # Simulate authentication attempts (for testing)
                    auth_attempts, auth_successful, auth_failure_reason, auth_step_failed, credential_failure_details = self._simulate_auth_attempts(user_id, test_id)
                    
                    total_auth_time = time.time() - auth_start_time
                    auth_session_duration = total_auth_time
                    
                    if auth_successful:
                        print(f"✅ Authentication successful after {auth_attempts} attempts")
                        authentication_flow_completed = True
                    else:
                        print(f"❌ Authentication failed after {auth_attempts} attempts")
                        customer_care_handover = True
                        handover_reason = 'authentication_failed'
                        contact_number = '+91 998877654321'
                        reference_id = f"REF_{test_id}_{int(datetime.now().timestamp())}"
                else:
                    print(f"❌ Failed to start authentication flow")
                    auth_failure_reason = 'session_start_failed'
            
            # Process the message through the system
            result = self.system.process_customer_message(user_id, user_message)
            response_time = time.time() - start_time
            
            # Extract system results
            detected_intent = result.get('intent', 'unknown')
            intent_confidence = result.get('confidence', 0.0)
            human_handover = result.get('requires_human_agent', False)
            agent_response = result.get('response', '')
            follow_up_questions = result.get('follow_up_questions', [])
            
            # Run LLM judge evaluation
            print(f"🤖 Running LLM judge evaluation...")
            evaluation = self.llm_judge.evaluate_interaction(
                user_message=user_message,
                detected_intent=detected_intent,
                intent_confidence=intent_confidence,
                auth_required=auth_required,
                auth_successful=auth_successful,
                human_handover=human_handover,
                agent_response=agent_response,
                follow_up_questions=follow_up_questions,
                response_time=response_time
            )
            
            # Determine resolution status
            resolution_achieved = not customer_care_handover and auth_successful if auth_required else not auth_required
            
            # Prepare enhanced CSV row
            csv_row = self._prepare_enhanced_csv_row(
                test_id, user_id, scenario_type, persona, user_message,
                detected_intent, intent_confidence, auth_required, auth_successful,
                auth_session_started, auth_attempts, auth_failure_reason, auth_step_failed,
                auth_session_duration, session_expired, re_authentication_required,
                human_handover, response_time, agent_response, follow_up_questions,
                evaluation, resolution_achieved, customer_care_handover,
                handover_reason, contact_number, reference_id,
                credential_failure_details, authentication_flow_completed, total_auth_time
            )
            
            # Log to CSV
            self._log_to_csv(csv_row)
            
            print(f"✅ Enhanced test completed successfully")
            print(f"📊 Intent: {detected_intent} (confidence: {intent_confidence:.2f})")
            print(f"🔐 Auth Required: {auth_required}, Successful: {auth_successful}")
            print(f"👨‍💼 Customer Care Handover: {customer_care_handover}")
            print(f"⏱️ Response Time: {response_time:.2f}s, Auth Time: {total_auth_time:.2f}s")
            
            return {
                "success": True,
                "test_id": test_id,
                "scenario_type": scenario_type,
                "persona": persona,
                "auth_required": auth_required,
                "auth_successful": auth_successful,
                "auth_attempts": auth_attempts,
                "customer_care_handover": customer_care_handover,
                "system_result": result,
                "evaluation": evaluation,
                "response_time": response_time,
                "auth_time": total_auth_time,
                "csv_row": csv_row
            }
            
        except Exception as e:
            error_time = time.time() - start_time
            print(f"❌ Enhanced test failed: {e}")
            
            # Log error to CSV
            error_row = self._prepare_error_csv_row(
                test_id, user_id, scenario_type, persona, user_message, str(e), error_time,
                auth_session_started, auth_attempts, customer_care_handover
            )
            self._log_to_csv(error_row)
            
            return {
                "success": False,
                "test_id": test_id,
                "error": str(e),
                "response_time": error_time,
                "auth_attempts": auth_attempts,
                "customer_care_handover": customer_care_handover
            }
    
    def _simulate_auth_attempts(self, user_id: str, test_id: str) -> tuple:
        """Simulate authentication attempts for testing purposes."""
        # Get user credentials for simulation
        try:
            with open('shared/fixtures/password_reference.json', 'r') as f:
                credentials = json.load(f)
                user_creds = credentials.get(user_id, {})
        except:
            return 3, False, 'credentials_not_found', 'all', []
        
        auth_attempts = 0
        auth_successful = False
        auth_failure_reason = None
        auth_step_failed = None
        credential_failure_details = []
        
        # Simulate different failure scenarios based on test_id
        if 'adv_' in test_id:  # Adversarial scenarios - more likely to fail
            failure_scenarios = ['username_failed', 'password_failed', 'email_failed']
            auth_attempts = 3
            auth_successful = False
            auth_failure_reason = 'max_attempts_reached'
            auth_step_failed = random.choice(failure_scenarios)
            credential_failure_details = failure_scenarios
        elif 'multi_' in test_id:  # Multi-turn scenarios - moderate success
            auth_attempts = random.choice([1, 2, 3])
            auth_successful = auth_attempts == 1
            if not auth_successful:
                auth_failure_reason = 'credential_mismatch'
                auth_step_failed = random.choice(['username_failed', 'password_failed'])
                credential_failure_details = [auth_step_failed]
        else:  # Regular scenarios - mostly successful
            auth_attempts = random.choice([1, 2])
            auth_successful = True
            auth_failure_reason = None
            auth_step_failed = None
            credential_failure_details = []
        
        return auth_attempts, auth_successful, auth_failure_reason, auth_step_failed, credential_failure_details
    
    def _prepare_enhanced_csv_row(self, test_id, user_id, scenario_type, persona, user_message,
                                detected_intent, intent_confidence, auth_required, auth_successful,
                                auth_session_started, auth_attempts, auth_failure_reason, auth_step_failed,
                                auth_session_duration, session_expired, re_authentication_required,
                                human_handover, response_time, agent_response, follow_up_questions,
                                evaluation, resolution_achieved, customer_care_handover,
                                handover_reason, contact_number, reference_id,
                                credential_failure_details, authentication_flow_completed, total_auth_time):
        """Prepare an enhanced row for CSV logging."""
        
        scores = evaluation.get('scores', {})
        
        # Determine credential correctness based on failure details
        username_correct = 'username_failed' not in credential_failure_details
        password_correct = 'password_failed' not in credential_failure_details
        email_correct = 'email_failed' not in credential_failure_details
        
        return [
            datetime.now().isoformat(),  # timestamp
            test_id,
            user_id,
            scenario_type,
            persona,
            user_message,
            detected_intent,
            intent_confidence,
            
            # Authentication tracking
            auth_required,
            auth_successful,
            auth_session_started,
            auth_attempts,
            username_correct,
            password_correct,
            email_correct,
            auth_failure_reason,
            auth_attempts - 1 if auth_attempts > 0 else 0,  # retry count
            auth_step_failed,
            auth_session_duration,
            session_expired,
            re_authentication_required,
            
            # System response
            human_handover,
            response_time,
            agent_response,
            json.dumps(follow_up_questions) if follow_up_questions else "",
            
            # LLM Judge scores
            scores.get('intent_classification_accuracy', {}).get('score', 0),
            scores.get('intent_classification_accuracy', {}).get('reasoning', ''),
            scores.get('response_relevance', {}).get('score', 0),
            scores.get('response_relevance', {}).get('reasoning', ''),
            scores.get('auth_decision_correctness', {}).get('score', 0),
            scores.get('auth_decision_correctness', {}).get('reasoning', ''),
            scores.get('handover_appropriateness', {}).get('score', 0),
            scores.get('handover_appropriateness', {}).get('reasoning', ''),
            scores.get('follow_up_quality', {}).get('score', 0),
            scores.get('follow_up_quality', {}).get('reasoning', ''),
            scores.get('overall_satisfaction', {}).get('score', 0),
            scores.get('overall_satisfaction', {}).get('reasoning', ''),
            
            # Business metrics
            resolution_achieved,
            customer_care_handover,
            handover_reason,
            contact_number,
            reference_id,
            False,  # error_occurred
            
            # Analytics data
            evaluation.get('raw_evaluation', ''),
            evaluation.get('model_used', ''),
            json.dumps(credential_failure_details),
            authentication_flow_completed,
            total_auth_time
        ]
    
    def _prepare_error_csv_row(self, test_id, user_id, scenario_type, persona, user_message, error, response_time,
                             auth_session_started, auth_attempts, customer_care_handover):
        """Prepare an error row for CSV logging."""
        return [
            datetime.now().isoformat(),  # timestamp
            test_id,
            user_id,
            scenario_type,
            persona,
            user_message,
            'error',  # detected_intent
            0.0,  # intent_confidence
            False,  # auth_required
            False,  # auth_successful
            auth_session_started,
            auth_attempts,
            False,  # username_correct
            False,  # password_correct
            False,  # email_correct
            f"System error: {error}",  # auth_failure_reason
            0,  # retry count
            'system_error',  # auth_step_failed
            0,  # auth_session_duration
            False,  # session_expired
            False,  # re_authentication_required
            True,  # human_handover (error = handover)
            response_time,
            f"Error: {error}",  # agent_response
            "",  # follow_up_questions
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  # all scores and reasoning
            False,  # resolution_achieved
            customer_care_handover,
            'system_error',  # handover_reason
            '+91 998877654321',  # contact_number
            f"REF_error_{test_id}",  # reference_id
            True,  # error_occurred
            f"System error: {error}",  # llm_judge_reasoning
            'error',  # model_used
            json.dumps(['system_error']),  # credential_failure_details
            False,  # authentication_flow_completed
            0  # total_auth_time
        ]
    
    def _log_to_csv(self, row):
        """Log a row to the Matrix.csv file."""
        with open(self.matrix_file, 'a', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(row)
    
    def run_comprehensive_enhanced_evaluation(self, num_scenarios_per_category: int = 10):
        """Run comprehensive enhanced evaluation with authentication tracking."""
        print("🚀 Starting Comprehensive Enhanced Evaluation")
        print("="*70)
        print("This includes detailed authentication tracking and analytics")
        print("="*70)
        
        # Generate all scenarios
        print("📝 Generating test scenarios...")
        all_scenarios = self.scenario_generator.generate_all_scenarios()
        
        # Get summary
        summary = self.scenario_generator.get_scenario_summary(all_scenarios)
        print(f"✅ Generated {summary['total_scenarios']} total scenarios")
        print(f"📊 By type: {summary['by_type']}")
        print(f"👥 By persona: {summary['by_persona']}")
        print(f"🔐 Auth required: {summary['auth_required_count']}")
        print(f"🔄 Multi-turn: {summary['multi_turn_count']}")
        
        # Run enhanced evaluations
        results = []
        successful_tests = 0
        failed_tests = 0
        total_auth_attempts = 0
        successful_auths = 0
        customer_care_handovers = 0
        
        print(f"\n🧪 Running enhanced evaluations...")
        print("-" * 70)
        
        for i, scenario in enumerate(all_scenarios):
            print(f"\n[{i+1}/{len(all_scenarios)}] Running enhanced test...")
            
            result = self.run_enhanced_evaluation(scenario)
            
            if result['success']:
                successful_tests += 1
                total_auth_attempts += result.get('auth_attempts', 0)
                if result.get('auth_successful', False):
                    successful_auths += 1
                if result.get('customer_care_handover', False):
                    customer_care_handovers += 1
            else:
                failed_tests += 1
            
            results.append(result)
            
            # Small delay between tests
            time.sleep(1)
        
        # Print enhanced summary
        print(f"\n🎉 ENHANCED EVALUATION COMPLETED!")
        print("="*70)
        print(f"✅ Successful tests: {successful_tests}")
        print(f"❌ Failed tests: {failed_tests}")
        print(f"📊 Success rate: {(successful_tests/len(all_scenarios)*100):.1f}%")
        print(f"🔐 Total auth attempts: {total_auth_attempts}")
        print(f"✅ Successful authentications: {successful_auths}")
        print(f"📞 Customer care handovers: {customer_care_handovers}")
        print(f"📈 Auth success rate: {(successful_auths/total_auth_attempts*100):.1f}%" if total_auth_attempts > 0 else "N/A")
        print(f"📄 Results logged to: {self.matrix_file}")
        
        return {
            "total_scenarios": len(all_scenarios),
            "successful_tests": successful_tests,
            "failed_tests": failed_tests,
            "success_rate": successful_tests / len(all_scenarios),
            "total_auth_attempts": total_auth_attempts,
            "successful_auths": successful_auths,
            "customer_care_handovers": customer_care_handovers,
            "auth_success_rate": successful_auths / total_auth_attempts if total_auth_attempts > 0 else 0,
            "results": results,
            "matrix_file": self.matrix_file
        }
