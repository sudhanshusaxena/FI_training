#!/usr/bin/env python3
"""
User Data Generator for Customer Care Agent System
Generates 50-100 realistic users with complete authentication data
"""

import json
import random
import secrets
import bcrypt
from datetime import datetime, timedelta
from typing import List, Dict, Any
import os
from pathlib import Path

class UserDataGenerator:
    """Generates realistic user data for the customer care system."""
    
    def __init__(self):
        self.first_names = [
            "John", "Jane", "Michael", "Sarah", "David", "Emily", "James", "Jessica",
            "Robert", "Ashley", "William", "Amanda", "Richard", "Jennifer", "Thomas",
            "Lisa", "Christopher", "Michelle", "Daniel", "Kimberly", "Matthew", "Amy",
            "Anthony", "Angela", "Mark", "Helen", "Donald", "Brenda", "Steven", "Emma",
            "Paul", "Olivia", "Andrew", "Cynthia", "Joshua", "Marie", "Kenneth", "Janet",
            "Kevin", "Catherine", "Brian", "Frances", "George", "Christine", "Timothy",
            "Samantha", "Ronald", "Deborah", "Jason", "Rachel", "Edward", "Carolyn"
        ]
        
        self.last_names = [
            "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
            "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson",
            "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson",
            "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker",
            "Young", "Allen", "King", "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores",
            "Green", "Adams", "Nelson", "Baker", "Hall", "Rivera", "Campbell", "Mitchell",
            "Carter", "Roberts", "Gomez", "Phillips", "Evans", "Turner", "Diaz", "Parker"
        ]
        
        self.cities = [
            "New York", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia",
            "San Antonio", "San Diego", "Dallas", "San Jose", "Austin", "Jacksonville",
            "Fort Worth", "Columbus", "Charlotte", "San Francisco", "Indianapolis",
            "Seattle", "Denver", "Washington", "Boston", "El Paso", "Nashville", "Detroit",
            "Oklahoma City", "Portland", "Las Vegas", "Memphis", "Louisville", "Baltimore"
        ]
        
        self.states = [
            "NY", "CA", "IL", "TX", "AZ", "PA", "FL", "OH", "NC", "WA", "GA", "MI",
            "VA", "TN", "IN", "MO", "MD", "WI", "CO", "MN", "SC", "AL", "LA", "KY",
            "OR", "OK", "CT", "UT", "IA", "NV", "AR", "MS", "KS", "NM", "NE", "WV",
            "ID", "HI", "NH", "ME", "RI", "MT", "DE", "SD", "ND", "AK", "VT", "WY"
        ]
        
        self.email_domains = [
            "gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "aol.com",
            "icloud.com", "live.com", "msn.com", "comcast.net", "verizon.net",
            "att.net", "sbcglobal.net", "bellsouth.net", "cox.net", "charter.net"
        ]

    def generate_password(self, length: int = 12) -> str:
        """Generate a secure password."""
        characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"
        return ''.join(secrets.choice(characters) for _ in range(length))

    def hash_password(self, password: str) -> str:
        """Hash password using bcrypt."""
        salt = bcrypt.gensalt()
        return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')

    def generate_phone_number(self) -> str:
        """Generate a realistic phone number."""
        area_codes = ["212", "213", "214", "215", "216", "217", "218", "219", "224", "225",
                     "228", "229", "231", "234", "239", "240", "248", "251", "252", "253"]
        area_code = random.choice(area_codes)
        exchange = f"{random.randint(200, 999)}"
        number = f"{random.randint(1000, 9999)}"
        return f"+1-{area_code}-{exchange}-{number}"

    def generate_address(self) -> Dict[str, str]:
        """Generate a realistic address."""
        street_numbers = [str(random.randint(1, 9999))]
        street_names = [
            "Main St", "Oak Ave", "First St", "Second St", "Park Ave", "Elm St",
            "Maple Ave", "Cedar St", "Pine St", "Washington St", "Lincoln Ave",
            "Jefferson St", "Madison Ave", "Franklin St", "Church St", "Broadway",
            "Center St", "High St", "Spring St", "Mill St", "River Rd", "Hill St"
        ]
        
        street = f"{random.choice(street_numbers)} {random.choice(street_names)}"
        city = random.choice(self.cities)
        state = random.choice(self.states)
        zip_code = f"{random.randint(10000, 99999)}"
        
        return {
            "street": street,
            "city": city,
            "state": state,
            "zip": zip_code,
            "country": "USA"
        }

    def generate_email(self, first_name: str, last_name: str) -> str:
        """Generate a realistic email address."""
        email_variations = [
            f"{first_name.lower()}.{last_name.lower()}",
            f"{first_name.lower()}{last_name.lower()}",
            f"{first_name.lower()}{random.randint(1, 99)}",
            f"{first_name.lower()}.{last_name.lower()}{random.randint(1, 99)}",
            f"{last_name.lower()}.{first_name.lower()}",
            f"{first_name[0].lower()}{last_name.lower()}",
            f"{first_name.lower()}{last_name[0].lower()}{random.randint(10, 99)}"
        ]
        
        email_prefix = random.choice(email_variations)
        domain = random.choice(self.email_domains)
        return f"{email_prefix}@{domain}"

    def generate_username(self, first_name: str, last_name: str) -> str:
        """Generate a realistic username."""
        username_variations = [
            f"{first_name.lower()}_{last_name.lower()}",
            f"{first_name.lower()}{last_name.lower()}",
            f"{first_name.lower()}{random.randint(1, 99)}",
            f"{first_name[0].lower()}{last_name.lower()}",
            f"{first_name.lower()}.{last_name.lower()}",
            f"{last_name.lower()}{first_name.lower()}",
            f"{first_name.lower()}{last_name.lower()}{random.randint(10, 99)}"
        ]
        
        return random.choice(username_variations)

    def generate_user(self, user_id: str) -> Dict[str, Any]:
        """Generate a single user with complete data."""
        first_name = random.choice(self.first_names)
        last_name = random.choice(self.last_names)
        
        # Generate password and hash it
        plain_password = self.generate_password()
        password_hash = self.hash_password(plain_password)
        
        # Generate user data
        email = self.generate_email(first_name, last_name)
        username = self.generate_username(first_name, last_name)
        phone = self.generate_phone_number()
        address = self.generate_address()
        
        # Generate timestamps
        created_date = datetime.now() - timedelta(days=random.randint(1, 365))
        last_login = datetime.now() - timedelta(days=random.randint(0, 30))
        login_count = random.randint(1, 50)
        
        # Determine auth level (most users level 2, some level 1)
        auth_level = random.choices([1, 2], weights=[20, 80])[0]
        
        user_data = {
            "user_id": user_id,
            "username": username,
            "password_hash": password_hash,
            "plain_password": plain_password,  # Only for demo purposes - remove in production
            "email": email,
            "email_verified": True,
            "auth_level": auth_level,
            "profile": {
                "first_name": first_name,
                "last_name": last_name,
                "phone": phone,
                "address": address,
                "preferences": {
                    "communication": random.choice(["email", "phone", "sms"]),
                    "language": "en",
                    "timezone": random.choice(["EST", "PST", "CST", "MST"])
                },
                "account_status": "active",
                "created_at": created_date.isoformat(),
                "last_login": last_login.isoformat(),
                "login_count": login_count
            }
        }
        
        return user_data

    def generate_users(self, count: int = 75) -> List[Dict[str, Any]]:
        """Generate multiple users."""
        users = []
        
        for i in range(1, count + 1):
            user_id = f"u_{1000 + i}"
            user_data = self.generate_user(user_id)
            users.append(user_data)
        
        return users

    def save_users_to_file(self, users: List[Dict[str, Any]], file_path: str):
        """Save users to JSON file."""
        # Ensure directory exists
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        # Prepare data structure
        data = {
            "metadata": {
                "generated_at": datetime.now().isoformat(),
                "total_users": len(users),
                "generator_version": "1.0.0"
            },
            "users": users
        }
        
        # Save to file
        with open(file_path, 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"✅ Generated {len(users)} users and saved to {file_path}")

    def create_password_reference_file(self, users: List[Dict[str, Any]], file_path: str):
        """Create a reference file with plain passwords for demo purposes."""
        password_ref = {}
        
        for user in users:
            password_ref[user["user_id"]] = {
                "username": user["username"],
                "email": user["email"],
                "plain_password": user["plain_password"]
            }
        
        with open(file_path, 'w') as f:
            json.dump(password_ref, f, indent=2)
        
        print(f"✅ Created password reference file at {file_path}")

def main():
    """Generate user data for the customer care system."""
    print("🚀 Starting User Data Generation...")
    
    generator = UserDataGenerator()
    
    # Generate 75 users (good middle ground between 50-100)
    users = generator.generate_users(75)
    
    # Define file paths
    users_file = "shared/fixtures/users.json"
    password_ref_file = "shared/fixtures/password_reference.json"
    
    # Save users data
    generator.save_users_to_file(users, users_file)
    
    # Create password reference for demo purposes
    generator.create_password_reference_file(users, password_ref_file)
    
    # Print summary
    print(f"\n📊 Generation Summary:")
    print(f"   Total Users: {len(users)}")
    print(f"   Auth Level 1: {len([u for u in users if u['auth_level'] == 1])}")
    print(f"   Auth Level 2: {len([u for u in users if u['auth_level'] == 2])}")
    print(f"   Verified Emails: {len([u for u in users if u['email_verified']])}")
    print(f"   Active Accounts: {len([u for u in users if u['profile']['account_status'] == 'active'])}")
    
    print(f"\n🎯 Sample Users Generated:")
    for i, user in enumerate(users[:5]):
        print(f"   {i+1}. {user['profile']['first_name']} {user['profile']['last_name']} ({user['user_id']})")
        print(f"      Username: {user['username']}")
        print(f"      Email: {user['email']}")
        print(f"      Auth Level: {user['auth_level']}")
        print(f"      Password: {user['plain_password']}")
        print()

if __name__ == "__main__":
    main()
