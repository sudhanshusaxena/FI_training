# Human-in-the-Loop (HITL) System - Customer Care Agent
"""
Human-in-the-loop approval system for high-impact actions and edge cases.
Handles approval workflows, decision tracking, and escalation management.
"""

import json
import logging
import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path

class ApprovalStatus(Enum):
    """HITL approval status."""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"
    CANCELLED = "cancelled"

class PriorityLevel(Enum):
    """HITL priority levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"

@dataclass
class ApprovalRequest:
    """HITL approval request structure."""
    request_id: str
    action_id: str
    action_type: str
    user_id: str
    session_id: str
    priority: PriorityLevel
    reason: str
    options: List[Dict[str, Any]]
    context: Dict[str, Any]
    created_at: str
    expires_at: str
    assigned_to: Optional[str] = None
    status: ApprovalStatus = ApprovalStatus.PENDING
    decision: Optional[Dict[str, Any]] = None
    approved_by: Optional[str] = None
    approved_at: Optional[str] = None
    comments: List[str] = None

@dataclass
class ApprovalDecision:
    """HITL approval decision structure."""
    request_id: str
    decision: str  # 'approved', 'rejected', 'revised'
    selected_option: Optional[str]
    reasoning: str
    conditions: List[str]
    approved_by: str
    approved_at: str
    comments: str

class HITLSystem:
    """
    Human-in-the-loop approval system for customer care actions.
    Manages approval workflows, decision tracking, and escalation.
    """
    
    def __init__(self, storage_path: str = "logs/hitl"):
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger(__name__)
        
        # Configuration
        self.default_timeout = timedelta(hours=24)
        self.escalation_timeout = timedelta(hours=4)
        self.auto_approve_threshold = timedelta(hours=48)
        
        # Approval handlers
        self.approval_handlers: Dict[str, Callable] = {}
        
        # Pending requests cache
        self.pending_requests: Dict[str, ApprovalRequest] = {}
        
        # Load existing requests
        self._load_pending_requests()
    
    def create_approval_request(self,
                              action_id: str,
                              action_type: str,
                              user_id: str,
                              session_id: str,
                              priority: PriorityLevel,
                              reason: str,
                              options: List[Dict[str, Any]],
                              context: Dict[str, Any],
                              timeout: Optional[timedelta] = None) -> str:
        """
        Create a new HITL approval request.
        
        Args:
            action_id: Unique identifier for the action
            action_type: Type of action requiring approval
            user_id: User ID for the customer
            session_id: Session ID for the conversation
            priority: Priority level for the request
            reason: Reason why HITL is required
            options: Available options for the human reviewer
            context: Additional context information
            timeout: Custom timeout (uses default if None)
            
        Returns:
            Request ID for tracking
        """
        try:
            request_id = str(uuid.uuid4())
            timeout_delta = timeout or self.default_timeout
            
            request = ApprovalRequest(
                request_id=request_id,
                action_id=action_id,
                action_type=action_type,
                user_id=user_id,
                session_id=session_id,
                priority=priority,
                reason=reason,
                options=options,
                context=context,
                created_at=datetime.now().isoformat(),
                expires_at=(datetime.now() + timeout_delta).isoformat(),
                comments=[]
            )
            
            # Store request
            self._store_request(request)
            self.pending_requests[request_id] = request
            
            # Log request creation
            self.logger.info(f"Created HITL request {request_id} for action {action_id}")
            
            # Trigger approval workflow
            self._trigger_approval_workflow(request)
            
            return request_id
            
        except Exception as e:
            self.logger.error(f"Failed to create approval request: {e}")
            raise
    
    def submit_decision(self,
                       request_id: str,
                       decision: str,
                       selected_option: Optional[str],
                       reasoning: str,
                       approved_by: str,
                       conditions: Optional[List[str]] = None,
                       comments: str = "") -> bool:
        """
        Submit a human decision for an approval request.
        
        Args:
            request_id: Request ID to update
            decision: Decision made ('approved', 'rejected', 'revised')
            selected_option: Selected option ID (if approved)
            reasoning: Reasoning for the decision
            approved_by: Human reviewer identifier
            conditions: Additional conditions (if any)
            comments: Additional comments
            
        Returns:
            True if decision was submitted successfully
        """
        try:
            if request_id not in self.pending_requests:
                self.logger.error(f"Request {request_id} not found")
                return False
            
            request = self.pending_requests[request_id]
            
            # Check if request is still valid
            if request.status != ApprovalStatus.PENDING:
                self.logger.warning(f"Request {request_id} is no longer pending")
                return False
            
            # Create decision
            approval_decision = ApprovalDecision(
                request_id=request_id,
                decision=decision,
                selected_option=selected_option,
                reasoning=reasoning,
                conditions=conditions or [],
                approved_by=approved_by,
                approved_at=datetime.now().isoformat(),
                comments=comments
            )
            
            # Update request
            request.status = ApprovalStatus.APPROVED if decision == 'approved' else ApprovalStatus.REJECTED
            request.decision = asdict(approval_decision)
            request.approved_by = approved_by
            request.approved_at = approval_decision.approved_at
            request.comments.append(f"[{datetime.now().isoformat()}] {comments}")
            
            # Store updated request
            self._store_request(request)
            
            # Remove from pending cache
            if request_id in self.pending_requests:
                del self.pending_requests[request_id]
            
            # Log decision
            self.logger.info(f"HITL decision for request {request_id}: {decision}")
            
            # Trigger post-decision actions
            self._trigger_post_decision_actions(request, approval_decision)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to submit decision for request {request_id}: {e}")
            return False
    
    def get_request_status(self, request_id: str) -> Optional[Dict[str, Any]]:
        """Get the current status of an approval request."""
        try:
            # Check pending cache first
            if request_id in self.pending_requests:
                request = self.pending_requests[request_id]
                return self._request_to_dict(request)
            
            # Check stored requests
            request_file = self.storage_path / f"{request_id}.json"
            if request_file.exists():
                with open(request_file, 'r') as f:
                    request_data = json.load(f)
                return request_data
            
            return None
            
        except Exception as e:
            self.logger.error(f"Failed to get request status for {request_id}: {e}")
            return None
    
    def list_pending_requests(self, 
                            assigned_to: Optional[str] = None,
                            priority: Optional[PriorityLevel] = None) -> List[Dict[str, Any]]:
        """List all pending approval requests."""
        try:
            pending = []
            
            for request in self.pending_requests.values():
                # Apply filters
                if assigned_to and request.assigned_to != assigned_to:
                    continue
                if priority and request.priority != priority:
                    continue
                
                pending.append(self._request_to_dict(request))
            
            # Sort by priority and creation time
            priority_order = {PriorityLevel.URGENT: 0, PriorityLevel.HIGH: 1, 
                            PriorityLevel.MEDIUM: 2, PriorityLevel.LOW: 3}
            pending.sort(key=lambda x: (priority_order.get(x['priority'], 4), x['created_at']))
            
            return pending
            
        except Exception as e:
            self.logger.error(f"Failed to list pending requests: {e}")
            return []
    
    def assign_request(self, request_id: str, assigned_to: str) -> bool:
        """Assign a pending request to a human reviewer."""
        try:
            if request_id not in self.pending_requests:
                return False
            
            request = self.pending_requests[request_id]
            request.assigned_to = assigned_to
            
            # Update stored request
            self._store_request(request)
            
            self.logger.info(f"Assigned request {request_id} to {assigned_to}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to assign request {request_id}: {e}")
            return False
    
    def cancel_request(self, request_id: str, reason: str = "") -> bool:
        """Cancel a pending approval request."""
        try:
            if request_id not in self.pending_requests:
                return False
            
            request = self.pending_requests[request_id]
            request.status = ApprovalStatus.CANCELLED
            request.comments.append(f"[{datetime.now().isoformat()}] Cancelled: {reason}")
            
            # Store updated request
            self._store_request(request)
            
            # Remove from pending cache
            del self.pending_requests[request_id]
            
            self.logger.info(f"Cancelled request {request_id}: {reason}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to cancel request {request_id}: {e}")
            return False
    
    def cleanup_expired_requests(self):
        """Clean up expired approval requests."""
        try:
            current_time = datetime.now()
            expired_requests = []
            
            for request_id, request in list(self.pending_requests.items()):
                expires_at = datetime.fromisoformat(request.expires_at)
                if current_time > expires_at:
                    expired_requests.append(request_id)
            
            for request_id in expired_requests:
                request = self.pending_requests[request_id]
                request.status = ApprovalStatus.EXPIRED
                request.comments.append(f"[{current_time.isoformat()}] Request expired")
                
                # Store updated request
                self._store_request(request)
                
                # Remove from pending cache
                del self.pending_requests[request_id]
                
                self.logger.info(f"Expired request {request_id}")
            
            self.logger.info(f"Cleaned up {len(expired_requests)} expired requests")
            
        except Exception as e:
            self.logger.error(f"Failed to cleanup expired requests: {e}")
    
    def register_approval_handler(self, action_type: str, handler: Callable):
        """Register a custom approval handler for specific action types."""
        self.approval_handlers[action_type] = handler
        self.logger.info(f"Registered approval handler for {action_type}")
    
    def _trigger_approval_workflow(self, request: ApprovalRequest):
        """Trigger the approval workflow for a request."""
        try:
            # Check for custom handler
            if request.action_type in self.approval_handlers:
                handler = self.approval_handlers[request.action_type]
                handler(request)
                return
            
            # Default workflow
            self._default_approval_workflow(request)
            
        except Exception as e:
            self.logger.error(f"Failed to trigger approval workflow for {request.request_id}: {e}")
    
    def _default_approval_workflow(self, request: ApprovalRequest):
        """Default approval workflow implementation."""
        # In a real system, this would:
        # 1. Notify human reviewers
        # 2. Create tickets in ticketing system
        # 3. Send alerts to appropriate channels
        # 4. Update dashboards
        
        self.logger.info(f"Triggered default approval workflow for request {request.request_id}")
        
        # Simulate workflow actions
        workflow_data = {
            "request_id": request.request_id,
            "action_type": request.action_type,
            "priority": request.priority.value,
            "reason": request.reason,
            "created_at": request.created_at,
            "expires_at": request.expires_at
        }
        
        # Log workflow trigger
        workflow_log = self.storage_path / "workflow_log.jsonl"
        with open(workflow_log, 'a') as f:
            f.write(json.dumps(workflow_data) + '\n')
    
    def _trigger_post_decision_actions(self, request: ApprovalRequest, decision: ApprovalDecision):
        """Trigger actions after a decision is made."""
        try:
            # Log decision
            decision_log = self.storage_path / "decisions.jsonl"
            with open(decision_log, 'a') as f:
                f.write(json.dumps(asdict(decision)) + '\n')
            
            # Notify relevant systems
            self._notify_decision(request, decision)
            
        except Exception as e:
            self.logger.error(f"Failed to trigger post-decision actions for {request.request_id}: {e}")
    
    def _notify_decision(self, request: ApprovalRequest, decision: ApprovalDecision):
        """Notify relevant systems about the decision."""
        # In a real system, this would:
        # 1. Update the customer care system
        # 2. Execute the approved action
        # 3. Send notifications to stakeholders
        # 4. Update audit logs
        
        self.logger.info(f"Notified systems about decision for request {request.request_id}")
    
    def _store_request(self, request: ApprovalRequest):
        """Store an approval request to disk."""
        try:
            request_file = self.storage_path / f"{request.request_id}.json"
            with open(request_file, 'w') as f:
                json.dump(self._request_to_dict(request), f, indent=2)
                
        except Exception as e:
            self.logger.error(f"Failed to store request {request.request_id}: {e}")
    
    def _load_pending_requests(self):
        """Load pending requests from disk."""
        try:
            for request_file in self.storage_path.glob("*.json"):
                try:
                    with open(request_file, 'r') as f:
                        request_data = json.load(f)
                    
                    # Only load pending requests
                    if request_data.get('status') == ApprovalStatus.PENDING.value:
                        request = self._dict_to_request(request_data)
                        self.pending_requests[request.request_id] = request
                        
                except Exception as e:
                    self.logger.error(f"Failed to load request from {request_file}: {e}")
            
            self.logger.info(f"Loaded {len(self.pending_requests)} pending requests")
            
        except Exception as e:
            self.logger.error(f"Failed to load pending requests: {e}")
    
    def _request_to_dict(self, request: ApprovalRequest) -> Dict[str, Any]:
        """Convert ApprovalRequest to dictionary."""
        data = asdict(request)
        data['priority'] = request.priority.value
        data['status'] = request.status.value
        return data
    
    def _dict_to_request(self, data: Dict[str, Any]) -> ApprovalRequest:
        """Convert dictionary to ApprovalRequest."""
        # Convert enum values back
        data['priority'] = PriorityLevel(data['priority'])
        data['status'] = ApprovalStatus(data['status'])
        
        # Handle optional fields
        if 'comments' not in data:
            data['comments'] = []
        
        return ApprovalRequest(**data)
    
    def get_hitl_stats(self) -> Dict[str, Any]:
        """Get HITL system statistics."""
        try:
            stats = {
                "pending_requests": len(self.pending_requests),
                "requests_by_priority": {},
                "requests_by_type": {},
                "average_response_time": None,
                "approval_rate": None
            }
            
            # Count by priority
            for priority in PriorityLevel:
                stats["requests_by_priority"][priority.value] = sum(
                    1 for req in self.pending_requests.values() 
                    if req.priority == priority
                )
            
            # Count by action type
            for request in self.pending_requests.values():
                action_type = request.action_type
                stats["requests_by_type"][action_type] = stats["requests_by_type"].get(action_type, 0) + 1
            
            return stats
            
        except Exception as e:
            self.logger.error(f"Failed to get HITL stats: {e}")
            return {}

# Example usage and testing
if __name__ == "__main__":
    # Initialize HITL system
    hitl_system = HITLSystem()
    
    # Create test approval request
    request_id = hitl_system.create_approval_request(
        action_id="refund_001",
        action_type="orders.refund_apply",
        user_id="u_1001",
        session_id="session_001",
        priority=PriorityLevel.HIGH,
        reason="High-value refund exceeding $500 threshold",
        options=[
            {"id": "full_refund", "description": "Full refund of $299.00", "amount": 299.00},
            {"id": "partial_refund", "description": "Partial refund of $150.00", "amount": 150.00},
            {"id": "exchange", "description": "Free exchange for same product", "amount": 0.00}
        ],
        context={
            "order_id": "o_2001",
            "customer_history": "Good customer, 2 previous orders",
            "reason": "Damaged item received"
        }
    )
    
    print(f"Created HITL request: {request_id}")
    
    # List pending requests
    pending = hitl_system.list_pending_requests()
    print(f"Pending requests: {len(pending)}")
    
    # Submit decision
    success = hitl_system.submit_decision(
        request_id=request_id,
        decision="approved",
        selected_option="full_refund",
        reasoning="Customer has good history and item was clearly damaged",
        approved_by="agent_001",
        comments="Processed full refund as requested"
    )
    
    print(f"Decision submitted: {success}")
    
    # Get stats
    stats = hitl_system.get_hitl_stats()
    print(f"HITL stats: {stats}")
