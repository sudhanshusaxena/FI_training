#!/usr/bin/env python3
"""
Enhanced Authentication Manager with Step-by-Step Credential Collection
Handles progressive authentication with retry logic and session management
"""

import os
import json
import time
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import hashlib

class EnhancedAuthenticationManager:
    """Enhanced authentication manager with step-by-step credential collection and session management."""
    
    def __init__(self, users_file: str = "shared/fixtures/users.json", 
                 password_ref_file: str = "shared/fixtures/password_reference.json",
                 session_duration_minutes: int = 3):
        """Initialize the enhanced authentication manager."""
        self.users_file = users_file
        self.password_ref_file = password_ref_file
        self.session_duration_minutes = session_duration_minutes
        self.max_auth_attempts = 3
        
        # Authentication state tracking
        self.auth_sessions = {}  # user_id -> auth_session_data
        self.auth_attempts = {}  # user_id -> attempt_history
        
        # Load user data
        self._load_users()
        self._load_password_references()
    
    def _load_users(self):
        """Load user data from JSON file."""
        try:
            with open(self.users_file, 'r') as f:
                self.users = json.load(f)
        except Exception as e:
            print(f"Error loading users: {e}")
            self.users = {}
    
    def _load_password_references(self):
        """Load password reference data."""
        try:
            with open(self.password_ref_file, 'r') as f:
                self.password_refs = json.load(f)
        except Exception as e:
            print(f"Error loading password references: {e}")
            self.password_refs = {}
    
    def start_authentication_flow(self, user_id: str, chat_context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Start the step-by-step authentication flow."""
        current_time = datetime.now()
        
        # Initialize authentication session
        auth_session = {
            'user_id': user_id,
            'start_time': current_time,
            'current_step': 'username',
            'attempt_count': 0,
            'credentials': {
                'username': None,
                'password': None,
                'email': None
            },
            'step_history': [],
            'chat_context': chat_context or {},
            'session_expiry': current_time + timedelta(minutes=self.session_duration_minutes)
        }
        
        self.auth_sessions[user_id] = auth_session
        self.auth_attempts[user_id] = []
        
        return {
            'success': True,
            'message': "I need to authenticate you for security. Let me collect your credentials:",
            'next_step': 'username',
            'prompt': "Please provide your username:",
            'auth_session_id': f"auth_{user_id}_{int(current_time.timestamp())}",
            'session_expiry': auth_session['session_expiry'].isoformat(),
            'attempts_remaining': self.max_auth_attempts
        }
    
    def process_credential_input(self, user_id: str, credential_type: str, 
                               credential_value: str) -> Dict[str, Any]:
        """Process credential input for the current authentication step."""
        if user_id not in self.auth_sessions:
            return {
                'success': False,
                'error': 'No active authentication session',
                'message': 'Please start authentication first'
            }
        
        auth_session = self.auth_sessions[user_id]
        
        # Check if session has expired
        if datetime.now() > auth_session['session_expiry']:
            self._clear_auth_session(user_id)
            return {
                'success': False,
                'error': 'Authentication session expired',
                'message': 'Your authentication session has expired. Please start again.',
                'session_expired': True
            }
        
        # Check if max attempts reached
        if auth_session['attempt_count'] >= self.max_auth_attempts:
            return self._handle_max_attempts_reached(user_id)
        
        # Process the credential
        auth_session['credentials'][credential_type] = credential_value
        auth_session['step_history'].append({
            'step': credential_type,
            'value': credential_value,
            'timestamp': datetime.now().isoformat()
        })
        
        # Determine next step
        if credential_type == 'username':
            return self._handle_username_step(user_id, credential_value)
        elif credential_type == 'password':
            return self._handle_password_step(user_id, credential_value)
        elif credential_type == 'email':
            return self._handle_email_step(user_id, credential_value)
        else:
            return {
                'success': False,
                'error': 'Invalid credential type',
                'message': 'Invalid credential type provided'
            }
    
    def _handle_username_step(self, user_id: str, username: str) -> Dict[str, Any]:
        """Handle username input step."""
        auth_session = self.auth_sessions[user_id]
        
        # Validate username exists
        user_found = False
        for uid, user_data in self.users.items():
            if user_data.get('username', '').lower() == username.lower():
                user_found = True
                auth_session['target_user_id'] = uid
                break
        
        if not user_found:
            auth_session['attempt_count'] += 1
            self._record_auth_attempt(user_id, 'username_failed', username)
            
            if auth_session['attempt_count'] >= self.max_auth_attempts:
                return self._handle_max_attempts_reached(user_id)
            
            return {
                'success': False,
                'error': 'Invalid username',
                'message': f"Username not found. Please re-enter your username (attempt {auth_session['attempt_count']}/{self.max_auth_attempts}):",
                'next_step': 'username',
                'attempts_remaining': self.max_auth_attempts - auth_session['attempt_count']
            }
        
        # Username is valid, move to password step
        auth_session['current_step'] = 'password'
        self._record_auth_attempt(user_id, 'username_success', username)
        
        return {
            'success': True,
            'message': "✓ Username verified. Now please provide your password:",
            'next_step': 'password',
            'attempts_remaining': self.max_auth_attempts - auth_session['attempt_count']
        }
    
    def _handle_password_step(self, user_id: str, password: str) -> Dict[str, Any]:
        """Handle password input step."""
        auth_session = self.auth_sessions[user_id]
        target_user_id = auth_session.get('target_user_id')
        
        if not target_user_id:
            return {
                'success': False,
                'error': 'No target user ID found',
                'message': 'Authentication error. Please start over.'
            }
        
        # Verify password
        user_data = self.users.get(target_user_id, {})
        stored_password = user_data.get('password_hash', '')
        
        # For demo purposes, we'll check against the password reference
        password_ref = self.password_refs.get(target_user_id, {})
        expected_password = password_ref.get('plain_password', '')
        
        if password != expected_password:
            auth_session['attempt_count'] += 1
            self._record_auth_attempt(user_id, 'password_failed', password)
            
            if auth_session['attempt_count'] >= self.max_auth_attempts:
                return self._handle_max_attempts_reached(user_id)
            
            return {
                'success': False,
                'error': 'Invalid password',
                'message': f"Password incorrect. Please re-enter your password (attempt {auth_session['attempt_count']}/{self.max_auth_attempts}):",
                'next_step': 'password',
                'attempts_remaining': self.max_auth_attempts - auth_session['attempt_count']
            }
        
        # Password is correct, move to email step
        auth_session['current_step'] = 'email'
        self._record_auth_attempt(user_id, 'password_success', password)
        
        return {
            'success': True,
            'message': "✓ Password verified. Finally, please provide your email address:",
            'next_step': 'email',
            'attempts_remaining': self.max_auth_attempts - auth_session['attempt_count']
        }
    
    def _handle_email_step(self, user_id: str, email: str) -> Dict[str, Any]:
        """Handle email input step."""
        auth_session = self.auth_sessions[user_id]
        target_user_id = auth_session.get('target_user_id')
        
        if not target_user_id:
            return {
                'success': False,
                'error': 'No target user ID found',
                'message': 'Authentication error. Please start over.'
            }
        
        # Verify email
        user_data = self.users.get(target_user_id, {})
        stored_email = user_data.get('email', '').lower()
        
        if email.lower() != stored_email:
            auth_session['attempt_count'] += 1
            self._record_auth_attempt(user_id, 'email_failed', email)
            
            if auth_session['attempt_count'] >= self.max_auth_attempts:
                return self._handle_max_attempts_reached(user_id)
            
            return {
                'success': False,
                'error': 'Invalid email',
                'message': f"Email address incorrect. Please re-enter your email (attempt {auth_session['attempt_count']}/{self.max_auth_attempts}):",
                'next_step': 'email',
                'attempts_remaining': self.max_auth_attempts - auth_session['attempt_count']
            }
        
        # All credentials verified successfully
        return self._complete_authentication(user_id, email)
    
    def _complete_authentication(self, user_id: str, email: str) -> Dict[str, Any]:
        """Complete the authentication process successfully."""
        auth_session = self.auth_sessions[user_id]
        
        # Mark as authenticated
        auth_session['authenticated'] = True
        auth_session['auth_completed_time'] = datetime.now()
        auth_session['current_step'] = 'completed'
        
        self._record_auth_attempt(user_id, 'authentication_success', email)
        
        # Calculate session duration
        session_duration = (auth_session['auth_completed_time'] - auth_session['start_time']).total_seconds()
        
        return {
            'success': True,
            'authenticated': True,
            'message': f"✅ Authentication successful! You're now verified for {self.session_duration_minutes} minutes.",
            'session_expiry': auth_session['session_expiry'].isoformat(),
            'session_duration': session_duration,
            'target_user_id': auth_session.get('target_user_id'),
            'credentials_verified': auth_session['credentials']
        }
    
    def _handle_max_attempts_reached(self, user_id: str) -> Dict[str, Any]:
        """Handle when maximum authentication attempts are reached."""
        auth_session = self.auth_sessions[user_id]
        
        self._record_auth_attempt(user_id, 'max_attempts_reached', 'customer_care_handover')
        
        # Clear the session
        self._clear_auth_session(user_id)
        
        return {
            'success': False,
            'error': 'Maximum attempts reached',
            'message': "I'm unable to authenticate you after 3 attempts. Please call +91 998877654321 to our customer care",
            'customer_care_handover': True,
            'handover_reason': 'authentication_failed',
            'contact_number': '+91 998877654321',
            'reference_id': f"REF_auth_{user_id}_{int(datetime.now().timestamp())}"
        }
    
    def _record_auth_attempt(self, user_id: str, attempt_type: str, value: str = None):
        """Record authentication attempt for analytics."""
        attempt_record = {
            'timestamp': datetime.now().isoformat(),
            'attempt_type': attempt_type,
            'value': value[:10] + '...' if value and len(value) > 10 else value,  # Truncate for security
            'session_id': f"auth_{user_id}_{int(datetime.now().timestamp())}"
        }
        
        if user_id not in self.auth_attempts:
            self.auth_attempts[user_id] = []
        
        self.auth_attempts[user_id].append(attempt_record)
    
    def check_authentication_status(self, user_id: str) -> Dict[str, Any]:
        """Check if user is currently authenticated and session is valid."""
        if user_id not in self.auth_sessions:
            return {
                'authenticated': False,
                'message': 'No active authentication session'
            }
        
        auth_session = self.auth_sessions[user_id]
        
        # Check if session has expired
        if datetime.now() > auth_session['session_expiry']:
            self._clear_auth_session(user_id)
            return {
                'authenticated': False,
                'message': 'Authentication session has expired',
                'session_expired': True
            }
        
        # Check if authenticated
        if not auth_session.get('authenticated', False):
            return {
                'authenticated': False,
                'message': 'Authentication not completed',
                'current_step': auth_session.get('current_step', 'username')
            }
        
        # Calculate remaining time
        remaining_time = (auth_session['session_expiry'] - datetime.now()).total_seconds()
        
        return {
            'authenticated': True,
            'message': f'Authentication valid for {remaining_time/60:.1f} more minutes',
            'session_expiry': auth_session['session_expiry'].isoformat(),
            'remaining_time_seconds': remaining_time,
            'target_user_id': auth_session.get('target_user_id')
        }
    
    def _clear_auth_session(self, user_id: str):
        """Clear authentication session for a user."""
        if user_id in self.auth_sessions:
            del self.auth_sessions[user_id]
    
    def get_authentication_analytics(self, user_id: str = None) -> Dict[str, Any]:
        """Get authentication analytics for a specific user or all users."""
        if user_id:
            user_attempts = self.auth_attempts.get(user_id, [])
            user_session = self.auth_sessions.get(user_id)
            
            return {
                'user_id': user_id,
                'total_attempts': len(user_attempts),
                'successful_auths': len([a for a in user_attempts if a['attempt_type'] == 'authentication_success']),
                'failed_auths': len([a for a in user_attempts if a['attempt_type'].endswith('_failed')]),
                'customer_care_handovers': len([a for a in user_attempts if a['attempt_type'] == 'max_attempts_reached']),
                'current_session': user_session is not None,
                'authenticated': user_session.get('authenticated', False) if user_session else False
            }
        else:
            # Return analytics for all users
            total_attempts = sum(len(attempts) for attempts in self.auth_attempts.values())
            successful_auths = sum(len([a for a in attempts if a['attempt_type'] == 'authentication_success']) 
                                 for attempts in self.auth_attempts.values())
            failed_auths = sum(len([a for a in attempts if a['attempt_type'].endswith('_failed')]) 
                             for attempts in self.auth_attempts.values())
            handovers = sum(len([a for a in attempts if a['attempt_type'] == 'max_attempts_reached']) 
                          for attempts in self.auth_attempts.values())
            
            return {
                'total_users': len(self.auth_attempts),
                'total_attempts': total_attempts,
                'successful_auths': successful_auths,
                'failed_auths': failed_auths,
                'customer_care_handovers': handovers,
                'success_rate': (successful_auths / total_attempts * 100) if total_attempts > 0 else 0,
                'handover_rate': (handovers / total_attempts * 100) if total_attempts > 0 else 0
            }
