#!/usr/bin/env python3
"""
Enhanced Interactive Chat for Jupyter Notebook
Shows agent thinking process and provides comprehensive chat summaries
"""

import sys
import os
import json
import time
from datetime import datetime
from typing import Dict, List, Any

class EnhancedInteractiveChat:
    """Enhanced interactive chat with agent thinking visualization and chat summaries."""
    
    def __init__(self, system_orchestrator):
        """Initialize the enhanced interactive chat."""
        self.system = system_orchestrator
        self.chat_session = {
            'start_time': None,
            'end_time': None,
            'user_id': None,
            'messages': [],
            'agent_decisions': [],
            'authentication_attempts': 0,
            'human_handovers': 0,
            'intents_classified': [],
            'system_stats_start': None,
            'system_stats_end': None
        }
    
    def load_demo_credentials(self) -> Dict[str, Any]:
        """Load demo user credentials for testing."""
        try:
            with open('shared/fixtures/password_reference.json', 'r') as f:
                return json.load(f)
        except:
            return {}
    
    def display_credential_showcase(self) -> Dict[str, Any]:
        """Display demo credentials in an attractive format."""
        credentials = self.load_demo_credentials()
        
        print("🔑 DEMO CREDENTIALS SHOWCASE")
        print("="*80)
        print("Choose any of these demo users to test the system:")
        print()
        
        # Display first 10 users in a nice format
        user_options = []
        for i, (user_id, creds) in enumerate(list(credentials.items())[:10], 1):
            user_options.append({
                'number': i,
                'user_id': user_id,
                'username': creds.get('username', 'N/A'),
                'email': creds.get('email', 'N/A'),
                'password': creds.get('plain_password', 'N/A')
            })
            
            print(f"{i:2d}. 👤 {user_id}")
            print(f"    📧 Email: {creds.get('email', 'N/A')}")
            print(f"    🔐 Password: {creds.get('plain_password', 'N/A')}")
            print(f"    👤 Username: {creds.get('username', 'N/A')}")
            print("-" * 60)
        
        print()
        print("💡 TIP: Copy any user ID, email, and password to test the authentication flow!")
        print("🎯 The system will show you exactly how it thinks and makes decisions.")
        print("="*80)
        
        return user_options
    
    def get_user_selection(self, user_options: List[Dict]) -> str:
        """Get user selection for testing."""
        print("\n🎮 USER SELECTION")
        print("-" * 40)
        
        while True:
            try:
                selection = input("👤 Enter user number (1-10) or user ID: ").strip()
                
                # If it's a number, get the corresponding user
                if selection.isdigit():
                    num = int(selection)
                    if 1 <= num <= len(user_options):
                        selected_user = user_options[num - 1]
                        print(f"✅ Selected: {selected_user['user_id']} ({selected_user['email']})")
                        return selected_user['user_id']
                    else:
                        print(f"❌ Please enter a number between 1 and {len(user_options)}")
                        continue
                
                # If it's a user ID, validate it
                user_ids = [user['user_id'] for user in user_options]
                if selection in user_ids:
                    selected_user = next(user for user in user_options if user['user_id'] == selection)
                    print(f"✅ Selected: {selected_user['user_id']} ({selected_user['email']})")
                    return selection
                else:
                    print(f"❌ User ID '{selection}' not found. Please try again.")
                    continue
                    
            except KeyboardInterrupt:
                print("\n👋 Goodbye!")
                sys.exit(0)
            except Exception as e:
                print(f"❌ Error: {e}. Please try again.")
    
    def display_agent_thinking(self, result: Dict[str, Any], message: str) -> None:
        """Display the agent's thinking process in detail."""
        print("\n🧠 AGENT THINKING PROCESS")
        print("="*60)
        
        # Step 1: Intent Classification
        print("1️⃣ INTENT CLASSIFICATION")
        print(f"   📝 User Message: \"{message}\"")
        print(f"   🎯 Detected Intent: {result.get('intent', 'N/A')}")
        print(f"   📊 Confidence: {result.get('confidence', 0):.2f} ({result.get('confidence', 0)*100:.1f}%)")
        print(f"   🧠 Reasoning: {result.get('reasoning', 'N/A')}")
        
        # Step 2: Authentication Analysis
        print("\n2️⃣ AUTHENTICATION ANALYSIS")
        auth_required = result.get('auth_required', False)
        auth_successful = result.get('auth_successful', False)
        
        print(f"   🔐 Authentication Required: {'✅ YES' if auth_required else '❌ NO'}")
        if auth_required:
            print(f"   🔐 Authentication Successful: {'✅ YES' if auth_successful else '❌ NO'}")
            print(f"   🔄 Authentication Attempts: {self.chat_session['authentication_attempts']}")
        
        # Step 3: Decision Making
        print("\n3️⃣ DECISION MAKING")
        if result.get('requires_human_agent', False):
            print("   👨‍💼 Decision: HUMAN AGENT HANDOVER REQUIRED")
            print(f"   📞 Reason: {result.get('human_handover', {}).get('reason', 'N/A')}")
        else:
            print("   🤖 Decision: AI AGENT CAN HANDLE")
        
        # Step 4: Response Generation
        print("\n4️⃣ RESPONSE GENERATION")
        print(f"   💬 Response Type: {'Human Handover' if result.get('requires_human_agent', False) else 'AI Response'}")
        
        # Step 5: Follow-up Planning
        if result.get('follow_up_questions'):
            print("\n5️⃣ FOLLOW-UP PLANNING")
            print(f"   ❓ Generated {len(result['follow_up_questions'])} follow-up questions")
        
        # Step 6: Audit Logging
        print("\n6️⃣ AUDIT & TRACKING")
        print(f"   📋 Chat ID: {result.get('chat_id', 'N/A')}")
        print(f"   📊 Session ID: {result.get('session_id', 'N/A')}")
        
        print("="*60)
    
    def display_chat_summary(self) -> None:
        """Display comprehensive chat summary."""
        print("\n📊 CHAT SESSION SUMMARY")
        print("="*80)
        
        # Session Overview
        duration = self.chat_session['end_time'] - self.chat_session['start_time'] if self.chat_session['start_time'] and self.chat_session['end_time'] else None
        
        print("🎯 SESSION OVERVIEW")
        print(f"   👤 User ID: {self.chat_session['user_id']}")
        print(f"   ⏰ Duration: {duration.total_seconds():.1f} seconds" if duration else "   ⏰ Duration: N/A")
        print(f"   💬 Total Messages: {len(self.chat_session['messages'])}")
        print(f"   🔐 Authentication Attempts: {self.chat_session['authentication_attempts']}")
        print(f"   👨‍💼 Human Handovers: {self.chat_session['human_handovers']}")
        
        # Intent Analysis
        print("\n🧠 INTENT ANALYSIS")
        intent_counts = {}
        for intent in self.chat_session['intents_classified']:
            intent_counts[intent] = intent_counts.get(intent, 0) + 1
        
        for intent, count in intent_counts.items():
            print(f"   📋 {intent}: {count} times")
        
        # Agent Decisions
        print("\n🤖 AGENT DECISIONS")
        for i, decision in enumerate(self.chat_session['agent_decisions'], 1):
            print(f"   {i}. {decision}")
        
        # System Impact
        print("\n📈 SYSTEM IMPACT")
        if self.chat_session['system_stats_start'] and self.chat_session['system_stats_end']:
            start_stats = self.chat_session['system_stats_start']
            end_stats = self.chat_session['system_stats_end']
            
            print(f"   💬 Chats Created: +{end_stats['chat_history']['total_chats'] - start_stats['chat_history']['total_chats']}")
            print(f"   📋 Events Logged: +{end_stats['audit_logging']['total_events'] - start_stats['audit_logging']['total_events']}")
            print(f"   👨‍💼 Handovers: +{end_stats['human_handovers']['total_handovers'] - start_stats['human_handovers']['total_handovers']}")
        
        # Message History
        print("\n💬 MESSAGE HISTORY")
        for i, msg in enumerate(self.chat_session['messages'], 1):
            print(f"   {i}. User: \"{msg['user_message']}\"")
            print(f"      Agent: \"{msg['agent_response'][:100]}{'...' if len(msg['agent_response']) > 100 else ''}\"")
            print(f"      Intent: {msg['intent']} (Confidence: {msg['confidence']:.2f})")
            print()
        
        print("="*80)
        print("🎉 Chat session completed successfully!")
        print("💡 The agent demonstrated intelligent decision-making throughout the conversation.")
    
    def start_enhanced_chat(self) -> None:
        """Start the enhanced interactive chat with full visualization."""
        print("🚀 ENHANCED INTERACTIVE CHAT")
        print("="*80)
        print("Welcome to the Complete Intelligent Triage Agent System!")
        print("This chat will show you exactly how the AI agent thinks and makes decisions.")
        print("="*80)
        
        # Display credentials showcase
        user_options = self.display_credential_showcase()
        
        # Get user selection
        selected_user_id = self.get_user_selection(user_options)
        
        # Initialize chat session
        self.chat_session['start_time'] = datetime.now()
        self.chat_session['user_id'] = selected_user_id
        
        # Get initial system stats
        try:
            self.chat_session['system_stats_start'] = self.system.get_system_stats()
        except:
            self.chat_session['system_stats_start'] = None
        
        print(f"\n💬 CHAT SESSION STARTED")
        print(f"👤 User: {selected_user_id}")
        print(f"⏰ Time: {self.chat_session['start_time'].strftime('%Y-%m-%d %H:%M:%S')}")
        print("-" * 80)
        print("💡 Commands: 'help' for commands, 'summary' for chat summary, 'quit' to exit")
        print("-" * 80)
        
        # Main chat loop
        while True:
            try:
                # Get user input
                message = input("\n💬 You: ").strip()
                
                # Handle special commands
                if message.lower() in ['quit', 'exit', 'q']:
                    self.chat_session['end_time'] = datetime.now()
                    self.display_chat_summary()
                    break
                elif message.lower() == 'help':
                    self.display_help()
                    continue
                elif message.lower() == 'summary':
                    self.display_chat_summary()
                    continue
                elif not message.strip():
                    print("💡 Please enter a message or command")
                    continue
                
                # Process message through the system
                print(f"\n🤖 Processing your message...")
                print("-" * 40)
                
                # Get user credentials for authentication
                credentials = self.load_demo_credentials()
                user_creds = credentials.get(selected_user_id, {})
                
                # Process the message
                result = self.system.process_customer_message(
                    selected_user_id, 
                    message,
                    password=user_creds.get('plain_password', '')
                )
                
                # Display agent thinking process
                self.display_agent_thinking(result, message)
                
                # Update chat session tracking
                self.chat_session['messages'].append({
                    'user_message': message,
                    'agent_response': result.get('response', ''),
                    'intent': result.get('intent', 'N/A'),
                    'confidence': result.get('confidence', 0),
                    'timestamp': datetime.now()
                })
                
                self.chat_session['intents_classified'].append(result.get('intent', 'N/A'))
                
                if result.get('auth_required', False):
                    self.chat_session['authentication_attempts'] += 1
                
                if result.get('requires_human_agent', False):
                    self.chat_session['human_handovers'] += 1
                    self.chat_session['agent_decisions'].append(
                        f"Human handover triggered: {result.get('human_handover', {}).get('reason', 'N/A')}"
                    )
                else:
                    self.chat_session['agent_decisions'].append(
                        f"AI handled request: {result.get('intent', 'N/A')}"
                    )
                
                # Display response
                print(f"\n💬 AGENT RESPONSE")
                print("-" * 40)
                print(f"{result.get('response', 'No response generated')}")
                
                # Display follow-up questions if available
                if result.get('follow_up_questions'):
                    print(f"\n❓ FOLLOW-UP QUESTIONS")
                    print("-" * 30)
                    for i, question in enumerate(result['follow_up_questions'], 1):
                        print(f"   {i}. {question}")
                
                # Display human handover info if needed
                if result.get('human_handover'):
                    handover = result['human_handover']
                    print(f"\n📞 HUMAN AGENT HANDOVER")
                    print("-" * 30)
                    print(f"   📞 Contact: {handover.get('contact_number', 'N/A')}")
                    print(f"   🆔 Reference ID: {handover.get('reference_id', 'N/A')}")
                    print(f"   📝 Reason: {handover.get('reason', 'N/A')}")
                
                print("\n" + "="*80)
                
            except KeyboardInterrupt:
                print("\n\n👋 Chat interrupted. Generating summary...")
                self.chat_session['end_time'] = datetime.now()
                self.display_chat_summary()
                break
            except Exception as e:
                print(f"\n❌ Error processing message: {e}")
                print("💡 Please try again or type 'help' for assistance")
        
        # Get final system stats
        try:
            self.chat_session['system_stats_end'] = self.system.get_system_stats()
        except:
            self.chat_session['system_stats_end'] = None
    
    def display_help(self) -> None:
        """Display help information."""
        print("\n📚 AVAILABLE COMMANDS")
        print("-" * 40)
        print("  help     - Show this help message")
        print("  summary  - Show comprehensive chat summary")
        print("  quit     - Exit the chat and show summary")
        print("\n💡 Just type your message to interact with the AI agent!")
        print("🧠 The agent will show you its complete thinking process!")
        print("📊 You'll see intent classification, authentication analysis, and decision-making!")
