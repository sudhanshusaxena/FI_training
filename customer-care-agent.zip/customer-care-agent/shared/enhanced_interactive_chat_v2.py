#!/usr/bin/env python3
"""
Enhanced Interactive Chat v2 - TriageAgent with Clear Authentication Flow
Shows TriageAgent thinking process and handles step-by-step authentication
"""

import sys
import os
import json
import time
from datetime import datetime
from typing import Dict, List, Any

class EnhancedInteractiveChatV2:
    """Enhanced interactive chat with TriageAgent thinking and step-by-step authentication."""
    
    def __init__(self, system_orchestrator):
        """Initialize the enhanced interactive chat v2."""
        self.system = system_orchestrator
        self.chat_session = {
            'start_time': None,
            'end_time': None,
            'user_id': None,
            'messages': [],
            'agent_decisions': [],
            'authentication_attempts': 0,
            'human_handovers': 0,
            'intents_classified': [],
            'system_stats_start': None,
            'system_stats_end': None,
            'current_auth_step': None,
            'auth_session_active': False
        }
    
    def load_demo_credentials(self) -> Dict[str, Any]:
        """Load demo user credentials for testing."""
        try:
            with open('shared/fixtures/password_reference.json', 'r') as f:
                return json.load(f)
        except:
            return {}
    
    def display_credential_showcase(self) -> Dict[str, Any]:
        """Display demo credentials in an attractive format."""
        credentials = self.load_demo_credentials()
        
        print("🔑 DEMO CREDENTIALS SHOWCASE")
        print("="*80)
        print("Choose any of these demo users to test the enhanced TriageAgent system:")
        print()
        
        # Display first 10 users in a nice format
        user_options = []
        for i, (user_id, creds) in enumerate(list(credentials.items())[:10], 1):
            user_options.append({
                'number': i,
                'user_id': user_id,
                'username': creds.get('username', 'N/A'),
                'email': creds.get('email', 'N/A'),
                'password': creds.get('plain_password', 'N/A')
            })
            
            print(f"{i:2d}. 👤 {user_id}")
            print(f"    📧 Email: {creds.get('email', 'N/A')}")
            print(f"    🔐 Password: {creds.get('plain_password', 'N/A')}")
            print(f"    👤 Username: {creds.get('username', 'N/A')}")
            print("-" * 60)
        
        print()
        print("💡 TIP: The TriageAgent will now show its thinking process clearly!")
        print("🧠 You'll see exactly how it decides when authentication is needed!")
        print("🔐 Watch the step-by-step authentication flow in action!")
        print("="*80)
        
        return user_options
    
    def get_user_selection(self, user_options: List[Dict]) -> str:
        """Get user selection for testing."""
        print("\n🎮 USER SELECTION")
        print("-" * 40)
        
        while True:
            try:
                selection = input("👤 Enter user number (1-10) or user ID: ").strip()
                
                # If it's a number, get the corresponding user
                if selection.isdigit():
                    num = int(selection)
                    if 1 <= num <= len(user_options):
                        selected_user = user_options[num - 1]
                        print(f"✅ Selected: {selected_user['user_id']} ({selected_user['email']})")
                        return selected_user['user_id']
                    else:
                        print(f"❌ Please enter a number between 1 and {len(user_options)}")
                        continue
                
                # If it's a user ID, validate it
                user_ids = [user['user_id'] for user in user_options]
                if selection in user_ids:
                    selected_user = next(user for user in user_options if user['user_id'] == selection)
                    print(f"✅ Selected: {selected_user['user_id']} ({selected_user['email']})")
                    return selection
                else:
                    print(f"❌ User ID '{selection}' not found. Please try again.")
                    continue
                    
            except KeyboardInterrupt:
                print("\n👋 Goodbye!")
                sys.exit(0)
            except Exception as e:
                print(f"❌ Error: {e}. Please try again.")
    
    def display_triage_agent_thinking(self, user_message: str, result: Dict[str, Any]) -> None:
        """Display the TriageAgent's complete thinking process."""
        print("\n🧠 TRIAGE AGENT THINKING PROCESS")
        print("="*80)
        
        # Step 1: Message Analysis
        print("1️⃣ MESSAGE ANALYSIS")
        print(f"   📝 User Message: \"{user_message}\"")
        print(f"   🔍 Analyzing intent and context...")
        
        # Step 2: Intent Classification
        detected_intent = result.get('intent', 'unknown')
        confidence = result.get('confidence', 0.0)
        
        print("\n2️⃣ INTENT CLASSIFICATION")
        print(f"   🎯 Detected Intent: {detected_intent}")
        print(f"   📊 Confidence: {confidence:.2f} ({confidence*100:.1f}%)")
        
        # Determine reasoning based on intent
        intent_reasoning = self._get_intent_reasoning(detected_intent, user_message)
        print(f"   🧠 Reasoning: {intent_reasoning}")
        
        # Step 3: Authentication Decision
        auth_required = result.get('auth_required', False)
        
        print("\n3️⃣ AUTHENTICATION DECISION")
        if auth_required:
            print(f"   🔐 Authentication Required: ✅ YES")
            auth_reasoning = self._get_auth_reasoning(detected_intent)
            print(f"   📝 Reasoning: {auth_reasoning}")
            print(f"   ⚠️  This involves sensitive personal data that requires verification")
        else:
            print(f"   🔐 Authentication Required: ❌ NO")
            print(f"   📝 Reasoning: This is general information that doesn't require user verification")
        
        # Step 4: Action Decision
        print("\n4️⃣ ACTION DECISION")
        if auth_required:
            print(f"   🎯 Decision: REQUEST AUTHENTICATION")
            print(f"   📋 Next Steps: Ask user for credentials (username → password → email)")
        else:
            print(f"   🎯 Decision: ANSWER DIRECTLY")
            print(f"   📋 Next Steps: Provide helpful response immediately")
        
        print("="*80)
    
    def _get_intent_reasoning(self, intent: str, message: str) -> str:
        """Get reasoning for intent classification."""
        intent_reasoning_map = {
            'general_inquiry': 'User is asking for general information or help',
            'order_status': 'User is asking about order tracking or status',
            'refunds': 'User is requesting a refund or return',
            'troubleshooting': 'User is experiencing technical issues',
            'account_issues': 'User has problems with their account',
            'sales_inquiry': 'User is interested in products or services'
        }
        return intent_reasoning_map.get(intent, 'Intent analysis completed')
    
    def _get_auth_reasoning(self, intent: str) -> str:
        """Get reasoning for authentication requirement."""
        auth_reasoning_map = {
            'order_status': 'Order information is personal and requires verification',
            'refunds': 'Refund requests involve financial data and account access',
            'troubleshooting': 'Technical support may require account access',
            'account_issues': 'Account problems require identity verification'
        }
        return auth_reasoning_map.get(intent, 'Sensitive data requires authentication')
    
    def display_authentication_flow(self, auth_result: Dict[str, Any]) -> None:
        """Display the authentication flow process."""
        print("\n🔐 AUTHENTICATION FLOW")
        print("="*60)
        
        if auth_result.get('success'):
            print(f"✅ Authentication flow started successfully")
            print(f"📋 Next step: {auth_result.get('next_step', 'unknown')}")
            print(f"⏰ Session duration: 3 minutes")
            print(f"🔄 Attempts remaining: {auth_result.get('attempts_remaining', 3)}")
            print(f"📝 Prompt: {auth_result.get('prompt', '')}")
        else:
            print(f"❌ Authentication flow failed to start")
            print(f"📝 Error: {auth_result.get('error', 'Unknown error')}")
        
        print("="*60)
    
    def display_authentication_step_result(self, step_result: Dict[str, Any], step_type: str) -> None:
        """Display the result of an authentication step."""
        print(f"\n🔐 AUTHENTICATION STEP: {step_type.upper()}")
        print("-" * 50)
        
        if step_result.get('success'):
            print(f"✅ {step_type.title()} verified successfully")
            if step_result.get('next_step'):
                print(f"➡️ Next: {step_result['next_step']}")
            if step_result.get('message'):
                print(f"💬 {step_result['message']}")
        else:
            print(f"❌ {step_type.title()} verification failed")
            print(f"📝 Error: {step_result.get('error', 'Unknown error')}")
            if step_result.get('message'):
                print(f"💬 {step_result['message']}")
            if step_result.get('attempts_remaining'):
                print(f"🔄 Attempts remaining: {step_result['attempts_remaining']}")
        
        print("-" * 50)
    
    def display_authentication_completion(self, auth_result: Dict[str, Any]) -> None:
        """Display authentication completion result."""
        print("\n🎉 AUTHENTICATION RESULT")
        print("="*60)
        
        if auth_result.get('authenticated'):
            print(f"✅ AUTHENTICATION SUCCESSFUL!")
            print(f"⏰ Session valid for 3 minutes")
            print(f"🎯 You can now ask sensitive questions")
            print(f"📊 Session duration: {auth_result.get('session_duration', 0):.1f} seconds")
        elif auth_result.get('customer_care_handover'):
            print(f"📞 CUSTOMER CARE HANDOVER")
            print(f"📝 Reason: Authentication failed after 3 attempts")
            print(f"📞 Contact: {auth_result.get('contact_number', 'N/A')}")
            print(f"🆔 Reference ID: {auth_result.get('reference_id', 'N/A')}")
        else:
            print(f"❌ Authentication failed")
            print(f"📝 Reason: {auth_result.get('error', 'Unknown error')}")
        
        print("="*60)
    
    def display_agent_response(self, result: Dict[str, Any]) -> None:
        """Display the agent's final response."""
        print("\n💬 TRIAGE AGENT RESPONSE")
        print("="*60)
        
        intent = result.get('intent', 'N/A')
        confidence = result.get('confidence', 0.0)
        auth_required = result.get('auth_required', False)
        auth_successful = result.get('auth_successful', False)
        human_handover = result.get('requires_human_agent', False)
        
        print(f"🎯 Intent: {intent}")
        print(f"📊 Confidence: {confidence:.2f}")
        print(f"🔐 Auth Required: {'✅ YES' if auth_required else '❌ NO'}")
        print(f"🔐 Auth Successful: {'✅ YES' if auth_successful else '❌ NO'}")
        print(f"👨‍💼 Human Handover: {'✅ YES' if human_handover else '❌ NO'}")
        
        if result.get('reasoning'):
            print(f"\n🧠 Agent Reasoning: {result['reasoning']}")
        
        print(f"\n💬 Response:")
        print(f"{result.get('response', 'No response generated')}")
        
        # Display follow-up questions if available
        if result.get('follow_up_questions'):
            print(f"\n❓ FOLLOW-UP QUESTIONS")
            print("-" * 30)
            for i, question in enumerate(result['follow_up_questions'], 1):
                print(f"   {i}. {question}")
        
        # Display human handover info if needed
        if result.get('human_handover'):
            handover = result['human_handover']
            print(f"\n📞 HUMAN AGENT HANDOVER")
            print("-" * 30)
            print(f"   📞 Contact: {handover.get('contact_number', 'N/A')}")
            print(f"   🆔 Reference ID: {handover.get('reference_id', 'N/A')}")
            print(f"   📝 Reason: {handover.get('reason', 'N/A')}")
        
        print("="*60)
    
    def display_chat_summary(self) -> None:
        """Display comprehensive chat summary."""
        print("\n📊 CHAT SESSION SUMMARY")
        print("="*80)
        
        # Session Overview
        duration = self.chat_session['end_time'] - self.chat_session['start_time'] if self.chat_session['start_time'] and self.chat_session['end_time'] else None
        
        print("🎯 SESSION OVERVIEW")
        print(f"   👤 User ID: {self.chat_session['user_id']}")
        print(f"   ⏰ Duration: {duration.total_seconds():.1f} seconds" if duration else "   ⏰ Duration: N/A")
        print(f"   💬 Total Messages: {len(self.chat_session['messages'])}")
        print(f"   🔐 Authentication Attempts: {self.chat_session['authentication_attempts']}")
        print(f"   👨‍💼 Human Handovers: {self.chat_session['human_handovers']}")
        print(f"   🔄 Auth Sessions: {'✅ Active' if self.chat_session['auth_session_active'] else '❌ None'}")
        
        # Intent Analysis
        print("\n🧠 INTENT ANALYSIS")
        intent_counts = {}
        for intent in self.chat_session['intents_classified']:
            intent_counts[intent] = intent_counts.get(intent, 0) + 1
        
        for intent, count in intent_counts.items():
            print(f"   📋 {intent}: {count} times")
        
        # Agent Decisions
        print("\n🤖 TRIAGE AGENT DECISIONS")
        for i, decision in enumerate(self.chat_session['agent_decisions'], 1):
            print(f"   {i}. {decision}")
        
        # System Impact
        print("\n📈 SYSTEM IMPACT")
        if self.chat_session['system_stats_start'] and self.chat_session['system_stats_end']:
            start_stats = self.chat_session['system_stats_start']
            end_stats = self.chat_session['system_stats_end']
            
            print(f"   💬 Chats Created: +{end_stats['chat_history']['total_chats'] - start_stats['chat_history']['total_chats']}")
            print(f"   📋 Events Logged: +{end_stats['audit_logging']['total_events'] - start_stats['audit_logging']['total_events']}")
            print(f"   👨‍💼 Handovers: +{end_stats['human_handovers']['total_handovers'] - start_stats['human_handovers']['total_handovers']}")
        
        # Message History
        print("\n💬 MESSAGE HISTORY")
        for i, msg in enumerate(self.chat_session['messages'], 1):
            print(f"   {i}. User: \"{msg['user_message']}\"")
            print(f"      Intent: {msg['intent']} (Confidence: {msg['confidence']:.2f})")
            print(f"      Auth Required: {msg.get('auth_required', False)}")
            print(f"      Auth Successful: {msg.get('auth_successful', False)}")
            print()
        
        print("="*80)
        print("🎉 Enhanced TriageAgent chat session completed successfully!")
        print("💡 You've seen the complete decision-making process in action!")
    
    def start_enhanced_chat_v2(self) -> None:
        """Start the enhanced interactive chat v2 with TriageAgent thinking."""
        print("🚀 ENHANCED TRIAGE AGENT INTERACTIVE CHAT")
        print("="*80)
        print("Welcome to the Enhanced Customer Care Agent System!")
        print("Now with clear TriageAgent thinking and step-by-step authentication!")
        print("="*80)
        
        # Display credentials showcase
        user_options = self.display_credential_showcase()
        
        # Get user selection
        selected_user_id = self.get_user_selection(user_options)
        
        # Initialize chat session
        self.chat_session['start_time'] = datetime.now()
        self.chat_session['user_id'] = selected_user_id
        
        # Get initial system stats
        try:
            self.chat_session['system_stats_start'] = self.system.get_system_stats()
        except:
            self.chat_session['system_stats_start'] = None
        
        print(f"\n💬 ENHANCED CHAT SESSION STARTED")
        print(f"👤 User: {selected_user_id}")
        print(f"⏰ Time: {self.chat_session['start_time'].strftime('%Y-%m-%d %H:%M:%S')}")
        print("-" * 80)
        print("💡 Commands: 'help' for commands, 'summary' for chat summary, 'quit' to exit")
        print("🧠 Watch the TriageAgent think and make decisions!")
        print("-" * 80)
        
        # Main chat loop
        while True:
            try:
                # Get user input
                message = input("\n💬 You: ").strip()
                
                # Handle special commands
                if message.lower() in ['quit', 'exit', 'q']:
                    self.chat_session['end_time'] = datetime.now()
                    self.display_chat_summary()
                    break
                elif message.lower() == 'help':
                    self.display_help()
                    continue
                elif message.lower() == 'summary':
                    self.display_chat_summary()
                    continue
                elif not message.strip():
                    print("💡 Please enter a message or command")
                    continue
                
                # Process message through the system
                print(f"\n🤖 Processing your message...")
                print("-" * 40)
                
                # Show TriageAgent thinking process
                result = self.system.process_customer_message(selected_user_id, message)
                self.display_triage_agent_thinking(message, result)
                
                # Handle authentication if required
                if result.get('auth_required', False) and not result.get('auth_successful', False):
                    print(f"\n🔐 AUTHENTICATION REQUIRED")
                    print("The TriageAgent has determined that your query requires authentication.")
                    print("Let me start the step-by-step authentication process...")
                    
                    # Here you would integrate with the enhanced authentication manager
                    # For now, we'll show the concept
                    print(f"📋 Authentication Steps:")
                    print(f"   1. Username verification")
                    print(f"   2. Password verification") 
                    print(f"   3. Email verification")
                    print(f"⏰ Session will be valid for 3 minutes")
                    
                    # Update session tracking
                    self.chat_session['auth_session_active'] = True
                    self.chat_session['authentication_attempts'] += 1
                
                # Display agent response
                self.display_agent_response(result)
                
                # Update chat session tracking
                self.chat_session['messages'].append({
                    'user_message': message,
                    'agent_response': result.get('response', ''),
                    'intent': result.get('intent', 'N/A'),
                    'confidence': result.get('confidence', 0),
                    'auth_required': result.get('auth_required', False),
                    'auth_successful': result.get('auth_successful', False),
                    'timestamp': datetime.now()
                })
                
                self.chat_session['intents_classified'].append(result.get('intent', 'N/A'))
                
                if result.get('requires_human_agent', False):
                    self.chat_session['human_handovers'] += 1
                    self.chat_session['agent_decisions'].append(
                        f"Human handover triggered: {result.get('human_handover', {}).get('reason', 'N/A')}"
                    )
                else:
                    self.chat_session['agent_decisions'].append(
                        f"TriageAgent handled request: {result.get('intent', 'N/A')}"
                    )
                
                print("\n" + "="*80)
                
            except KeyboardInterrupt:
                print("\n\n👋 Chat interrupted. Generating summary...")
                self.chat_session['end_time'] = datetime.now()
                self.display_chat_summary()
                break
            except Exception as e:
                print(f"\n❌ Error processing message: {e}")
                print("💡 Please try again or type 'help' for assistance")
        
        # Get final system stats
        try:
            self.chat_session['system_stats_end'] = self.system.get_system_stats()
        except:
            self.chat_session['system_stats_end'] = None
    
    def display_help(self) -> None:
        """Display help information."""
        print("\n📚 AVAILABLE COMMANDS")
        print("-" * 40)
        print("  help     - Show this help message")
        print("  summary  - Show comprehensive chat summary")
        print("  quit     - Exit the chat and show summary")
        print("\n💡 Just type your message to interact with the TriageAgent!")
        print("🧠 The TriageAgent will show you its complete thinking process!")
        print("🔐 Watch the step-by-step authentication flow when needed!")
        print("📊 You'll see intent classification, authentication decisions, and more!")
