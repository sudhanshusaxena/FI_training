#!/usr/bin/env python3
"""
Human Agent Simulator for Customer Care Agent System
Simulates human agent handover with phone number contact
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Any, Optional

class HumanAgentSimulator:
    """Simulates human agent handover and interaction."""
    
    def __init__(self, contact_number: str = "+91 998877654321"):
        self.contact_number = contact_number
        self.handover_reasons = {
            "authentication_failed": "Unable to verify your identity",
            "complex_issue": "Your issue requires specialized assistance",
            "escalation_requested": "You've requested to speak with a human agent",
            "system_error": "We're experiencing technical difficulties",
            "policy_exception": "Your request requires manual review"
        }
    
    def initiate_handover(self, user_id: str, chat_id: str, reason: str, 
                         context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Initiate human agent handover.
        
        Args:
            user_id: User ID
            chat_id: Chat ID
            reason: Reason for handover
            context: Additional context information
            
        Returns:
            Handover response
        """
        handover_message = self._generate_handover_message(reason, context)
        
        handover_data = {
            "handover_initiated": True,
            "timestamp": datetime.now().isoformat(),
            "user_id": user_id,
            "chat_id": chat_id,
            "reason": reason,
            "contact_number": self.contact_number,
            "handover_message": handover_message,
            "context": context or {},
            "estimated_wait_time": "5-10 minutes",
            "reference_id": f"REF_{chat_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        }
        
        # Log handover event
        self._log_handover_event(handover_data)
        
        return handover_data
    
    def _generate_handover_message(self, reason: str, context: Dict[str, Any] = None) -> str:
        """Generate appropriate handover message based on reason."""
        
        if reason == "authentication_failed":
            return f"I am unable to authenticate you. Please call {self.contact_number} to our customer care"
        
        elif reason == "complex_issue":
            return f"Your issue requires specialized assistance. Please call {self.contact_number} and reference your chat ID for faster service."
        
        elif reason == "escalation_requested":
            return f"You've requested to speak with a human agent. Please call {self.contact_number} and we'll connect you with our support team."
        
        elif reason == "system_error":
            return f"We're experiencing technical difficulties. Please call {self.contact_number} for immediate assistance."
        
        elif reason == "policy_exception":
            return f"Your request requires manual review. Please call {self.contact_number} to speak with our policy team."
        
        else:
            return f"For immediate assistance, please call {self.contact_number} to speak with our customer care team."
    
    def _log_handover_event(self, handover_data: Dict[str, Any]):
        """Log handover event to system logs."""
        try:
            log_file = "logs/system/human_handovers.json"
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            
            # Load existing handovers
            handovers = []
            if os.path.exists(log_file):
                with open(log_file, 'r') as f:
                    handovers = json.load(f)
            
            # Add new handover
            handovers.append(handover_data)
            
            # Save updated handovers
            with open(log_file, 'w') as f:
                json.dump(handovers, f, indent=2)
            
        except Exception as e:
            print(f"⚠️ Failed to log handover event: {e}")
    
    def get_handover_stats(self) -> Dict[str, Any]:
        """Get handover statistics."""
        try:
            log_file = "logs/system/human_handovers.json"
            
            if not os.path.exists(log_file):
                return {
                    "total_handovers": 0,
                    "recent_handovers": [],
                    "reasons": {}
                }
            
            with open(log_file, 'r') as f:
                handovers = json.load(f)
            
            # Calculate stats
            total_handovers = len(handovers)
            reasons = {}
            
            for handover in handovers:
                reason = handover.get("reason", "unknown")
                reasons[reason] = reasons.get(reason, 0) + 1
            
            # Get recent handovers (last 10)
            recent_handovers = sorted(
                handovers, 
                key=lambda x: x["timestamp"], 
                reverse=True
            )[:10]
            
            return {
                "total_handovers": total_handovers,
                "recent_handovers": recent_handovers,
                "reasons": reasons
            }
            
        except Exception as e:
            print(f"❌ Failed to get handover stats: {e}")
            return {"error": str(e)}
    
    def simulate_human_response(self, user_id: str, chat_id: str, 
                               user_message: str) -> Dict[str, Any]:
        """
        Simulate a human agent response (for demo purposes).
        
        Args:
            user_id: User ID
            chat_id: Chat ID
            user_message: User's message
            
        Returns:
            Simulated human agent response
        """
        # This is a simulation - in real implementation, this would connect to actual human agents
        
        simulated_responses = {
            "greeting": "Hello! I'm a human customer care representative. How can I assist you today?",
            "order_issue": "I understand you're having an issue with your order. Let me look into this for you right away.",
            "refund_request": "I can help you with your refund request. Let me check your order details and process this for you.",
            "technical_problem": "I'll help you troubleshoot this technical issue. Let me gather some information from you.",
            "general_inquiry": "I'm here to help! Could you please provide more details about what you need assistance with?"
        }
        
        # Simple message classification for simulation
        message_lower = user_message.lower()
        
        if any(word in message_lower for word in ["hello", "hi", "hey"]):
            response_type = "greeting"
        elif any(word in message_lower for word in ["order", "shipping", "delivery"]):
            response_type = "order_issue"
        elif any(word in message_lower for word in ["refund", "return", "money"]):
            response_type = "refund_request"
        elif any(word in message_lower for word in ["problem", "issue", "not working"]):
            response_type = "technical_problem"
        else:
            response_type = "general_inquiry"
        
        simulated_response = {
            "response": simulated_responses[response_type],
            "agent_type": "human",
            "agent_id": "HUMAN_001",
            "timestamp": datetime.now().isoformat(),
            "response_type": response_type,
            "estimated_resolution_time": "5-15 minutes",
            "requires_follow_up": True
        }
        
        # Log the simulated interaction
        self._log_simulated_interaction(user_id, chat_id, user_message, simulated_response)
        
        return simulated_response
    
    def _log_simulated_interaction(self, user_id: str, chat_id: str, 
                                  user_message: str, response: Dict[str, Any]):
        """Log simulated human agent interaction."""
        try:
            log_file = "logs/system/simulated_interactions.json"
            os.makedirs(os.path.dirname(log_file), exist_ok=True)
            
            interaction = {
                "timestamp": datetime.now().isoformat(),
                "user_id": user_id,
                "chat_id": chat_id,
                "user_message": user_message,
                "human_response": response,
                "simulation": True
            }
            
            # Load existing interactions
            interactions = []
            if os.path.exists(log_file):
                with open(log_file, 'r') as f:
                    interactions = json.load(f)
            
            # Add new interaction
            interactions.append(interaction)
            
            # Save updated interactions
            with open(log_file, 'w') as f:
                json.dump(interactions, f, indent=2)
            
        except Exception as e:
            print(f"⚠️ Failed to log simulated interaction: {e}")
    
    def display_handover_summary(self):
        """Display handover summary."""
        stats = self.get_handover_stats()
        
        print("\n📞 HUMAN AGENT HANDOVER SUMMARY")
        print("="*50)
        print(f"Total handovers: {stats['total_handovers']}")
        print(f"Contact number: {self.contact_number}")
        print("-"*50)
        
        if stats['reasons']:
            print("Handover reasons:")
            for reason, count in stats['reasons'].items():
                print(f"  {reason}: {count}")
        
        print("-"*50)
        
        if stats['recent_handovers']:
            print("Recent handovers:")
            for handover in stats['recent_handovers'][:3]:
                timestamp = handover['timestamp'][:19].replace('T', ' ')
                print(f"  {timestamp} - {handover['reason']} - {handover['user_id']}")
        
        print("="*50 + "\n")

def test_human_agent_simulator():
    """Test the human agent simulator."""
    print("🧪 Testing Human Agent Simulator...")
    
    # Initialize simulator
    simulator = HumanAgentSimulator()
    
    # Test handover initiation
    handover_data = simulator.initiate_handover(
        user_id="u_1001",
        chat_id="chat_test_001",
        reason="authentication_failed",
        context={"attempts": 3, "last_attempt": "2024-01-15T10:30:00Z"}
    )
    
    print(f"✅ Handover initiated: {handover_data['handover_initiated']}")
    print(f"   Message: {handover_data['handover_message']}")
    print(f"   Reference ID: {handover_data['reference_id']}")
    
    # Test simulated human response
    simulated_response = simulator.simulate_human_response(
        user_id="u_1001",
        chat_id="chat_test_001",
        user_message="I need help with my order"
    )
    
    print(f"✅ Simulated human response: {simulated_response['response'][:50]}...")
    print(f"   Agent ID: {simulated_response['agent_id']}")
    print(f"   Response type: {simulated_response['response_type']}")
    
    # Test handover stats
    stats = simulator.get_handover_stats()
    print(f"✅ Handover stats: {stats['total_handovers']} total handovers")
    
    # Display summary
    simulator.display_handover_summary()
    
    print("🎉 Human agent simulator tests completed!")

if __name__ == "__main__":
    test_human_agent_simulator()
