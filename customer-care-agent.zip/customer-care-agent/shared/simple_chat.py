#!/usr/bin/env python3
"""
Simple Chat System - Basic Hello and Let TriageAgent Decide
No user selection, no confusion - just simple conversation
"""

import sys
import os
import json
import time
import random
from datetime import datetime
from typing import Dict, List, Any, Optional

class SimpleChat:
    """Simple chat that starts with hello and lets TriageAgent decide everything."""
    
    def __init__(self, system_orchestrator):
        """Initialize the simple chat."""
        self.system = system_orchestrator
        self.chat_session = {
            'start_time': None,
            'end_time': None,
            'messages': [],
            'authenticated_user': None,
            'auth_required': False
        }
    
    def start_simple_chat(self) -> None:
        """Start the simple chat - just say hello and ask how to help."""
        print("🤖 Hello! I'm your Customer Care Agent.")
        print("How can I help you today?")
        print("\n💡 Just tell me what you need help with!")
        print("💡 Type 'quit' to end our conversation.")
        print("-" * 60)
        
        # Initialize chat session
        self.chat_session['start_time'] = datetime.now()
        
        # Main chat loop
        while True:
            try:
                # Get user input
                message = input("\n💬 You: ").strip()
                
                # Handle quit command
                if message.lower() in ['quit', 'exit', 'bye']:
                    print("\n👋 Thank you for chatting with me! Have a great day!")
                    break
                
                # Handle empty message
                if not message.strip():
                    print("💡 Please tell me how I can help you!")
                    continue
                
                # Process the message
                self.process_message(message)
                
            except KeyboardInterrupt:
                print("\n\n👋 Chat ended. Thank you!")
                break
            except Exception as e:
                print(f"\n❌ Sorry, something went wrong: {e}")
                print("💡 Please try again or type 'quit' to exit")
        
        # End session
        self.chat_session['end_time'] = datetime.now()
    
    def process_message(self, message: str) -> None:
        """Process user message and let TriageAgent decide what to do."""
        print(f"\n🤖 Let me understand what you need...")
        
        # Analyze the message
        intent_result = self.analyze_intent(message)
        
        # Show TriageAgent thinking
        self.show_triage_agent_thinking(message, intent_result)
        
        # Handle based on intent
        if intent_result['auth_required']:
            self.handle_authentication_required(message, intent_result)
        else:
            self.handle_direct_response(message, intent_result)
    
    def analyze_intent(self, message: str) -> Dict[str, Any]:
        """Analyze user intent and determine if authentication is needed."""
        message_lower = message.lower()
        
        # Simple intent analysis
        if any(word in message_lower for word in ['order', 'track', 'status', 'shipping', 'delivery']):
            return {
                'intent': 'order_status',
                'confidence': 0.9,
                'auth_required': True,
                'reason': 'Order information requires authentication'
            }
        elif any(word in message_lower for word in ['refund', 'return', 'money', 'cancel']):
            return {
                'intent': 'refunds',
                'confidence': 0.9,
                'auth_required': True,
                'reason': 'Refund requests require authentication'
            }
        elif any(word in message_lower for word in ['problem', 'issue', 'troubleshoot', 'not working', 'broken']):
            return {
                'intent': 'troubleshooting',
                'confidence': 0.8,
                'auth_required': True,
                'reason': 'Technical support requires authentication'
            }
        elif any(word in message_lower for word in ['account', 'login', 'password', 'username']):
            return {
                'intent': 'account_issues',
                'confidence': 0.9,
                'auth_required': True,
                'reason': 'Account issues require authentication'
            }
        elif any(word in message_lower for word in ['buy', 'purchase', 'product', 'price', 'catalog']):
            return {
                'intent': 'sales_inquiry',
                'confidence': 0.8,
                'auth_required': False,
                'reason': 'General product information'
            }
        else:
            return {
                'intent': 'general_inquiry',
                'confidence': 0.7,
                'auth_required': False,
                'reason': 'General question'
            }
    
    def show_triage_agent_thinking(self, message: str, intent_result: Dict[str, Any]) -> None:
        """Show what the TriageAgent is thinking."""
        print("\n🧠 TriageAgent Analysis:")
        print(f"📝 Your message: \"{message}\"")
        print(f"🎯 Intent: {intent_result['intent'].replace('_', ' ').title()}")
        print(f"📊 Confidence: {intent_result['confidence']:.1%}")
        print(f"🔐 Authentication needed: {'Yes' if intent_result['auth_required'] else 'No'}")
        print(f"📋 Reason: {intent_result['reason']}")
        print("-" * 50)
    
    def handle_direct_response(self, message: str, intent_result: Dict[str, Any]) -> None:
        """Handle messages that don't require authentication."""
        print(f"💬 I can help you with that!")
        
        if intent_result['intent'] == 'sales_inquiry':
            response = "I'd be happy to help you with our products! We have a wide range of items available. What specific product are you interested in?"
        else:
            response = "I'd be happy to help you! Could you please provide more details about what you need assistance with?"
        
        print(f"🤖 {response}")
        
        # Store message
        self.chat_session['messages'].append({
            'user': message,
            'agent': response,
            'intent': intent_result['intent'],
            'auth_required': False,
            'timestamp': datetime.now()
        })
    
    def handle_authentication_required(self, message: str, intent_result: Dict[str, Any]) -> None:
        """Handle messages that require authentication."""
        print(f"🔐 I need to verify your identity to help with this request.")
        print(f"Let me authenticate you step by step...")
        
        # Load demo users
        demo_users = self.load_demo_users()
        
        # Step 1: Username
        print(f"\n📋 Step 1: Username")
        username = input("👤 Please enter your username: ").strip()
        
        # Find matching user
        matching_user = None
        for user in demo_users:
            if user['username'].lower() == username.lower():
                matching_user = user
                break
        
        if not matching_user:
            print(f"❌ Username not found. Here are some demo users you can try:")
            for user in demo_users[:5]:
                print(f"   • {user['username']}")
            print(f"🤖 I can still help with general questions. What else can I assist you with?")
            return
        
        print(f"✅ Username verified: {matching_user['full_name']}")
        
        # Step 2: Password
        print(f"\n📋 Step 2: Password")
        password = input(f"🔐 Please enter your password: ").strip()
        
        if password != matching_user['password']:
            print(f"❌ Password incorrect. Here's a hint: {matching_user['password']}")
            print(f"🤖 I can still help with general questions. What else can I assist you with?")
            return
        
        print(f"✅ Password verified!")
        
        # Step 3: Email
        print(f"\n📋 Step 3: Email")
        email = input(f"📧 Please enter your email: ").strip()
        
        if email.lower() != matching_user['email'].lower():
            print(f"❌ Email doesn't match. Expected: {matching_user['email']}")
            print(f"🤖 I can still help with general questions. What else can I assist you with?")
            return
        
        print(f"✅ Email verified!")
        
        # Authentication successful
        print(f"\n🎉 Authentication successful!")
        print(f"✅ Welcome back, {matching_user['full_name']}!")
        print(f"🤖 Now I can help you with your request!")
        
        # Store authenticated user
        self.chat_session['authenticated_user'] = matching_user
        
        # Answer the original question
        self.answer_authenticated_question(message, intent_result, matching_user)
    
    def answer_authenticated_question(self, message: str, intent_result: Dict[str, Any], user: Dict[str, Any]) -> None:
        """Answer the user's question now that they're authenticated."""
        intent = intent_result['intent']
        
        if intent == 'order_status':
            response = f"Great! I can see your order status now, {user['full_name']}. Your order #12345 is currently 'In Transit' and should arrive within 2-3 business days. You can track it using tracking number TRK789456123."
        elif intent == 'refunds':
            response = f"I've initiated your refund request, {user['full_name']}. Your refund of ₹2,499 will be processed within 5-7 business days and credited back to your original payment method."
        elif intent == 'troubleshooting':
            response = f"I can help you troubleshoot this issue, {user['full_name']}. Let me guide you through some steps to resolve this problem. First, can you tell me what specific error messages you're seeing?"
        elif intent == 'account_issues':
            response = f"Now that you're authenticated, I can help you with your account issues, {user['full_name']}. What specific problem are you experiencing with your account?"
        else:
            response = f"Now that you're authenticated, I can provide you with detailed information, {user['full_name']}. What specific information do you need?"
        
        print(f"\n🤖 {response}")
        
        # Store message
        self.chat_session['messages'].append({
            'user': message,
            'agent': response,
            'intent': intent_result['intent'],
            'auth_required': True,
            'authenticated': True,
            'user_id': user['user_id'],
            'timestamp': datetime.now()
        })
    
    def load_demo_users(self) -> List[Dict[str, Any]]:
        """Load demo users for testing."""
        try:
            with open('shared/fixtures/password_reference.json', 'r') as f:
                all_users = json.load(f)
            
            # Get random sample
            user_list = list(all_users.items())
            random.shuffle(user_list)
            demo_users = user_list[:10]
            
            formatted_users = []
            for user_id, creds in demo_users:
                formatted_users.append({
                    'user_id': user_id,
                    'username': creds.get('username', 'N/A'),
                    'email': creds.get('email', 'N/A'),
                    'password': creds.get('plain_password', 'N/A'),
                    'full_name': creds.get('full_name', 'N/A')
                })
            
            return formatted_users
            
        except Exception as e:
            print(f"❌ Error loading demo users: {e}")
            return []
