#!/usr/bin/env python3
"""
Complete System Orchestrator for Customer Care Agent
Integrates all components: LangGraph, Authentication, Chat History, Audit, Human Agent
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Any, Optional

# Import all system components
from langgraph_orchestrator import LangGraphOrchestrator
from auth_manager import AuthenticationManager
from chat_history_manager import ChatHistoryManager
from enhanced_audit_logger import EnhancedAuditLogger
from human_agent_simulator import HumanAgentSimulator
from follow_up_generator import FollowUpGenerator

class CompleteSystemOrchestrator:
    """Complete system orchestrator integrating all components."""
    
    def __init__(self, openai_api_key: str = None):
        """Initialize the complete system."""
        self.openai_api_key = openai_api_key
        
        # Initialize all system components
        self.langgraph_orchestrator = LangGraphOrchestrator(openai_api_key)
        self.auth_manager = AuthenticationManager()
        self.chat_manager = ChatHistoryManager()
        self.audit_logger = EnhancedAuditLogger()
        self.human_agent_simulator = HumanAgentSimulator()
        self.follow_up_generator = FollowUpGenerator(openai_api_key)
        
        print("🚀 Complete Customer Care Agent System Initialized")
        print("   ✅ LangGraph Orchestrator")
        print("   ✅ Authentication Manager")
        print("   ✅ Chat History Manager")
        print("   ✅ Enhanced Audit Logger")
        print("   ✅ Human Agent Simulator")
        print("   ✅ Follow-up Question Generator")
    
    def process_customer_message(self, user_id: str, message: str, 
                               session_id: str = None, chat_id: str = None,
                               **kwargs) -> Dict[str, Any]:
        """
        Process a customer message through the complete system.
        
        Args:
            user_id: User ID
            message: Customer message
            session_id: Existing session ID (optional)
            chat_id: Existing chat ID (optional)
            **kwargs: Additional parameters (password, email_token, etc.)
            
        Returns:
            Complete system response
        """
        try:
            # Generate chat ID if not provided
            if not chat_id:
                chat_id = self._generate_chat_id(user_id)
            
            # Start audit logging
            self.audit_logger.start_chat_session(user_id, chat_id, session_id, message)
            
            # Start chat history
            if not session_id:
                chat_session = self.chat_manager.start_new_chat(
                    user_id, chat_id, session_id, message
                )
            else:
                # Add message to existing chat
                self.chat_manager.add_message_to_chat(user_id, chat_id, "user", message)
            
            # Process through LangGraph orchestrator
            orchestrator_result = self.langgraph_orchestrator.process_message(
                user_id, message, session_id=session_id, chat_id=chat_id, **kwargs
            )
            
            # Add assistant response to chat history
            if orchestrator_result["success"]:
                self.chat_manager.add_message_to_chat(
                    user_id, chat_id, "assistant", orchestrator_result["response"]
                )
                
                # Update chat metadata
                self.chat_manager.update_chat_metadata(
                    user_id, chat_id,
                    topics=orchestrator_result.get("topics", []),
                    intents=[orchestrator_result.get("intent")] if orchestrator_result.get("intent") else [],
                    auth_required=orchestrator_result.get("auth_required", False),
                    auth_successful=orchestrator_result.get("auth_successful", False)
                )
            
            # Log all audit events
            for event in orchestrator_result.get("audit_events", []):
                self.audit_logger.log_event(
                    user_id, chat_id, event["event_type"], event
                )
            
            # End chat session and audit
            audit_summary = self.audit_logger.end_chat_session(user_id, chat_id)
            self.chat_manager.end_chat_session(user_id, chat_id)
            
            # Prepare comprehensive response
            response = {
                "success": orchestrator_result["success"],
                "response": orchestrator_result["response"],
                "chat_id": chat_id,
                "session_id": orchestrator_result.get("session_id"),
                "intent": orchestrator_result.get("intent"),
                "confidence": orchestrator_result.get("confidence"),
                "reasoning": orchestrator_result.get("reasoning"),
                "follow_up_questions": orchestrator_result.get("follow_up_questions", []),
                "auth_required": orchestrator_result.get("auth_required", False),
                "auth_successful": orchestrator_result.get("auth_successful", False),
                "requires_human_agent": orchestrator_result.get("requires_human_agent", False),
                "audit_summary": audit_summary,
                "system_status": "operational",
                "timestamp": datetime.now().isoformat()
            }
            
            # Handle human agent handover if required
            if orchestrator_result.get("requires_human_agent"):
                handover_data = self.human_agent_simulator.initiate_handover(
                    user_id, chat_id, "authentication_failed"
                )
                response["human_handover"] = handover_data
            
            return response
            
        except Exception as e:
            # Handle system errors gracefully
            error_response = {
                "success": False,
                "error": f"System error: {str(e)}",
                "response": "I apologize, but we're experiencing technical difficulties. Please try again later or call our customer care line.",
                "chat_id": chat_id or self._generate_chat_id(user_id),
                "system_status": "error",
                "timestamp": datetime.now().isoformat()
            }
            
            # Log error event
            try:
                self.audit_logger.log_event(
                    user_id, chat_id or error_response["chat_id"],
                    "system_error", {"error": str(e)}
                )
            except:
                pass  # Don't let audit logging errors compound the problem
            
            return error_response
    
    def authenticate_user(self, user_id: str, password: str, email_token: str = None) -> Dict[str, Any]:
        """
        Authenticate a user with multi-factor authentication.
        
        Args:
            user_id: User ID
            password: User password
            email_token: Email verification token
            
        Returns:
            Authentication result
        """
        try:
            auth_result = self.auth_manager.handle_authentication_attempt(
                user_id, password, email_token
            )
            
            return {
                "success": auth_result["success"],
                "session_id": auth_result.get("session_id"),
                "chat_id": auth_result.get("chat_id"),
                "auth_level": auth_result.get("auth_level"),
                "message": auth_result.get("message"),
                "requires_email_verification": auth_result.get("requires_email_verification", False),
                "email_token": auth_result.get("email_token"),
                "requires_human_agent": auth_result.get("requires_human_agent", False)
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Authentication failed: {str(e)}",
                "requires_human_agent": True
            }
    
    def get_user_chat_history(self, user_id: str, limit: int = 10) -> Dict[str, Any]:
        """Get user's chat history."""
        try:
            chat_history = self.chat_manager.get_user_chat_history(user_id, limit)
            chat_summary = self.chat_manager.get_chat_summary(user_id)
            
            return {
                "success": True,
                "chat_history": chat_history,
                "summary": chat_summary
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to retrieve chat history: {str(e)}"
            }
    
    def get_system_stats(self) -> Dict[str, Any]:
        """Get comprehensive system statistics."""
        try:
            auth_stats = self.auth_manager.get_authentication_stats()
            chat_stats = self.chat_manager.get_history_stats()
            audit_stats = self.audit_logger.get_audit_stats()
            handover_stats = self.human_agent_simulator.get_handover_stats()
            
            return {
                "success": True,
                "timestamp": datetime.now().isoformat(),
                "authentication": auth_stats,
                "chat_history": chat_stats,
                "audit_logging": audit_stats,
                "human_handovers": handover_stats,
                "system_status": "operational"
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to get system stats: {str(e)}"
            }
    
    def display_system_dashboard(self):
        """Display comprehensive system dashboard."""
        print("\n" + "="*80)
        print("🎛️  COMPLETE CUSTOMER CARE AGENT SYSTEM DASHBOARD")
        print("="*80)
        
        # Get system stats
        stats = self.get_system_stats()
        
        if stats["success"]:
            auth = stats["authentication"]
            chat = stats["chat_history"]
            audit = stats["audit_logging"]
            handovers = stats["human_handovers"]
            
            print(f"📊 SYSTEM OVERVIEW")
            print(f"   Total Users: {auth['total_users']}")
            print(f"   Active Sessions: {auth['session_stats']['active_sessions']}")
            print(f"   Total Chats: {chat['total_chats']}")
            print(f"   Total Events: {audit['total_events']}")
            print(f"   Human Handovers: {handovers['total_handovers']}")
            
            print(f"\n🔐 AUTHENTICATION")
            print(f"   Active Users: {auth['active_users']}")
            print(f"   Auth Level 1: {auth['auth_level_1_users']}")
            print(f"   Auth Level 2: {auth['auth_level_2_users']}")
            print(f"   Session Duration: {auth['session_stats']['session_duration_minutes']} minutes")
            
            print(f"\n💬 CHAT HISTORY")
            print(f"   Average Chats/User: {chat['average_chats_per_user']}")
            if chat.get('most_active_users') and len(chat['most_active_users']) > 0:
                top_user = chat['most_active_users'][0]
                if isinstance(top_user, dict):
                    print(f"   Most Active User: {top_user.get('user_id', 'N/A')} ({top_user.get('total_chats', 0)} chats)")
                else:
                    print(f"   Most Active User: {top_user[0]} ({top_user[1]} chats)")
            
            print(f"\n📋 AUDIT LOGGING")
            print(f"   Average Events/Chat: {audit['average_events_per_chat']:.1f}")
            if audit.get('most_active_users') and len(audit['most_active_users']) > 0:
                top_audit_user = audit['most_active_users'][0]
                print(f"   Most Audited User: {top_audit_user[0]}")
            
            print(f"\n📞 HUMAN HANDOVERS")
            print(f"   Total Handovers: {handovers['total_handovers']}")
            if handovers['reasons']:
                top_reason = max(handovers['reasons'].items(), key=lambda x: x[1])
                print(f"   Most Common Reason: {top_reason[0]} ({top_reason[1]})")
        
        else:
            print(f"❌ Failed to load system stats: {stats['error']}")
        
        print("="*80 + "\n")
    
    def _generate_chat_id(self, user_id: str) -> str:
        """Generate a unique chat ID."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        import secrets
        random_suffix = secrets.token_urlsafe(6)
        return f"chat_{user_id}_{timestamp}_{random_suffix}"
    
    def run_demo_scenario(self, scenario_name: str, user_id: str = "u_1001") -> Dict[str, Any]:
        """Run a demo scenario to showcase system capabilities."""
        
        demo_scenarios = {
            "general_inquiry": {
                "message": "Hello, what are your business hours?",
                "description": "General inquiry that doesn't require authentication"
            },
            "order_status": {
                "message": "I need to check the status of my order #12345",
                "description": "Order status inquiry requiring authentication"
            },
            "refund_request": {
                "message": "I want to request a refund for my recent purchase",
                "description": "Refund request requiring high-level authentication"
            },
            "troubleshooting": {
                "message": "My product isn't working properly, can you help?",
                "description": "Technical support requiring authentication"
            }
        }
        
        if scenario_name not in demo_scenarios:
            return {"error": f"Unknown scenario: {scenario_name}"}
        
        scenario = demo_scenarios[scenario_name]
        
        print(f"\n🎬 DEMO SCENARIO: {scenario_name.upper()}")
        print(f"📝 Description: {scenario['description']}")
        print(f"👤 User: {user_id}")
        print(f"💬 Message: {scenario['message']}")
        print("-"*60)
        
        # Process the scenario
        result = self.process_customer_message(user_id, scenario['message'])
        
        print(f"✅ Response: {result['response']}")
        print(f"🎯 Intent: {result.get('intent', 'N/A')}")
        print(f"🔐 Auth Required: {result.get('auth_required', False)}")
        print(f"✅ Auth Successful: {result.get('auth_successful', False)}")
        print(f"👨‍💼 Human Agent: {result.get('requires_human_agent', False)}")
        
        if result.get('follow_up_questions'):
            print(f"❓ Follow-up Questions: {len(result['follow_up_questions'])}")
            for i, q in enumerate(result['follow_up_questions'][:2], 1):
                print(f"   {i}. {q}")
        
        print(f"📊 Chat ID: {result['chat_id']}")
        print(f"⏰ Timestamp: {result['timestamp']}")
        print("-"*60)
        
        return result

def test_complete_system():
    """Test the complete system orchestrator."""
    print("🧪 Testing Complete System Orchestrator...")
    
    # Initialize complete system
    system = CompleteSystemOrchestrator()
    
    # Test system stats
    stats = system.get_system_stats()
    print(f"✅ System stats retrieved: {'PASSED' if stats['success'] else 'FAILED'}")
    
    # Test demo scenarios
    scenarios = ["general_inquiry", "order_status", "refund_request", "troubleshooting"]
    
    for scenario in scenarios:
        result = system.run_demo_scenario(scenario)
        print(f"✅ Demo scenario '{scenario}': {'PASSED' if result.get('success') else 'FAILED'}")
    
    # Display system dashboard
    system.display_system_dashboard()
    
    print("🎉 Complete system tests completed!")

if __name__ == "__main__":
    test_complete_system()
