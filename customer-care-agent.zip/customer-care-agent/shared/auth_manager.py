#!/usr/bin/env python3
"""
Authentication Manager for Customer Care Agent System
Handles multi-factor authentication with user ID, password, and email verification
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, Optional, Tuple, Any
from password_manager import PasswordManager
from email_verification import EmailVerificationSystem
from session_manager import SessionManager

class AuthenticationManager:
    """Manages multi-factor authentication for the customer care system."""
    
    def __init__(self, users_file: str = "shared/fixtures/users.json"):
        self.users_file = users_file
        self.password_manager = PasswordManager()
        self.email_system = EmailVerificationSystem()
        self.session_manager = SessionManager()
        self.max_auth_attempts = 3
        self.load_users()
    
    def load_users(self):
        """Load user data from file."""
        # Try multiple possible paths
        possible_paths = [
            self.users_file,
            f"../{self.users_file}",
            f"../../{self.users_file}",
            os.path.join(os.path.dirname(__file__), "fixtures", "users.json"),
            os.path.join(os.path.dirname(os.path.dirname(__file__)), "shared", "fixtures", "users.json")
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                try:
                    with open(path, 'r') as f:
                        data = json.load(f)
                        self.users = {user["user_id"]: user for user in data["users"]}
                        print(f"✅ Loaded {len(self.users)} users from {path}")
                        return
                except (json.JSONDecodeError, FileNotFoundError, KeyError) as e:
                    print(f"❌ Failed to load users from {path}: {e}")
                    continue
        
        print(f"❌ Could not find users.json file. Tried paths: {possible_paths}")
        self.users = {}
    
    def authenticate_user(self, user_id: str, password: str, email_token: str = None) -> Dict[str, Any]:
        """
        Authenticate a user with multi-factor authentication.
        
        Args:
            user_id: User ID to authenticate
            password: User's password
            email_token: Email verification token (optional for first attempt)
            
        Returns:
            Dictionary with authentication result
        """
        # Check if user exists
        if user_id not in self.users:
            return {
                "success": False,
                "error": "User not found",
                "error_code": "USER_NOT_FOUND"
            }
        
        user = self.users[user_id]
        
        # Verify password
        if not self.password_manager.verify_password(password, user["password_hash"]):
            return {
                "success": False,
                "error": "Invalid credentials",
                "error_code": "INVALID_PASSWORD"
            }
        
        # Check if email token is provided
        if email_token:
            # Verify email token
            token_result = self.email_system.verify_token(email_token)
            if not token_result["valid"]:
                return {
                    "success": False,
                    "error": f"Email verification failed: {token_result['error']}",
                    "error_code": "INVALID_EMAIL_TOKEN"
                }
            
            # Check if token belongs to this user
            if token_result["user_id"] != user_id:
                return {
                    "success": False,
                    "error": "Email token does not match user",
                    "error_code": "TOKEN_USER_MISMATCH"
                }
        else:
            # Generate email verification token for first attempt
            email_token = self.email_system.generate_verification_token(
                user_id, user["email"]
            )
            
            return {
                "success": False,
                "requires_email_verification": True,
                "email_token": email_token,
                "message": "Password verified. Please check your email for verification code.",
                "error_code": "EMAIL_VERIFICATION_REQUIRED"
            }
        
        # Create session after successful authentication
        session_data = self.session_manager.create_session(
            user_id=user_id,
            auth_method="multi_factor",
            auth_level=user["auth_level"]
        )
        
        return {
            "success": True,
            "user_id": user_id,
            "session_id": session_data["session_id"],
            "chat_id": session_data["chat_id"],
            "auth_level": user["auth_level"],
            "message": "Authentication successful",
            "session_expires_at": session_data["expires_at"]
        }
    
    def start_authentication_flow(self, user_id: str) -> Dict[str, Any]:
        """
        Start the authentication flow for a user.
        
        Args:
            user_id: User ID to start authentication for
            
        Returns:
            Dictionary with authentication flow status
        """
        if user_id not in self.users:
            return {
                "success": False,
                "error": "User not found",
                "error_code": "USER_NOT_FOUND"
            }
        
        user = self.users[user_id]
        
        return {
            "success": True,
            "user_id": user_id,
            "username": user["username"],
            "email": user["email"],
            "auth_level": user["auth_level"],
            "message": "Authentication flow started. Please provide your password.",
            "requires_password": True
        }
    
    def validate_session(self, session_id: str) -> Dict[str, Any]:
        """
        Validate an existing session.
        
        Args:
            session_id: Session ID to validate
            
        Returns:
            Dictionary with session validation result
        """
        return self.session_manager.validate_session(session_id)
    
    def handle_authentication_attempt(self, user_id: str, password: str, 
                                    email_token: str = None, attempt_number: int = 1) -> Dict[str, Any]:
        """
        Handle a complete authentication attempt with retry logic.
        
        Args:
            user_id: User ID to authenticate
            password: User's password
            email_token: Email verification token
            attempt_number: Current attempt number (1-3)
            
        Returns:
            Dictionary with authentication result
        """
        # Perform authentication
        auth_result = self.authenticate_user(user_id, password, email_token)
        
        # If authentication failed and we haven't reached max attempts
        if not auth_result["success"] and attempt_number < self.max_auth_attempts:
            if auth_result["error_code"] == "INVALID_PASSWORD":
                return {
                    "success": False,
                    "error": "Invalid credentials. Please try again.",
                    "attempt_number": attempt_number,
                    "remaining_attempts": self.max_auth_attempts - attempt_number,
                    "requires_retry": True,
                    "error_code": "INVALID_CREDENTIALS_RETRY"
                }
            elif auth_result["error_code"] == "INVALID_EMAIL_TOKEN":
                return {
                    "success": False,
                    "error": "Invalid email verification code. Please try again.",
                    "attempt_number": attempt_number,
                    "remaining_attempts": self.max_auth_attempts - attempt_number,
                    "requires_retry": True,
                    "error_code": "INVALID_EMAIL_TOKEN_RETRY"
                }
        
        # If authentication failed and we've reached max attempts
        if not auth_result["success"] and attempt_number >= self.max_auth_attempts:
            return {
                "success": False,
                "error": "I am unable to authenticate you. Please call +91 998877654321 to our customer care",
                "attempt_number": attempt_number,
                "requires_human_agent": True,
                "error_code": "MAX_ATTEMPTS_EXCEEDED"
            }
        
        # Authentication successful
        if auth_result["success"]:
            return {
                "success": True,
                "user_id": auth_result["user_id"],
                "session_id": auth_result["session_id"],
                "chat_id": auth_result["chat_id"],
                "auth_level": auth_result["auth_level"],
                "message": "Authentication successful",
                "session_expires_at": auth_result["session_expires_at"]
            }
        
        # Return original result for other cases (like email verification required)
        return auth_result
    
    def get_user_info(self, user_id: str) -> Dict[str, Any]:
        """
        Get user information (non-sensitive data only).
        
        Args:
            user_id: User ID to get info for
            
        Returns:
            Dictionary with user information
        """
        if user_id not in self.users:
            return {
                "success": False,
                "error": "User not found"
            }
        
        user = self.users[user_id]
        
        return {
            "success": True,
            "user_id": user["user_id"],
            "username": user["username"],
            "email": user["email"],
            "auth_level": user["auth_level"],
            "profile": {
                "first_name": user["profile"]["first_name"],
                "last_name": user["profile"]["last_name"],
                "account_status": user["profile"]["account_status"],
                "created_at": user["profile"]["created_at"],
                "last_login": user["profile"]["last_login"]
            }
        }
    
    def check_auth_requirements(self, user_id: str, requested_action: str) -> Dict[str, Any]:
        """
        Check authentication requirements for a specific action.
        
        Args:
            user_id: User ID to check
            requested_action: Action being requested
            
        Returns:
            Dictionary with authentication requirements
        """
        # Define authentication requirements for different actions
        auth_requirements = {
            "order_status": 1,
            "order_details": 2,
            "refund_request": 2,
            "refunds": 2,
            "troubleshooting": 1,
            "account_info": 2,
            "general_inquiry": 0,
            "product_info": 0,
            "policy_lookup": 0,
            "business_hours": 0,
            "contact_info": 0,
            "hello": 0,
            "greeting": 0,
            "help": 0
        }
        
        required_level = auth_requirements.get(requested_action, 0)  # Default to 0 (no auth) instead of 1
        
        # For anonymous users, only require auth for level 1+ actions
        if user_id == "anonymous_user" or user_id not in self.users:
            if required_level == 0:
                return {
                    "auth_required": False,
                    "required_level": 0,
                    "reason": "No authentication required for this action"
                }
            else:
                return {
                    "auth_required": True,
                    "required_level": required_level,
                    "reason": f"Action '{requested_action}' requires authentication level {required_level}"
                }
        
        user = self.users[user_id]
        
        if required_level == 0:
            return {
                "auth_required": False,
                "required_level": 0,
                "reason": "No authentication required for this action"
            }
        
        return {
            "auth_required": True,
            "required_level": required_level,
            "user_auth_level": user["auth_level"],
            "reason": f"Action '{requested_action}' requires authentication level {required_level}"
        }
    
    def get_authentication_stats(self) -> Dict[str, Any]:
        """
        Get authentication system statistics.
        
        Returns:
            Dictionary with authentication statistics
        """
        session_stats = self.session_manager.get_session_stats()
        
        return {
            "total_users": len(self.users),
            "active_users": len([u for u in self.users.values() if u["profile"]["account_status"] == "active"]),
            "auth_level_1_users": len([u for u in self.users.values() if u["auth_level"] == 1]),
            "auth_level_2_users": len([u for u in self.users.values() if u["auth_level"] == 2]),
            "session_stats": session_stats,
            "max_auth_attempts": self.max_auth_attempts
        }

def test_authentication_manager():
    """Test the authentication manager functionality."""
    print("🧪 Testing Authentication Manager...")
    
    # Initialize authentication manager
    auth_mgr = AuthenticationManager()
    
    # Test user lookup
    user_id = "u_1001"
    user_info = auth_mgr.get_user_info(user_id)
    print(f"✅ User info retrieved: {'PASSED' if user_info['success'] else 'FAILED'}")
    
    if user_info["success"]:
        print(f"   User: {user_info['profile']['first_name']} {user_info['profile']['last_name']}")
        print(f"   Username: {user_info['username']}")
        print(f"   Email: {user_info['email']}")
        print(f"   Auth Level: {user_info['auth_level']}")
    
    # Test authentication flow start
    auth_start = auth_mgr.start_authentication_flow(user_id)
    print(f"✅ Authentication flow started: {'PASSED' if auth_start['success'] else 'FAILED'}")
    
    # Test authentication requirements
    auth_req = auth_mgr.check_auth_requirements(user_id, "order_status")
    print(f"✅ Auth requirements check: {'PASSED' if auth_req['auth_required'] else 'FAILED'}")
    print(f"   Required level: {auth_req['required_level']}")
    print(f"   Reason: {auth_req['reason']}")
    
    # Test authentication stats
    stats = auth_mgr.get_authentication_stats()
    print(f"✅ Authentication stats: {stats['total_users']} total users")
    
    print("🎉 Authentication manager tests completed!")

if __name__ == "__main__":
    test_authentication_manager()
