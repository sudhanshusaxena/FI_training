#!/usr/bin/env python3
"""
Evaluation Runner for Customer Care Agent
Runs comprehensive evaluations and logs results to Matrix.csv
"""

import os
import csv
import json
import time
import random
from datetime import datetime
from typing import Dict, List, Any, Optional
import sys

# Add shared directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from llm_judge_evaluator import LLMJudgeEvaluator
from test_scenario_generator import TestScenarioGenerator

class EvaluationRunner:
    """Runs comprehensive evaluations of the customer care agent system."""
    
    def __init__(self, system_orchestrator, api_key: str = None):
        """Initialize the evaluation runner."""
        self.system = system_orchestrator
        self.llm_judge = LLMJudgeEvaluator(api_key)
        self.scenario_generator = TestScenarioGenerator()
        self.matrix_file = "Matrix.csv"
        
        # Load demo users
        self.demo_users = self._load_demo_users()
        
        # Initialize CSV file if it doesn't exist
        self._initialize_matrix_csv()
    
    def _load_demo_users(self) -> List[str]:
        """Load demo user IDs for testing."""
        try:
            with open('shared/fixtures/password_reference.json', 'r') as f:
                credentials = json.load(f)
                return list(credentials.keys())
        except:
            return ['u_1001', 'u_1002', 'u_1003', 'u_1004', 'u_1005']
    
    def _initialize_matrix_csv(self):
        """Initialize the Matrix.csv file with headers if it doesn't exist."""
        if not os.path.exists(self.matrix_file):
            headers = [
                'timestamp', 'test_id', 'user_id', 'scenario_type', 'persona',
                'user_message', 'detected_intent', 'intent_confidence',
                'auth_required', 'auth_successful', 'human_handover',
                'response_time', 'agent_response', 'follow_up_questions',
                'intent_classification_accuracy_score', 'intent_classification_accuracy_reasoning',
                'response_relevance_score', 'response_relevance_reasoning',
                'auth_decision_correctness_score', 'auth_decision_correctness_reasoning',
                'handover_appropriateness_score', 'handover_appropriateness_reasoning',
                'follow_up_quality_score', 'follow_up_quality_reasoning',
                'overall_satisfaction_score', 'overall_satisfaction_reasoning',
                'resolution_achieved', 'session_duration', 'error_occurred',
                'llm_judge_reasoning', 'model_used'
            ]
            
            with open(self.matrix_file, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(headers)
    
    def run_single_evaluation(self, scenario: Dict[str, Any], user_id: str = None) -> Dict[str, Any]:
        """Run evaluation for a single scenario."""
        if user_id is None:
            user_id = random.choice(self.demo_users)
        
        test_id = scenario.get('test_id', f"test_{datetime.now().strftime('%Y%m%d_%H%M%S')}")
        user_message = scenario.get('user_message', '')
        scenario_type = scenario.get('scenario_type', 'unknown')
        persona = scenario.get('persona', 'unknown')
        
        print(f"🧪 Running test: {test_id} - {scenario_type} ({persona})")
        print(f"👤 User: {user_id}")
        print(f"💬 Message: {user_message}")
        
        start_time = time.time()
        
        try:
            # Process the message through the system
            result = self.system.process_customer_message(user_id, user_message)
            
            response_time = time.time() - start_time
            
            # Extract system results
            detected_intent = result.get('intent', 'unknown')
            intent_confidence = result.get('confidence', 0.0)
            auth_required = result.get('auth_required', False)
            auth_successful = result.get('auth_successful', False)
            human_handover = result.get('requires_human_agent', False)
            agent_response = result.get('response', '')
            follow_up_questions = result.get('follow_up_questions', [])
            
            # Run LLM judge evaluation
            print(f"🤖 Running LLM judge evaluation...")
            evaluation = self.llm_judge.evaluate_interaction(
                user_message=user_message,
                detected_intent=detected_intent,
                intent_confidence=intent_confidence,
                auth_required=auth_required,
                auth_successful=auth_successful,
                human_handover=human_handover,
                agent_response=agent_response,
                follow_up_questions=follow_up_questions,
                response_time=response_time
            )
            
            # Prepare result for CSV logging
            csv_row = self._prepare_csv_row(
                test_id, user_id, scenario_type, persona, user_message,
                detected_intent, intent_confidence, auth_required, auth_successful,
                human_handover, response_time, agent_response, follow_up_questions,
                evaluation, result
            )
            
            # Log to CSV
            self._log_to_csv(csv_row)
            
            print(f"✅ Test completed successfully")
            print(f"📊 Intent: {detected_intent} (confidence: {intent_confidence:.2f})")
            print(f"🔐 Auth Required: {auth_required}, Successful: {auth_successful}")
            print(f"👨‍💼 Human Handover: {human_handover}")
            print(f"⏱️ Response Time: {response_time:.2f}s")
            
            return {
                "success": True,
                "test_id": test_id,
                "scenario_type": scenario_type,
                "persona": persona,
                "system_result": result,
                "evaluation": evaluation,
                "response_time": response_time,
                "csv_row": csv_row
            }
            
        except Exception as e:
            error_time = time.time() - start_time
            print(f"❌ Test failed: {e}")
            
            # Log error to CSV
            error_row = self._prepare_error_csv_row(
                test_id, user_id, scenario_type, persona, user_message, str(e), error_time
            )
            self._log_to_csv(error_row)
            
            return {
                "success": False,
                "test_id": test_id,
                "error": str(e),
                "response_time": error_time
            }
    
    def _prepare_csv_row(self, test_id, user_id, scenario_type, persona, user_message,
                        detected_intent, intent_confidence, auth_required, auth_successful,
                        human_handover, response_time, agent_response, follow_up_questions,
                        evaluation, system_result):
        """Prepare a row for CSV logging."""
        
        scores = evaluation.get('scores', {})
        
        # Determine if resolution was achieved
        resolution_achieved = not human_handover and auth_successful if auth_required else not auth_required
        
        # Get session duration if available
        session_duration = system_result.get('session_duration', 0)
        
        return [
            datetime.now().isoformat(),  # timestamp
            test_id,
            user_id,
            scenario_type,
            persona,
            user_message,
            detected_intent,
            intent_confidence,
            auth_required,
            auth_successful,
            human_handover,
            response_time,
            agent_response,
            json.dumps(follow_up_questions) if follow_up_questions else "",
            scores.get('intent_classification_accuracy', {}).get('score', 0),
            scores.get('intent_classification_accuracy', {}).get('reasoning', ''),
            scores.get('response_relevance', {}).get('score', 0),
            scores.get('response_relevance', {}).get('reasoning', ''),
            scores.get('auth_decision_correctness', {}).get('score', 0),
            scores.get('auth_decision_correctness', {}).get('reasoning', ''),
            scores.get('handover_appropriateness', {}).get('score', 0),
            scores.get('handover_appropriateness', {}).get('reasoning', ''),
            scores.get('follow_up_quality', {}).get('score', 0),
            scores.get('follow_up_quality', {}).get('reasoning', ''),
            scores.get('overall_satisfaction', {}).get('score', 0),
            scores.get('overall_satisfaction', {}).get('reasoning', ''),
            resolution_achieved,
            session_duration,
            False,  # error_occurred
            evaluation.get('raw_evaluation', ''),
            evaluation.get('model_used', '')
        ]
    
    def _prepare_error_csv_row(self, test_id, user_id, scenario_type, persona, user_message, error, response_time):
        """Prepare an error row for CSV logging."""
        return [
            datetime.now().isoformat(),  # timestamp
            test_id,
            user_id,
            scenario_type,
            persona,
            user_message,
            'error',  # detected_intent
            0.0,  # intent_confidence
            False,  # auth_required
            False,  # auth_successful
            True,  # human_handover (error = handover)
            response_time,
            f"Error: {error}",  # agent_response
            "",  # follow_up_questions
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  # all scores and reasoning
            False,  # resolution_achieved
            0,  # session_duration
            True,  # error_occurred
            f"System error: {error}",  # llm_judge_reasoning
            'error'  # model_used
        ]
    
    def _log_to_csv(self, row):
        """Log a row to the Matrix.csv file."""
        with open(self.matrix_file, 'a', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(row)
    
    def run_comprehensive_evaluation(self, num_scenarios_per_category: int = 10):
        """Run comprehensive evaluation with multiple scenario types."""
        print("🚀 Starting Comprehensive Customer Care Agent Evaluation")
        print("="*70)
        
        # Generate all scenarios
        print("📝 Generating test scenarios...")
        all_scenarios = self.scenario_generator.generate_all_scenarios()
        
        # Get summary
        summary = self.scenario_generator.get_scenario_summary(all_scenarios)
        print(f"✅ Generated {summary['total_scenarios']} total scenarios")
        print(f"📊 By type: {summary['by_type']}")
        print(f"👥 By persona: {summary['by_persona']}")
        print(f"🔐 Auth required: {summary['auth_required_count']}")
        print(f"🔄 Multi-turn: {summary['multi_turn_count']}")
        
        # Run evaluations
        results = []
        successful_tests = 0
        failed_tests = 0
        
        print(f"\n🧪 Running evaluations...")
        print("-" * 50)
        
        for i, scenario in enumerate(all_scenarios):
            print(f"\n[{i+1}/{len(all_scenarios)}] Running test...")
            
            result = self.run_single_evaluation(scenario)
            
            if result['success']:
                successful_tests += 1
            else:
                failed_tests += 1
            
            results.append(result)
            
            # Small delay between tests
            time.sleep(1)
        
        # Print final summary
        print(f"\n🎉 EVALUATION COMPLETED!")
        print("="*70)
        print(f"✅ Successful tests: {successful_tests}")
        print(f"❌ Failed tests: {failed_tests}")
        print(f"📊 Success rate: {(successful_tests/len(all_scenarios)*100):.1f}%")
        print(f"📄 Results logged to: {self.matrix_file}")
        
        return {
            "total_scenarios": len(all_scenarios),
            "successful_tests": successful_tests,
            "failed_tests": failed_tests,
            "success_rate": successful_tests / len(all_scenarios),
            "results": results,
            "matrix_file": self.matrix_file
        }
    
    def run_quick_evaluation(self, num_tests: int = 5):
        """Run a quick evaluation with a few test scenarios."""
        print(f"🚀 Running Quick Evaluation ({num_tests} tests)")
        print("="*50)
        
        # Generate a few random scenarios
        scenarios = self.scenario_generator.generate_random_scenarios(num_tests)
        
        results = []
        for i, scenario in enumerate(scenarios):
            print(f"\n[{i+1}/{num_tests}] Running quick test...")
            result = self.run_single_evaluation(scenario)
            results.append(result)
            time.sleep(0.5)  # Small delay
        
        print(f"\n✅ Quick evaluation completed!")
        print(f"📄 Results logged to: {self.matrix_file}")
        
        return results
