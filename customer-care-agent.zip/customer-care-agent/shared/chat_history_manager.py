#!/usr/bin/env python3
"""
Chat History Manager for Customer Care Agent System
Handles persistent chat history storage and retrieval between notebook runs
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from pathlib import Path

class ChatHistoryManager:
    """Manages persistent chat history for users."""
    
    def __init__(self, history_file: str = "shared/fixtures/chat_history.json"):
        self.history_file = history_file
        self.max_chats_per_user = 10  # Keep last 10 chats
        self.ensure_history_directory()
    
    def ensure_history_directory(self):
        """Ensure the history directory exists."""
        os.makedirs(os.path.dirname(self.history_file), exist_ok=True)
    
    def load_chat_history(self) -> Dict[str, Dict]:
        """Load chat history from file."""
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                return {}
        return {}
    
    def save_chat_history(self, history: Dict[str, Dict]):
        """Save chat history to file."""
        with open(self.history_file, 'w') as f:
            json.dump(history, f, indent=2)
    
    def start_new_chat(self, user_id: str, chat_id: str, session_id: str, 
                      initial_message: str = None) -> Dict[str, Any]:
        """
        Start a new chat session.
        
        Args:
            user_id: User ID
            chat_id: Unique chat ID
            session_id: Session ID
            initial_message: Initial user message
            
        Returns:
            Dictionary with chat session data
        """
        history = self.load_chat_history()
        
        # Initialize user history if not exists
        if user_id not in history:
            history[user_id] = {
                "user_id": user_id,
                "total_chats": 0,
                "chats": []
            }
        
        # Create new chat session
        chat_session = {
            "chat_id": chat_id,
            "session_id": session_id,
            "timestamp": datetime.now().isoformat(),
            "duration_minutes": 0,
            "conversation": [],
            "topics": [],
            "intents": [],
            "auth_required": False,
            "auth_successful": False,
            "follow_up_questions": [],
            "customer_feedback": None,
            "status": "active"
        }
        
        # Add initial message if provided
        if initial_message:
            chat_session["conversation"].append({
                "role": "user",
                "message": initial_message,
                "timestamp": datetime.now().isoformat()
            })
        
        # Add chat to user's history
        history[user_id]["chats"].insert(0, chat_session)  # Add to beginning
        history[user_id]["total_chats"] += 1
        
        # Keep only last N chats
        if len(history[user_id]["chats"]) > self.max_chats_per_user:
            history[user_id]["chats"] = history[user_id]["chats"][:self.max_chats_per_user]
        
        # Save updated history
        self.save_chat_history(history)
        
        return chat_session
    
    def add_message_to_chat(self, user_id: str, chat_id: str, role: str, 
                           message: str) -> bool:
        """
        Add a message to an existing chat.
        
        Args:
            user_id: User ID
            chat_id: Chat ID
            role: Message role (user/assistant)
            message: Message content
            
        Returns:
            True if message added successfully, False otherwise
        """
        history = self.load_chat_history()
        
        if user_id not in history:
            return False
        
        # Find the chat session
        chat_session = None
        for chat in history[user_id]["chats"]:
            if chat["chat_id"] == chat_id:
                chat_session = chat
                break
        
        if not chat_session:
            return False
        
        # Add message to conversation
        chat_session["conversation"].append({
            "role": role,
            "message": message,
            "timestamp": datetime.now().isoformat()
        })
        
        # Save updated history
        self.save_chat_history(history)
        
        return True
    
    def update_chat_metadata(self, user_id: str, chat_id: str, **kwargs) -> bool:
        """
        Update chat session metadata.
        
        Args:
            user_id: User ID
            chat_id: Chat ID
            **kwargs: Metadata fields to update
            
        Returns:
            True if updated successfully, False otherwise
        """
        history = self.load_chat_history()
        
        if user_id not in history:
            return False
        
        # Find the chat session
        chat_session = None
        for chat in history[user_id]["chats"]:
            if chat["chat_id"] == chat_id:
                chat_session = chat
                break
        
        if not chat_session:
            return False
        
        # Update metadata fields
        for key, value in kwargs.items():
            chat_session[key] = value
        
        # Save updated history
        self.save_chat_history(history)
        
        return True
    
    def end_chat_session(self, user_id: str, chat_id: str) -> bool:
        """
        End a chat session and calculate duration.
        
        Args:
            user_id: User ID
            chat_id: Chat ID
            
        Returns:
            True if ended successfully, False otherwise
        """
        history = self.load_chat_history()
        
        if user_id not in history:
            return False
        
        # Find the chat session
        chat_session = None
        for chat in history[user_id]["chats"]:
            if chat["chat_id"] == chat_id:
                chat_session = chat
                break
        
        if not chat_session:
            return False
        
        # Calculate duration
        start_time = datetime.fromisoformat(chat_session["timestamp"])
        end_time = datetime.now()
        duration = (end_time - start_time).total_seconds() / 60
        
        # Update chat session
        chat_session["duration_minutes"] = round(duration, 2)
        chat_session["status"] = "completed"
        chat_session["ended_at"] = end_time.isoformat()
        
        # Save updated history
        self.save_chat_history(history)
        
        return True
    
    def get_user_chat_history(self, user_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get chat history for a user.
        
        Args:
            user_id: User ID
            limit: Maximum number of chats to return
            
        Returns:
            List of chat sessions
        """
        history = self.load_chat_history()
        
        if user_id not in history:
            return []
        
        # Return limited number of recent chats
        return history[user_id]["chats"][:limit]
    
    def get_chat_session(self, user_id: str, chat_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a specific chat session.
        
        Args:
            user_id: User ID
            chat_id: Chat ID
            
        Returns:
            Chat session data or None if not found
        """
        history = self.load_chat_history()
        
        if user_id not in history:
            return None
        
        # Find the chat session
        for chat in history[user_id]["chats"]:
            if chat["chat_id"] == chat_id:
                return chat
        
        return None
    
    def add_follow_up_questions(self, user_id: str, chat_id: str, 
                               questions: List[str]) -> bool:
        """
        Add follow-up questions to a chat session.
        
        Args:
            user_id: User ID
            chat_id: Chat ID
            questions: List of follow-up questions
            
        Returns:
            True if added successfully, False otherwise
        """
        return self.update_chat_metadata(user_id, chat_id, follow_up_questions=questions)
    
    def add_customer_feedback(self, user_id: str, chat_id: str, rating: int, 
                            comments: str = None) -> bool:
        """
        Add customer feedback to a chat session.
        
        Args:
            user_id: User ID
            chat_id: Chat ID
            rating: Rating (1-5)
            comments: Optional comments
            
        Returns:
            True if added successfully, False otherwise
        """
        feedback = {
            "rating": rating,
            "comments": comments,
            "timestamp": datetime.now().isoformat()
        }
        
        return self.update_chat_metadata(user_id, chat_id, customer_feedback=feedback)
    
    def get_chat_summary(self, user_id: str) -> Dict[str, Any]:
        """
        Get a summary of user's chat history.
        
        Args:
            user_id: User ID
            
        Returns:
            Dictionary with chat summary
        """
        history = self.load_chat_history()
        
        if user_id not in history:
            return {
                "user_id": user_id,
                "total_chats": 0,
                "recent_topics": [],
                "recent_intents": [],
                "average_rating": 0,
                "last_chat_date": None
            }
        
        user_data = history[user_id]
        chats = user_data["chats"]
        
        # Analyze recent chats
        recent_topics = []
        recent_intents = []
        ratings = []
        
        for chat in chats[:5]:  # Last 5 chats
            recent_topics.extend(chat.get("topics", []))
            recent_intents.extend(chat.get("intents", []))
            
            if chat.get("customer_feedback"):
                ratings.append(chat["customer_feedback"]["rating"])
        
        # Calculate averages and unique values
        unique_topics = list(set(recent_topics))
        unique_intents = list(set(recent_intents))
        average_rating = sum(ratings) / len(ratings) if ratings else 0
        
        last_chat_date = chats[0]["timestamp"] if chats else None
        
        return {
            "user_id": user_id,
            "total_chats": user_data["total_chats"],
            "recent_topics": unique_topics,
            "recent_intents": unique_intents,
            "average_rating": round(average_rating, 2),
            "last_chat_date": last_chat_date
        }
    
    def get_history_stats(self) -> Dict[str, Any]:
        """
        Get overall chat history statistics.
        
        Returns:
            Dictionary with history statistics
        """
        history = self.load_chat_history()
        
        total_users = len(history)
        total_chats = sum(user_data["total_chats"] for user_data in history.values())
        
        # Calculate average chats per user
        avg_chats_per_user = total_chats / total_users if total_users > 0 else 0
        
        # Get most active users
        active_users = sorted(history.items(), 
                            key=lambda x: x[1]["total_chats"], 
                            reverse=True)[:5]
        
        return {
            "total_users": total_users,
            "total_chats": total_chats,
            "average_chats_per_user": round(avg_chats_per_user, 2),
            "most_active_users": [
                {"user_id": user_id, "total_chats": data["total_chats"]} 
                for user_id, data in active_users
            ]
        }

def test_chat_history_manager():
    """Test the chat history manager functionality."""
    print("🧪 Testing Chat History Manager...")
    
    # Initialize chat history manager
    chat_mgr = ChatHistoryManager("shared/fixtures/test_chat_history.json")
    
    # Test starting a new chat
    user_id = "u_1001"
    chat_id = "chat_test_001"
    session_id = "sess_test_001"
    
    chat_session = chat_mgr.start_new_chat(user_id, chat_id, session_id, "Hello, I need help")
    print(f"✅ New chat started: {'PASSED' if chat_session else 'FAILED'}")
    
    # Test adding messages
    added = chat_mgr.add_message_to_chat(user_id, chat_id, "assistant", "How can I help you?")
    print(f"✅ Message added: {'PASSED' if added else 'FAILED'}")
    
    # Test updating metadata
    updated = chat_mgr.update_chat_metadata(user_id, chat_id, 
                                          topics=["order_status"], 
                                          intents=["order_inquiry"],
                                          auth_required=True,
                                          auth_successful=True)
    print(f"✅ Metadata updated: {'PASSED' if updated else 'FAILED'}")
    
    # Test adding follow-up questions
    questions = ["Did this help resolve your issue?", "How would you rate our service?"]
    added_questions = chat_mgr.add_follow_up_questions(user_id, chat_id, questions)
    print(f"✅ Follow-up questions added: {'PASSED' if added_questions else 'FAILED'}")
    
    # Test adding customer feedback
    feedback_added = chat_mgr.add_customer_feedback(user_id, chat_id, 5, "Very helpful!")
    print(f"✅ Customer feedback added: {'PASSED' if feedback_added else 'FAILED'}")
    
    # Test ending chat session
    ended = chat_mgr.end_chat_session(user_id, chat_id)
    print(f"✅ Chat session ended: {'PASSED' if ended else 'FAILED'}")
    
    # Test retrieving chat history
    user_history = chat_mgr.get_user_chat_history(user_id)
    print(f"✅ User chat history retrieved: {len(user_history)} chats")
    
    # Test chat summary
    summary = chat_mgr.get_chat_summary(user_id)
    print(f"✅ Chat summary: {summary}")
    
    # Test history stats
    stats = chat_mgr.get_history_stats()
    print(f"✅ History stats: {stats}")
    
    print("🎉 Chat history manager tests completed!")

if __name__ == "__main__":
    test_chat_history_manager()
