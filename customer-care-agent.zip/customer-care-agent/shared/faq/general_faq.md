# General FAQ

## Order Information
- **Refund timing**: 5–7 business days for processing, 10-14 days to appear in account
- **Tracking updates**: Every 24 hours with most carriers
- **Order modifications**: Can be modified within 2 hours of placement
- **International shipping**: 7-21 business days depending on destination

## Account & Authentication
- **Password reset**: Available through account settings or email link
- **Two-factor authentication**: Recommended for account security
- **Account verification**: Required for orders over $100
- **Guest checkout**: Available for orders under $50

## Product Information
- **Warranty**: 1 year manufacturer warranty on all products
- **Compatibility**: Check product specifications before purchase
- **Installation support**: Free installation guides available
- **Technical support**: Available via chat, email, or phone

## Payment & Billing
- **Accepted payment methods**: Credit cards, PayPal, Apple Pay, Google Pay
- **Payment security**: All transactions encrypted with SSL
- **Billing questions**: Contact billing@company.com
- **Invoice requests**: Available in account dashboard

## Shipping & Delivery
- **Free shipping**: Orders over $50 (domestic only)
- **Express shipping**: Available for urgent orders
- **Delivery tracking**: Real-time updates via email and SMS
- **Signature required**: Orders over $200 require signature

## Returns & Exchanges
- **Return window**: 30 days from delivery date
- **Return shipping**: Free return labels provided
- **Exchange process**: Same as returns, new item shipped upon receipt
- **Damaged items**: Immediate replacement or full refund

## Technical Support
- **Live chat**: Available 24/7 for urgent issues
- **Email support**: Response within 24 hours
- **Phone support**: Monday-Friday 8AM-8PM EST
- **Community forum**: Peer-to-peer support available

## Company Policies
- **Privacy policy**: Available on company website
- **Terms of service**: Updated annually
- **Data protection**: GDPR compliant
- **Accessibility**: WCAG 2.1 AA compliant
