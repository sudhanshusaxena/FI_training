---
title: Refunds Policy
version: 2024-07-01
owner: Ops
tags: [refunds, policy]
policy_rules:
  - clause_id: RF-2.3
    condition: "order_status == delivered AND within_days(30) AND reason in ['damaged','not_as_described']"
    action: "refund <= 100% to original payment method"
    requires: ["proof_of_purchase"]
  - clause_id: RF-1.2
    condition: "order_status == shipped AND carrier_delay == true"
    action: "offer voucher <= 15% OR partial refund <= 20%"
    requires: []
escalation_contacts: ["team-lead@company"]
effective_date: 2024-07-01
---
# Refunds Policy

## Overview
This policy governs all refund requests and compensation offers for customer orders. All refunds must comply with these rules and require appropriate documentation.

## Eligibility Rules

### RF-2.3: Full Refund for Damaged/Incorrect Items
**Conditions:**
- Order status: Delivered
- Time window: Within 30 days of delivery
- Reason: Damaged item or not as described
- Documentation: Proof of purchase required

**Action:** Full refund (up to 100%) to original payment method

**Process:**
1. Verify order status and delivery date
2. Confirm damage/incorrect item with customer
3. Request proof of purchase (receipt, email confirmation)
4. Process refund through original payment method
5. Issue ticket ID for tracking

### RF-1.2: Compensation for Shipping Delays
**Conditions:**
- Order status: Shipped but delayed
- Cause: Carrier delay (not customer error)

**Actions (choose one):**
- Voucher: Up to 15% discount for next purchase
- Partial refund: Up to 20% of order value

**Process:**
1. Verify shipping status and delay cause
2. Offer customer choice of compensation
3. Apply chosen compensation method
4. Document resolution in customer account

## General Refund Guidelines

### Processing Time
- Refunds processed within 5-7 business days
- Credit appears in customer account within 10-14 business days
- International refunds may take up to 21 business days

### Documentation Requirements
- Proof of purchase (receipt, email, order number)
- Photo evidence for damaged items (when applicable)
- Customer explanation of issue

### Exclusions
- Items returned after 30 days (unless defective)
- Items damaged by customer misuse
- Custom or personalized items (unless defective)
- Digital products (unless defective)

## Escalation Procedures
For complex cases or amounts over $500, escalate to team-lead@company for review.

## Policy Updates
This policy is effective as of 2024-07-01. Any updates will be communicated to all customer service representatives.
