# Memory Manager - Customer Care Agent
"""
Shared memory management system for session and global memory persistence.
Handles memory storage, retrieval, sanitization, and lifecycle management.
"""

import json
import os
import hashlib
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from pathlib import Path

@dataclass
class MemoryEntry:
    """Individual memory entry structure."""
    id: str
    scope: str  # 'session' or 'global'
    content: str
    summary: str
    timestamp: str
    user_id: Optional[str]
    session_id: Optional[str]
    memory_type: str  # 'conversation', 'preference', 'insight', 'action'
    metadata: Dict[str, Any]
    hash: str

@dataclass
class MemoryQuery:
    """Query structure for memory retrieval."""
    scope: Optional[str] = None
    memory_type: Optional[str] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    time_range: Optional[tuple] = None
    limit: int = 50

class MemoryManager:
    """
    Manages persistent memory storage for customer care conversations.
    Handles both session-specific (ephemeral) and global (durable) memory.
    """
    
    def __init__(self, base_path: str = "memory"):
        self.base_path = Path(base_path)
        self.session_path = self.base_path / "session"
        self.global_path = self.base_path / "global"
        
        # Create directories if they don't exist
        self.session_path.mkdir(parents=True, exist_ok=True)
        self.global_path.mkdir(parents=True, exist_ok=True)
        
        self.logger = logging.getLogger(__name__)
        
        # Memory configuration
        self.max_session_memory = 100  # entries per session
        self.max_global_memory = 1000  # total global entries
        self.session_retention_days = 30
        self.global_retention_days = 365
        
    def _generate_memory_id(self, content: str, scope: str) -> str:
        """Generate unique memory ID based on content and scope."""
        timestamp = datetime.now().isoformat()
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:8]
        return f"{scope}_{timestamp}_{content_hash}"
    
    def _sanitize_content(self, content: str) -> str:
        """
        Sanitize memory content by removing PII and sensitive information.
        """
        # Basic PII removal patterns
        import re
        
        # Email addresses
        content = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', 
                        '***@***.***', content)
        
        # Phone numbers
        content = re.sub(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b', 
                        '***-***-****', content)
        
        # Credit card numbers (basic pattern)
        content = re.sub(r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b', 
                        '****-****-****-****', content)
        
        # SSN (basic pattern)
        content = re.sub(r'\b\d{3}-\d{2}-\d{4}\b', 
                        '***-**-****', content)
        
        return content
    
    def _create_memory_entry(self, 
                           content: str, 
                           scope: str, 
                           memory_type: str,
                           user_id: Optional[str] = None,
                           session_id: Optional[str] = None,
                           metadata: Optional[Dict] = None) -> MemoryEntry:
        """Create a new memory entry with sanitization."""
        
        sanitized_content = self._sanitize_content(content)
        summary = self._generate_summary(sanitized_content)
        
        entry = MemoryEntry(
            id=self._generate_memory_id(sanitized_content, scope),
            scope=scope,
            content=sanitized_content,
            summary=summary,
            timestamp=datetime.now().isoformat(),
            user_id=user_id,
            session_id=session_id,
            memory_type=memory_type,
            metadata=metadata or {},
            hash=hashlib.sha256(sanitized_content.encode()).hexdigest()
        )
        
        return entry
    
    def _generate_summary(self, content: str) -> str:
        """Generate a concise summary of memory content."""
        # Simple summarization - in production, use more sophisticated NLP
        words = content.split()
        if len(words) <= 20:
            return content
        
        # Take first 15 words + "..."
        summary_words = words[:15]
        return " ".join(summary_words) + "..."
    
    def store_memory(self, 
                    content: str, 
                    scope: str, 
                    memory_type: str,
                    user_id: Optional[str] = None,
                    session_id: Optional[str] = None,
                    metadata: Optional[Dict] = None) -> str:
        """
        Store memory entry in appropriate scope.
        
        Args:
            content: Memory content to store
            scope: 'session' or 'global'
            memory_type: Type of memory ('conversation', 'preference', etc.)
            user_id: User identifier
            session_id: Session identifier
            metadata: Additional metadata
            
        Returns:
            Memory entry ID
        """
        try:
            entry = self._create_memory_entry(
                content, scope, memory_type, user_id, session_id, metadata
            )
            
            # Store in appropriate directory
            if scope == "session":
                self._store_session_memory(entry)
            elif scope == "global":
                self._store_global_memory(entry)
            else:
                raise ValueError(f"Invalid scope: {scope}")
            
            self.logger.info(f"Stored {scope} memory: {entry.id}")
            return entry.id
            
        except Exception as e:
            self.logger.error(f"Failed to store memory: {e}")
            raise
    
    def _store_session_memory(self, entry: MemoryEntry):
        """Store session memory with cleanup."""
        session_file = self.session_path / f"{entry.session_id}.jsonl"
        
        # Load existing memories
        memories = []
        if session_file.exists():
            with open(session_file, 'r') as f:
                for line in f:
                    if line.strip():
                        memories.append(json.loads(line))
        
        # Add new memory
        memories.append(asdict(entry))
        
        # Cleanup old memories if needed
        if len(memories) > self.max_session_memory:
            memories = memories[-self.max_session_memory:]
        
        # Write back to file
        with open(session_file, 'w') as f:
            for memory in memories:
                f.write(json.dumps(memory) + '\n')
    
    def _store_global_memory(self, entry: MemoryEntry):
        """Store global memory with cleanup."""
        global_file = self.global_path / "global_memory.jsonl"
        
        # Load existing memories
        memories = []
        if global_file.exists():
            with open(global_file, 'r') as f:
                for line in f:
                    if line.strip():
                        memories.append(json.loads(line))
        
        # Add new memory
        memories.append(asdict(entry))
        
        # Cleanup old memories if needed
        if len(memories) > self.max_global_memory:
            memories = memories[-self.max_global_memory:]
        
        # Write back to file
        with open(global_file, 'w') as f:
            for memory in memories:
                f.write(json.dumps(memory) + '\n')
    
    def retrieve_memories(self, query: MemoryQuery) -> List[MemoryEntry]:
        """
        Retrieve memories based on query criteria.
        
        Args:
            query: MemoryQuery with search criteria
            
        Returns:
            List of matching MemoryEntry objects
        """
        try:
            memories = []
            
            # Search session memories
            if query.scope in [None, "session"]:
                session_memories = self._search_session_memories(query)
                memories.extend(session_memories)
            
            # Search global memories
            if query.scope in [None, "global"]:
                global_memories = self._search_global_memories(query)
                memories.extend(global_memories)
            
            # Sort by timestamp (newest first)
            memories.sort(key=lambda x: x.timestamp, reverse=True)
            
            # Apply limit
            return memories[:query.limit]
            
        except Exception as e:
            self.logger.error(f"Failed to retrieve memories: {e}")
            return []
    
    def _search_session_memories(self, query: MemoryQuery) -> List[MemoryEntry]:
        """Search session memories."""
        memories = []
        
        if query.session_id:
            # Search specific session
            session_file = self.session_path / f"{query.session_id}.jsonl"
            if session_file.exists():
                memories.extend(self._load_memories_from_file(session_file, query))
        else:
            # Search all session files
            for session_file in self.session_path.glob("*.jsonl"):
                memories.extend(self._load_memories_from_file(session_file, query))
        
        return memories
    
    def _search_global_memories(self, query: MemoryQuery) -> List[MemoryEntry]:
        """Search global memories."""
        memories = []
        global_file = self.global_path / "global_memory.jsonl"
        
        if global_file.exists():
            memories.extend(self._load_memories_from_file(global_file, query))
        
        return memories
    
    def _load_memories_from_file(self, file_path: Path, query: MemoryQuery) -> List[MemoryEntry]:
        """Load and filter memories from a file."""
        memories = []
        
        try:
            with open(file_path, 'r') as f:
                for line in f:
                    if line.strip():
                        data = json.loads(line)
                        entry = MemoryEntry(**data)
                        
                        # Apply filters
                        if self._matches_query(entry, query):
                            memories.append(entry)
        except Exception as e:
            self.logger.error(f"Failed to load memories from {file_path}: {e}")
        
        return memories
    
    def _matches_query(self, entry: MemoryEntry, query: MemoryQuery) -> bool:
        """Check if memory entry matches query criteria."""
        
        # Scope filter
        if query.scope and entry.scope != query.scope:
            return False
        
        # Memory type filter
        if query.memory_type and entry.memory_type != query.memory_type:
            return False
        
        # User ID filter
        if query.user_id and entry.user_id != query.user_id:
            return False
        
        # Session ID filter
        if query.session_id and entry.session_id != query.session_id:
            return False
        
        # Time range filter
        if query.time_range:
            entry_time = datetime.fromisoformat(entry.timestamp)
            start_time, end_time = query.time_range
            if entry_time < start_time or entry_time > end_time:
                return False
        
        return True
    
    def cleanup_expired_memories(self):
        """Remove expired memories based on retention policies."""
        try:
            current_time = datetime.now()
            
            # Cleanup session memories
            session_cutoff = current_time - timedelta(days=self.session_retention_days)
            self._cleanup_session_memories(session_cutoff)
            
            # Cleanup global memories
            global_cutoff = current_time - timedelta(days=self.global_retention_days)
            self._cleanup_global_memories(global_cutoff)
            
            self.logger.info("Memory cleanup completed")
            
        except Exception as e:
            self.logger.error(f"Memory cleanup failed: {e}")
    
    def _cleanup_session_memories(self, cutoff_date: datetime):
        """Cleanup expired session memories."""
        for session_file in self.session_path.glob("*.jsonl"):
            try:
                # Load memories
                memories = []
                with open(session_file, 'r') as f:
                    for line in f:
                        if line.strip():
                            memories.append(json.loads(line))
                
                # Filter out expired memories
                valid_memories = []
                for memory in memories:
                    memory_time = datetime.fromisoformat(memory['timestamp'])
                    if memory_time >= cutoff_date:
                        valid_memories.append(memory)
                
                # Write back valid memories
                with open(session_file, 'w') as f:
                    for memory in valid_memories:
                        f.write(json.dumps(memory) + '\n')
                        
            except Exception as e:
                self.logger.error(f"Failed to cleanup session file {session_file}: {e}")
    
    def _cleanup_global_memories(self, cutoff_date: datetime):
        """Cleanup expired global memories."""
        global_file = self.global_path / "global_memory.jsonl"
        
        if not global_file.exists():
            return
        
        try:
            # Load memories
            memories = []
            with open(global_file, 'r') as f:
                for line in f:
                    if line.strip():
                        memories.append(json.loads(line))
            
            # Filter out expired memories
            valid_memories = []
            for memory in memories:
                memory_time = datetime.fromisoformat(memory['timestamp'])
                if memory_time >= cutoff_date:
                    valid_memories.append(memory)
            
            # Write back valid memories
            with open(global_file, 'w') as f:
                for memory in valid_memories:
                    f.write(json.dumps(memory) + '\n')
                    
        except Exception as e:
            self.logger.error(f"Failed to cleanup global memories: {e}")
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """Get memory usage statistics."""
        try:
            stats = {
                "session_memories": 0,
                "global_memories": 0,
                "total_sessions": 0,
                "oldest_session": None,
                "newest_session": None
            }
            
            # Count session memories
            session_times = []
            for session_file in self.session_path.glob("*.jsonl"):
                with open(session_file, 'r') as f:
                    count = sum(1 for line in f if line.strip())
                    stats["session_memories"] += count
                    stats["total_sessions"] += 1
                    
                    # Get file modification time
                    mtime = datetime.fromtimestamp(session_file.stat().st_mtime)
                    session_times.append(mtime)
            
            if session_times:
                stats["oldest_session"] = min(session_times).isoformat()
                stats["newest_session"] = max(session_times).isoformat()
            
            # Count global memories
            global_file = self.global_path / "global_memory.jsonl"
            if global_file.exists():
                with open(global_file, 'r') as f:
                    stats["global_memories"] = sum(1 for line in f if line.strip())
            
            return stats
            
        except Exception as e:
            self.logger.error(f"Failed to get memory stats: {e}")
            return {}

# Example usage and testing
if __name__ == "__main__":
    # Initialize memory manager
    memory_manager = MemoryManager()
    
    # Store some test memories
    memory_id1 = memory_manager.store_memory(
        content="Customer prefers email communication and has Smart Widget Pro",
        scope="global",
        memory_type="preference",
        user_id="u_1001",
        metadata={"product": "Smart Widget Pro", "communication": "email"}
    )
    
    memory_id2 = memory_manager.store_memory(
        content="Current conversation about refund request for damaged item",
        scope="session",
        memory_type="conversation",
        user_id="u_1001",
        session_id="session_001",
        metadata={"intent": "refunds", "status": "active"}
    )
    
    # Retrieve memories
    query = MemoryQuery(user_id="u_1001", limit=10)
    memories = memory_manager.retrieve_memories(query)
    
    print(f"Found {len(memories)} memories for user u_1001")
    for memory in memories:
        print(f"- {memory.memory_type}: {memory.summary}")
    
    # Get memory stats
    stats = memory_manager.get_memory_stats()
    print(f"\nMemory stats: {stats}")
