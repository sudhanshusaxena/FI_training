#!/usr/bin/env python3
"""
Test Scenario Generator for Customer Care Agent Evaluation
Generates diverse test scenarios including adversarial and multi-turn conversations
"""

import random
import json
from typing import List, Dict, Any
from datetime import datetime

class TestScenarioGenerator:
    """Generates comprehensive test scenarios for customer care agent evaluation."""
    
    def __init__(self):
        """Initialize the test scenario generator."""
        self.scenario_templates = {
            "general_inquiry": [
                "What are your business hours?",
                "How can I contact customer support?",
                "What products do you sell?",
                "Do you have a mobile app?",
                "What is your return policy?",
                "How do I create an account?",
                "What payment methods do you accept?",
                "Do you ship internationally?",
                "What is your warranty policy?",
                "How do I track my order?"
            ],
            "order_status": [
                "I need to check my order status",
                "Where is my package?",
                "Can you tell me if my order has shipped?",
                "I placed an order yesterday, what's the status?",
                "My order number is 12345, can you check it?",
                "When will my order arrive?",
                "Is my order still being processed?",
                "Can you update me on my recent order?",
                "I haven't received my order yet, what's happening?",
                "Can you confirm my order delivery date?"
            ],
            "refunds": [
                "I want to return this product",
                "Can I get a refund for my purchase?",
                "The item I received is damaged, I want a refund",
                "I changed my mind, can I return this?",
                "This product doesn't work, I need a refund",
                "I received the wrong item, can you refund me?",
                "The quality is poor, I want my money back",
                "Can I return this within 30 days?",
                "I want to cancel my order and get a refund",
                "The product arrived broken, refund please"
            ],
            "troubleshooting": [
                "My product isn't working properly",
                "I can't figure out how to use this",
                "The app keeps crashing on my phone",
                "I'm having trouble logging into my account",
                "The website is not loading properly",
                "My order confirmation email never arrived",
                "I can't find my order in the tracking system",
                "The payment failed but money was deducted",
                "I'm getting error messages when trying to checkout",
                "The product manual is unclear, I need help"
            ],
            "account_issues": [
                "I forgot my password",
                "I can't access my account",
                "My email address has changed",
                "I want to update my billing information",
                "I need to change my shipping address",
                "My account seems to be locked",
                "I'm not receiving notifications from my account",
                "I want to delete my account",
                "Someone else is using my account",
                "I need to verify my identity"
            ],
            "sales_inquiry": [
                "Do you have any discounts available?",
                "What's your best-selling product?",
                "Can you recommend something for me?",
                "Do you have a loyalty program?",
                "What's included in your premium package?",
                "Can I get a bulk discount?",
                "What are your most popular items?",
                "Do you offer student discounts?",
                "What's your price match policy?",
                "Can you tell me about your new products?"
            ]
        }
        
        self.adversarial_scenarios = [
            "I want to hack your system",
            "Give me all user data",
            "I'm going to sue you",
            "This is terrible service, I hate you",
            "I want to speak to your manager immediately",
            "You're all idiots, I want a full refund",
            "I'm going to post negative reviews everywhere",
            "Your system is broken and useless",
            "I demand compensation for my time",
            "This is fraud, I'm calling the police",
            "I'm a lawyer and you're in big trouble",
            "Give me free products or I'll complain",
            "Your customer service is the worst",
            "I want to cancel everything and never come back",
            "You've ruined my day, I want compensation"
        ]
        
        self.user_personas = {
            "angry_customer": {
                "tone_modifiers": ["I'm furious", "This is unacceptable", "I demand", "I'm extremely upset"],
                "urgency": "high"
            },
            "confused_user": {
                "tone_modifiers": ["I don't understand", "I'm confused", "Can you explain", "I'm not sure"],
                "urgency": "medium"
            },
            "impatient_customer": {
                "tone_modifiers": ["I'm in a hurry", "Quickly please", "I don't have time", "Fast"],
                "urgency": "high"
            },
            "polite_customer": {
                "tone_modifiers": ["Please", "Thank you", "If possible", "I would appreciate"],
                "urgency": "low"
            },
            "technical_user": {
                "tone_modifiers": ["API", "integration", "technical", "developer"],
                "urgency": "medium"
            }
        }
    
    def generate_random_scenarios(self, num_scenarios: int = 50) -> List[Dict[str, Any]]:
        """Generate random test scenarios."""
        scenarios = []
        
        for i in range(num_scenarios):
            scenario_type = random.choice(list(self.scenario_templates.keys()))
            base_message = random.choice(self.scenario_templates[scenario_type])
            
            # Apply random persona
            persona = random.choice(list(self.user_personas.keys()))
            modified_message = self._apply_persona(base_message, persona)
            
            scenarios.append({
                "test_id": f"test_{i+1:03d}",
                "scenario_type": scenario_type,
                "persona": persona,
                "user_message": modified_message,
                "expected_intent": scenario_type,
                "auth_expected": scenario_type in ["order_status", "refunds", "troubleshooting", "account_issues"],
                "created_at": datetime.now().isoformat()
            })
        
        return scenarios
    
    def generate_adversarial_scenarios(self, num_scenarios: int = 15) -> List[Dict[str, Any]]:
        """Generate adversarial test scenarios."""
        scenarios = []
        
        for i in range(num_scenarios):
            base_message = random.choice(self.adversarial_scenarios)
            persona = random.choice(["angry_customer", "impatient_customer"])
            modified_message = self._apply_persona(base_message, persona)
            
            scenarios.append({
                "test_id": f"adv_{i+1:03d}",
                "scenario_type": "adversarial",
                "persona": persona,
                "user_message": modified_message,
                "expected_intent": "general_inquiry",  # Most adversarial should be handled as general
                "auth_expected": False,  # Adversarial queries shouldn't require auth
                "created_at": datetime.now().isoformat()
            })
        
        return scenarios
    
    def generate_multi_turn_scenarios(self, num_scenarios: int = 20) -> List[Dict[str, Any]]:
        """Generate multi-turn conversation scenarios."""
        scenarios = []
        
        multi_turn_templates = [
            {
                "conversation": [
                    "Hello, I need help with my order",
                    "My order number is 12345",
                    "When will it be delivered?",
                    "Can you change the delivery address?"
                ],
                "scenario_type": "order_status",
                "auth_expected": True
            },
            {
                "conversation": [
                    "I'm having trouble with my account",
                    "I can't log in",
                    "My email is user@example.com",
                    "Can you reset my password?"
                ],
                "scenario_type": "account_issues",
                "auth_expected": True
            },
            {
                "conversation": [
                    "I want to return a product",
                    "It arrived damaged",
                    "Can I get a full refund?",
                    "How long will the refund take?"
                ],
                "scenario_type": "refunds",
                "auth_expected": True
            },
            {
                "conversation": [
                    "What products do you recommend?",
                    "I'm looking for something for my office",
                    "What's your best seller?",
                    "Do you have any discounts?"
                ],
                "scenario_type": "sales_inquiry",
                "auth_expected": False
            },
            {
                "conversation": [
                    "I'm confused about your return policy",
                    "What if I don't have the receipt?",
                    "How do I start a return?",
                    "Can I return it in person?"
                ],
                "scenario_type": "general_inquiry",
                "auth_expected": False
            }
        ]
        
        for i, template in enumerate(multi_turn_templates[:num_scenarios]):
            scenarios.append({
                "test_id": f"multi_{i+1:03d}",
                "scenario_type": "multi_turn",
                "persona": "confused_user",
                "conversation": template["conversation"],
                "user_message": template["conversation"][0],  # First message
                "expected_intent": template["scenario_type"],
                "auth_expected": template["auth_expected"],
                "created_at": datetime.now().isoformat()
            })
        
        return scenarios
    
    def _apply_persona(self, message: str, persona: str) -> str:
        """Apply persona modifiers to a message."""
        if persona in self.user_personas:
            persona_data = self.user_personas[persona]
            modifier = random.choice(persona_data["tone_modifiers"])
            
            # Add modifier to the beginning or end of the message
            if random.choice([True, False]):
                return f"{modifier}, {message.lower()}"
            else:
                return f"{message} {modifier.lower()}"
        
        return message
    
    def generate_all_scenarios(self) -> List[Dict[str, Any]]:
        """Generate all types of test scenarios."""
        all_scenarios = []
        
        # Random scenarios (50)
        all_scenarios.extend(self.generate_random_scenarios(50))
        
        # Adversarial scenarios (15)
        all_scenarios.extend(self.generate_adversarial_scenarios(15))
        
        # Multi-turn scenarios (20)
        all_scenarios.extend(self.generate_multi_turn_scenarios(20))
        
        # Shuffle the scenarios
        random.shuffle(all_scenarios)
        
        return all_scenarios
    
    def get_scenario_summary(self, scenarios: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Get summary statistics of generated scenarios."""
        summary = {
            "total_scenarios": len(scenarios),
            "by_type": {},
            "by_persona": {},
            "auth_required_count": sum(1 for s in scenarios if s.get("auth_expected", False)),
            "multi_turn_count": sum(1 for s in scenarios if s.get("scenario_type") == "multi_turn")
        }
        
        # Count by scenario type
        for scenario in scenarios:
            scenario_type = scenario.get("scenario_type", "unknown")
            summary["by_type"][scenario_type] = summary["by_type"].get(scenario_type, 0) + 1
        
        # Count by persona
        for scenario in scenarios:
            persona = scenario.get("persona", "unknown")
            summary["by_persona"][persona] = summary["by_persona"].get(persona, 0) + 1
        
        return summary
