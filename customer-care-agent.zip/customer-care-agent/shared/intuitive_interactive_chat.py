#!/usr/bin/env python3
"""
Intuitive Interactive Chat - User-Friendly TriageAgent System
Fixes all the confusion issues and makes the chat truly intuitive
"""

import sys
import os
import json
import time
import random
from datetime import datetime
from typing import Dict, List, Any, Optional

class IntuitiveInteractiveChat:
    """Intuitive interactive chat that asks for queries first, not user IDs."""
    
    def __init__(self, system_orchestrator):
        """Initialize the intuitive interactive chat."""
        self.system = system_orchestrator
        self.chat_session = {
            'start_time': None,
            'end_time': None,
            'user_id': None,
            'messages': [],
            'agent_decisions': [],
            'authentication_attempts': 0,
            'human_handovers': 0,
            'intents_classified': [],
            'context_memory': {},  # NEW: Remember what user said
            'current_auth_step': None,
            'auth_session_active': False,
            'authenticated_user': None
        }
    
    def load_random_demo_users(self) -> List[Dict[str, Any]]:
        """Load random demo users for testing (not hardcoded)."""
        try:
            with open('shared/fixtures/password_reference.json', 'r') as f:
                all_users = json.load(f)
            
            # Get random sample of users (not hardcoded numbers)
            user_list = list(all_users.items())
            random.shuffle(user_list)  # Randomize the order
            
            # Take first 8-12 users (random amount)
            sample_size = random.randint(8, 12)
            demo_users = user_list[:sample_size]
            
            formatted_users = []
            for i, (user_id, creds) in enumerate(demo_users, 1):
                formatted_users.append({
                    'number': i,
                    'user_id': user_id,
                    'username': creds.get('username', 'N/A'),
                    'email': creds.get('email', 'N/A'),
                    'password': creds.get('plain_password', 'N/A'),
                    'full_name': creds.get('full_name', 'N/A')
                })
            
            return formatted_users
            
        except Exception as e:
            print(f"❌ Error loading demo users: {e}")
            return []
    
    def display_welcome_and_demo_users(self) -> List[Dict[str, Any]]:
        """Display welcome message and random demo users."""
        print("🤖 WELCOME TO THE CUSTOMER CARE AGENT SYSTEM")
        print("="*80)
        print("Hi! I'm your intelligent Customer Care Agent. I can help you with:")
        print("• General questions about our services")
        print("• Order tracking and status updates")
        print("• Refund and return requests")
        print("• Technical troubleshooting")
        print("• Account-related issues")
        print()
        print("💡 Just ask me your question, and I'll help you right away!")
        print("🧠 I'll show you exactly how I think and make decisions!")
        print("="*80)
        
        # Load and display random demo users
        demo_users = self.load_random_demo_users()
        
        if demo_users:
            print("\n🔑 DEMO TESTING CREDENTIALS")
            print("="*60)
            print("For testing purposes, here are some demo user accounts:")
            print("(You can use these if you want to test authentication)")
            print()
            
            for user in demo_users:
                print(f"{user['number']:2d}. 👤 {user['full_name']} ({user['user_id']})")
                print(f"    📧 Email: {user['email']}")
                print(f"    🔐 Password: {user['password']}")
                print(f"    👤 Username: {user['username']}")
                print("-" * 50)
            
            print()
            print("💡 TIP: You don't need to choose a user right now!")
            print("💬 Just ask your question, and I'll tell you if authentication is needed!")
            print("="*60)
        
        return demo_users
    
    def display_help_system(self) -> None:
        """Display comprehensive help system."""
        print("\n📚 HOW TO USE THIS SYSTEM")
        print("="*60)
        print("🎯 SIMPLE WORKFLOW:")
        print("   1. Type your question or request")
        print("   2. Watch me analyze and decide what to do")
        print("   3. I'll either answer directly OR ask for authentication")
        print()
        print("💬 EXAMPLE QUESTIONS YOU CAN ASK:")
        print("   • 'What are your business hours?'")
        print("   • 'How can I track my order?'")
        print("   • 'I want to return a product'")
        print("   • 'My account is not working'")
        print("   • 'Can you help me troubleshoot my login?'")
        print()
        print("🔐 AUTHENTICATION:")
        print("   • If I need to verify your identity, I'll ask step by step")
        print("   • Username → Password → Email verification")
        print("   • Each step will be clear and easy to follow")
        print()
        print("⚡ SPECIAL COMMANDS:")
        print("   • 'help' - Show this help message")
        print("   • 'demo users' - Show demo credentials again")
        print("   • 'summary' - Show chat summary")
        print("   • 'quit' or 'exit' - End the chat")
        print("   • 'remember: [info]' - Tell me something to remember")
        print()
        print("🧠 MY THINKING PROCESS:")
        print("   • I'll show you exactly how I analyze your message")
        print("   • You'll see my intent classification and reasoning")
        print("   • I'll explain why I need authentication (if required)")
        print("   • Every decision will be transparent and clear")
        print("="*60)
    
    def remember_context(self, message: str) -> None:
        """Remember important context from user messages."""
        message_lower = message.lower()
        
        # Extract name if mentioned
        if 'my name is' in message_lower:
            name_start = message_lower.find('my name is') + len('my name is')
            name_part = message_lower[name_start:].strip()
            if name_part:
                # Take first word as name
                name = name_part.split()[0].title()
                self.chat_session['context_memory']['user_name'] = name
                print(f"✅ I'll remember that your name is {name}")
        
        # Extract other important info
        if 'i am' in message_lower:
            info_start = message_lower.find('i am') + len('i am')
            info_part = message_lower[info_start:].strip()
            if info_part:
                self.chat_session['context_memory']['user_info'] = info_part
                print(f"✅ I'll remember: {info_part}")
        
        # Handle explicit remember commands
        if message_lower.startswith('remember:'):
            info = message[9:].strip()  # Remove 'remember:'
            if info:
                self.chat_session['context_memory']['explicit_info'] = info
                print(f"✅ I'll remember: {info}")
    
    def display_triage_agent_thinking(self, user_message: str, result: Dict[str, Any]) -> None:
        """Display clear TriageAgent thinking process."""
        print("\n🧠 TRIAGE AGENT ANALYSIS")
        print("="*70)
        
        # Show what I'm analyzing
        print(f"📝 Your Message: \"{user_message}\"")
        print()
        
        # Intent Classification
        detected_intent = result.get('intent', 'unknown')
        confidence = result.get('confidence', 0.0)
        
        print(f"🎯 INTENT ANALYSIS:")
        print(f"   Detected Intent: {detected_intent.replace('_', ' ').title()}")
        print(f"   Confidence Level: {confidence:.1%}")
        
        # Explain what this intent means
        intent_explanations = {
            'general_inquiry': 'You\'re asking for general information or help',
            'order_status': 'You want to know about your order or tracking',
            'refunds': 'You\'re requesting a refund or return',
            'troubleshooting': 'You\'re experiencing technical issues',
            'account_issues': 'You have problems with your account',
            'sales_inquiry': 'You\'re interested in products or services'
        }
        
        explanation = intent_explanations.get(detected_intent, 'I understand your request')
        print(f"   What this means: {explanation}")
        print()
        
        # Authentication Decision
        auth_required = result.get('auth_required', False)
        
        print(f"🔐 AUTHENTICATION DECISION:")
        if auth_required:
            print(f"   ✅ Authentication Required")
            print(f"   📝 Why: This involves personal/sensitive information")
            print(f"   🔒 Security: I need to verify your identity first")
            print(f"   📋 Next: I'll ask for your credentials step by step")
        else:
            print(f"   ❌ No Authentication Needed")
            print(f"   📝 Why: This is general information I can share safely")
            print(f"   🚀 Next: I'll answer your question directly")
        
        print("="*70)
    
    def handle_authentication_flow(self, user_id: str = None) -> Dict[str, Any]:
        """Handle the step-by-step authentication flow."""
        print("\n🔐 AUTHENTICATION REQUIRED")
        print("="*50)
        print("I need to verify your identity to help with this request.")
        print("I'll ask for your credentials one step at a time.")
        print()
        
        # Get demo users for reference
        demo_users = self.load_random_demo_users()
        
        auth_result = {
            'success': False,
            'authenticated_user': None,
            'steps_completed': 0,
            'error': None
        }
        
        # Step 1: Username
        print("📋 STEP 1: USERNAME VERIFICATION")
        print("-" * 30)
        
        if demo_users:
            print("💡 Demo usernames you can try:")
            for user in demo_users[:5]:  # Show first 5
                print(f"   • {user['username']}")
            print()
        
        while True:
            username = input("👤 Please enter your username: ").strip()
            
            if username.lower() in ['quit', 'exit', 'help']:
                if username.lower() == 'help':
                    print("💡 Enter one of the demo usernames above, or 'quit' to cancel")
                    continue
                else:
                    print("❌ Authentication cancelled")
                    auth_result['error'] = 'User cancelled authentication'
                    return auth_result
            
            if username:
                # Check if username exists in demo users
                matching_user = None
                for user in demo_users:
                    if user['username'].lower() == username.lower():
                        matching_user = user
                        break
                
                if matching_user:
                    print(f"✅ Username verified: {matching_user['full_name']}")
                    auth_result['authenticated_user'] = matching_user
                    auth_result['steps_completed'] += 1
                    break
                else:
                    print(f"❌ Username '{username}' not found")
                    print("💡 Try one of the demo usernames above, or type 'help' for assistance")
            else:
                print("❌ Please enter a username")
        
        # Step 2: Password
        print(f"\n📋 STEP 2: PASSWORD VERIFICATION")
        print("-" * 30)
        print(f"👤 User: {matching_user['full_name']}")
        print(f"💡 Password hint: {matching_user['password']}")
        print()
        
        attempts = 0
        max_attempts = 3
        
        while attempts < max_attempts:
            password = input(f"🔐 Please enter your password (attempt {attempts + 1}/{max_attempts}): ").strip()
            
            if password.lower() in ['quit', 'exit']:
                print("❌ Authentication cancelled")
                auth_result['error'] = 'User cancelled authentication'
                return auth_result
            
            if password == matching_user['password']:
                print("✅ Password verified successfully")
                auth_result['steps_completed'] += 1
                break
            else:
                attempts += 1
                if attempts < max_attempts:
                    print(f"❌ Incorrect password. Try again.")
                    print(f"💡 Hint: {matching_user['password']}")
                else:
                    print("❌ Maximum password attempts reached")
                    auth_result['error'] = 'Password verification failed after 3 attempts'
                    return auth_result
        
        # Step 3: Email Verification
        print(f"\n📋 STEP 3: EMAIL VERIFICATION")
        print("-" * 30)
        print(f"👤 User: {matching_user['full_name']}")
        print(f"📧 Email: {matching_user['email']}")
        print()
        
        email_attempts = 0
        max_email_attempts = 2
        
        while email_attempts < max_email_attempts:
            email = input(f"📧 Please enter your email address (attempt {email_attempts + 1}/{max_email_attempts}): ").strip()
            
            if email.lower() in ['quit', 'exit']:
                print("❌ Authentication cancelled")
                auth_result['error'] = 'User cancelled authentication'
                return auth_result
            
            if email.lower() == matching_user['email'].lower():
                print("✅ Email verified successfully")
                auth_result['steps_completed'] += 1
                auth_result['success'] = True
                break
            else:
                email_attempts += 1
                if email_attempts < max_email_attempts:
                    print(f"❌ Email doesn't match. Try again.")
                    print(f"💡 Expected: {matching_user['email']}")
                else:
                    print("❌ Maximum email attempts reached")
                    auth_result['error'] = 'Email verification failed after 2 attempts'
                    return auth_result
        
        # Success!
        print(f"\n🎉 AUTHENTICATION SUCCESSFUL!")
        print("="*40)
        print(f"✅ Welcome back, {matching_user['full_name']}!")
        print(f"⏰ Your session is valid for 3 minutes")
        print(f"🔒 You can now ask sensitive questions")
        print("="*40)
        
        return auth_result
    
    def display_agent_response(self, result: Dict[str, Any]) -> None:
        """Display the agent's response in a clear, friendly way."""
        print("\n💬 MY RESPONSE")
        print("="*50)
        
        # Show the actual response
        response = result.get('response', 'I apologize, but I couldn\'t generate a proper response.')
        print(f"{response}")
        
        # Show follow-up questions if any
        if result.get('follow_up_questions'):
            print(f"\n❓ FOLLOW-UP QUESTIONS:")
            for i, question in enumerate(result['follow_up_questions'], 1):
                print(f"   {i}. {question}")
        
        # Show human handover info if needed
        if result.get('requires_human_agent', False):
            handover = result.get('human_handover', {})
            print(f"\n📞 HUMAN AGENT HANDOVER:")
            print(f"   📞 Contact: +91 998877654321")
            print(f"   📝 Reason: {handover.get('reason', 'Complex issue requiring human assistance')}")
            print(f"   🆔 Reference ID: {handover.get('reference_id', 'N/A')}")
        
        print("="*50)
    
    def display_chat_summary(self) -> None:
        """Display a friendly chat summary."""
        print("\n📊 CHAT SUMMARY")
        print("="*60)
        
        duration = self.chat_session['end_time'] - self.chat_session['start_time'] if self.chat_session['start_time'] and self.chat_session['end_time'] else None
        
        print(f"⏰ Chat Duration: {duration.total_seconds():.1f} seconds" if duration else "⏰ Chat Duration: N/A")
        print(f"💬 Messages Exchanged: {len(self.chat_session['messages'])}")
        print(f"🔐 Authentication Attempts: {self.chat_session['authentication_attempts']}")
        print(f"👨‍💼 Human Handovers: {self.chat_session['human_handovers']}")
        
        # Show what we talked about
        if self.chat_session['intents_classified']:
            print(f"\n🎯 Topics Discussed:")
            intent_counts = {}
            for intent in self.chat_session['intents_classified']:
                intent_counts[intent] = intent_counts.get(intent, 0) + 1
            
            for intent, count in intent_counts.items():
                print(f"   • {intent.replace('_', ' ').title()}: {count} times")
        
        # Show what I remembered
        if self.chat_session['context_memory']:
            print(f"\n🧠 What I Remembered:")
            for key, value in self.chat_session['context_memory'].items():
                print(f"   • {key.replace('_', ' ').title()}: {value}")
        
        print(f"\n🎉 Thank you for chatting with me!")
        print(f"💡 I hope I was able to help you effectively!")
        print("="*60)
    
    def start_intuitive_chat(self) -> None:
        """Start the intuitive interactive chat."""
        # Display welcome and demo users
        demo_users = self.display_welcome_and_demo_users()
        
        # Initialize chat session
        self.chat_session['start_time'] = datetime.now()
        
        print(f"\n💬 CHAT SESSION STARTED")
        print(f"⏰ Time: {self.chat_session['start_time'].strftime('%Y-%m-%d %H:%M:%S')}")
        print("-" * 60)
        print("💡 Just ask me your question! I'll show you how I think!")
        print("💡 Type 'help' if you need assistance, 'quit' to exit")
        print("-" * 60)
        
        # Main chat loop
        while True:
            try:
                # Get user input
                message = input("\n💬 You: ").strip()
                
                # Handle special commands
                if message.lower() in ['quit', 'exit', 'q']:
                    self.chat_session['end_time'] = datetime.now()
                    self.display_chat_summary()
                    print("\n👋 Goodbye! Have a great day!")
                    break
                
                elif message.lower() == 'help':
                    self.display_help_system()
                    continue
                
                elif message.lower() == 'demo users':
                    demo_users = self.display_welcome_and_demo_users()
                    continue
                
                elif message.lower() == 'summary':
                    self.display_chat_summary()
                    continue
                
                elif not message.strip():
                    print("💡 Please enter a question or command")
                    continue
                
                # Remember context if user is telling us something
                self.remember_context(message)
                
                # Process message through the system
                print(f"\n🤖 Let me analyze your message...")
                
                # Get system response (this would integrate with your actual system)
                # For now, we'll simulate the response
                result = self._simulate_system_response(message)
                
                # Show TriageAgent thinking
                self.display_triage_agent_thinking(message, result)
                
                # Handle authentication if required
                if result.get('auth_required', False) and not result.get('auth_successful', False):
                    auth_result = self.handle_authentication_flow()
                    
                    if auth_result['success']:
                        result['auth_successful'] = True
                        result['authenticated_user'] = auth_result['authenticated_user']
                        self.chat_session['authenticated_user'] = auth_result['authenticated_user']
                        self.chat_session['authentication_attempts'] += 1
                        
                        # Re-process the original message now that we're authenticated
                        print(f"\n🔄 Now that you're authenticated, let me answer your original question:")
                        result = self._simulate_authenticated_response(message)
                    else:
                        result['auth_successful'] = False
                        result['requires_human_agent'] = True
                        result['human_handover'] = {
                            'reason': 'Authentication failed after multiple attempts',
                            'contact_number': '+91 998877654321',
                            'reference_id': f'REF-{int(time.time())}'
                        }
                        self.chat_session['human_handovers'] += 1
                
                # Display response
                self.display_agent_response(result)
                
                # Update session tracking
                self.chat_session['messages'].append({
                    'user_message': message,
                    'agent_response': result.get('response', ''),
                    'intent': result.get('intent', 'N/A'),
                    'confidence': result.get('confidence', 0),
                    'auth_required': result.get('auth_required', False),
                    'auth_successful': result.get('auth_successful', False),
                    'timestamp': datetime.now()
                })
                
                self.chat_session['intents_classified'].append(result.get('intent', 'N/A'))
                
                if result.get('requires_human_agent', False):
                    self.chat_session['human_handovers'] += 1
                    self.chat_session['agent_decisions'].append(
                        f"Human handover: {result.get('human_handover', {}).get('reason', 'N/A')}"
                    )
                else:
                    self.chat_session['agent_decisions'].append(
                        f"Handled: {result.get('intent', 'N/A')}"
                    )
                
                print("\n" + "="*60)
                
            except KeyboardInterrupt:
                print("\n\n👋 Chat interrupted. Generating summary...")
                self.chat_session['end_time'] = datetime.now()
                self.display_chat_summary()
                break
            except Exception as e:
                print(f"\n❌ Error processing message: {e}")
                print("💡 Please try again or type 'help' for assistance")
        
        # Final cleanup
        self.chat_session['end_time'] = datetime.now()
    
    def _simulate_system_response(self, message: str) -> Dict[str, Any]:
        """Simulate system response for demo purposes."""
        message_lower = message.lower()
        
        # Determine intent based on keywords
        if any(word in message_lower for word in ['order', 'track', 'status', 'shipping']):
            intent = 'order_status'
            auth_required = True
            response = "I'd be happy to help you with your order status! Let me verify your identity first."
        elif any(word in message_lower for word in ['refund', 'return', 'money back']):
            intent = 'refunds'
            auth_required = True
            response = "I can help you with your refund request! Let me verify your identity first."
        elif any(word in message_lower for word in ['troubleshoot', 'problem', 'issue', 'not working']):
            intent = 'troubleshooting'
            auth_required = True
            response = "I'll help you troubleshoot this issue! Let me verify your identity first."
        elif any(word in message_lower for word in ['account', 'login', 'password', 'username']):
            intent = 'account_issues'
            auth_required = True
            response = "I can help you with your account issues! Let me verify your identity first."
        elif any(word in message_lower for word in ['buy', 'purchase', 'product', 'price']):
            intent = 'sales_inquiry'
            auth_required = False
            response = "I'd be happy to help you with product information and pricing! What specific product are you interested in?"
        else:
            intent = 'general_inquiry'
            auth_required = False
            response = "I'd be happy to help you! Could you please provide more details about what you need assistance with?"
        
        return {
            'intent': intent,
            'confidence': 0.85,
            'auth_required': auth_required,
            'auth_successful': False,
            'response': response,
            'follow_up_questions': [
                "Is there anything else I can help you with?",
                "Would you like me to explain anything in more detail?"
            ]
        }
    
    def _simulate_authenticated_response(self, message: str) -> Dict[str, Any]:
        """Simulate authenticated response."""
        message_lower = message.lower()
        
        if any(word in message_lower for word in ['order', 'track', 'status']):
            response = "Great! I can see your order status now. Your order #12345 is currently 'In Transit' and should arrive within 2-3 business days. You can track it using tracking number TRK789456123."
        elif any(word in message_lower for word in ['refund', 'return']):
            response = "I've initiated your refund request. Your refund of ₹2,499 will be processed within 5-7 business days and credited back to your original payment method."
        elif any(word in message_lower for word in ['troubleshoot', 'problem', 'issue']):
            response = "I can help you troubleshoot this issue. Let me guide you through some steps to resolve this problem."
        else:
            response = "Now that you're authenticated, I can provide you with detailed information about your account and orders."
        
        return {
            'intent': 'authenticated_response',
            'confidence': 0.95,
            'auth_required': False,
            'auth_successful': True,
            'response': response,
            'follow_up_questions': [
                "Is there anything else I can help you with?",
                "Would you like me to check anything else in your account?"
            ]
        }
