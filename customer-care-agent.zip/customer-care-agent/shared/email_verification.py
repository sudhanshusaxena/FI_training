#!/usr/bin/env python3
"""
Email Verification System for Customer Care Agent
Handles email token generation, validation, and console-based delivery
"""

import json
import secrets
import os
from datetime import datetime, timedelta
from typing import Dict, Optional, List
from pathlib import Path

class EmailVerificationSystem:
    """Manages email verification tokens and console-based delivery."""
    
    def __init__(self, tokens_file: str = "logs/email_tokens/tokens.json"):
        self.tokens_file = tokens_file
        self.ensure_tokens_directory()
    
    def ensure_tokens_directory(self):
        """Ensure the tokens directory exists."""
        os.makedirs(os.path.dirname(self.tokens_file), exist_ok=True)
    
    def load_tokens(self) -> Dict[str, Dict]:
        """Load existing tokens from file."""
        if os.path.exists(self.tokens_file):
            try:
                with open(self.tokens_file, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                return {}
        return {}
    
    def save_tokens(self, tokens: Dict[str, Dict]):
        """Save tokens to file."""
        with open(self.tokens_file, 'w') as f:
            json.dump(tokens, f, indent=2)
    
    def generate_verification_token(self, user_id: str, email: str) -> str:
        """
        Generate a verification token for email verification.
        
        Args:
            user_id: User ID requesting verification
            email: Email address to verify
            
        Returns:
            Verification token
        """
        token = secrets.token_urlsafe(16)
        expiry_time = datetime.now() + timedelta(minutes=15)
        
        token_data = {
            "token": token,
            "user_id": user_id,
            "email": email,
            "created_at": datetime.now().isoformat(),
            "expires_at": expiry_time.isoformat(),
            "used": False,
            "attempts": 0,
            "max_attempts": 3
        }
        
        # Load existing tokens
        tokens = self.load_tokens()
        
        # Add new token
        tokens[token] = token_data
        
        # Save tokens
        self.save_tokens(tokens)
        
        # Display token in console (simulated email delivery)
        self.display_verification_email(user_id, email, token)
        
        return token
    
    def display_verification_email(self, user_id: str, email: str, token: str):
        """Display verification email in console (simulated email delivery)."""
        print("\n" + "="*80)
        print("📧 EMAIL VERIFICATION NOTIFICATION")
        print("="*80)
        print(f"To: {email}")
        print(f"From: noreply@customer-care-demo.com")
        print(f"Subject: Email Verification Code - Customer Care Agent")
        print("-"*80)
        print("Dear Customer,")
        print()
        print("You have requested email verification for your customer care account.")
        print("Please use the following verification code to complete your authentication:")
        print()
        print(f"🔐 VERIFICATION CODE: {token}")
        print()
        print("This code will expire in 15 minutes.")
        print("If you did not request this verification, please ignore this message.")
        print()
        print("Best regards,")
        print("Customer Care Team")
        print("="*80)
        print(f"💡 For demo purposes, the verification code is: {token}")
        print("="*80 + "\n")
    
    def verify_token(self, token: str) -> Dict[str, any]:
        """
        Verify an email verification token.
        
        Args:
            token: Token to verify
            
        Returns:
            Dictionary with verification result
        """
        tokens = self.load_tokens()
        
        if token not in tokens:
            return {
                "valid": False,
                "error": "Invalid verification token"
            }
        
        token_data = tokens[token]
        
        # Check if token is already used
        if token_data["used"]:
            return {
                "valid": False,
                "error": "Token has already been used"
            }
        
        # Check if token has expired
        expiry_time = datetime.fromisoformat(token_data["expires_at"])
        if datetime.now() > expiry_time:
            return {
                "valid": False,
                "error": "Token has expired"
            }
        
        # Check attempt limit
        if token_data["attempts"] >= token_data["max_attempts"]:
            return {
                "valid": False,
                "error": "Too many verification attempts"
            }
        
        # Increment attempts
        token_data["attempts"] += 1
        
        # Mark as used
        token_data["used"] = True
        token_data["verified_at"] = datetime.now().isoformat()
        
        # Save updated tokens
        tokens[token] = token_data
        self.save_tokens(tokens)
        
        return {
            "valid": True,
            "user_id": token_data["user_id"],
            "email": token_data["email"],
            "verified_at": token_data["verified_at"]
        }
    
    def cleanup_expired_tokens(self):
        """Remove expired tokens from storage."""
        tokens = self.load_tokens()
        current_time = datetime.now()
        
        expired_tokens = []
        for token, data in tokens.items():
            expiry_time = datetime.fromisoformat(data["expires_at"])
            if current_time > expiry_time:
                expired_tokens.append(token)
        
        for token in expired_tokens:
            del tokens[token]
        
        if expired_tokens:
            self.save_tokens(tokens)
            print(f"🧹 Cleaned up {len(expired_tokens)} expired tokens")
    
    def get_user_verification_status(self, user_id: str) -> Dict[str, any]:
        """
        Get verification status for a user.
        
        Args:
            user_id: User ID to check
            
        Returns:
            Dictionary with verification status
        """
        tokens = self.load_tokens()
        
        user_tokens = []
        for token, data in tokens.items():
            if data["user_id"] == user_id:
                user_tokens.append({
                    "token": token,
                    "email": data["email"],
                    "created_at": data["created_at"],
                    "expires_at": data["expires_at"],
                    "used": data["used"],
                    "attempts": data["attempts"]
                })
        
        return {
            "user_id": user_id,
            "total_tokens": len(user_tokens),
            "active_tokens": len([t for t in user_tokens if not t["used"]]),
            "used_tokens": len([t for t in user_tokens if t["used"]]),
            "tokens": user_tokens
        }
    
    def display_verification_summary(self):
        """Display a summary of all verification tokens."""
        tokens = self.load_tokens()
        
        if not tokens:
            print("📊 No verification tokens found")
            return
        
        print("\n📊 EMAIL VERIFICATION SUMMARY")
        print("="*60)
        print(f"Total tokens: {len(tokens)}")
        
        active_count = len([t for t in tokens.values() if not t["used"]])
        used_count = len([t for t in tokens.values() if t["used"]])
        expired_count = len([t for t in tokens.values() 
                           if datetime.now() > datetime.fromisoformat(t["expires_at"])])
        
        print(f"Active tokens: {active_count}")
        print(f"Used tokens: {used_count}")
        print(f"Expired tokens: {expired_count}")
        print("-"*60)
        
        # Show recent tokens
        recent_tokens = sorted(tokens.items(), 
                             key=lambda x: x[1]["created_at"], 
                             reverse=True)[:5]
        
        print("Recent tokens:")
        for token, data in recent_tokens:
            status = "✅ Used" if data["used"] else "⏳ Active" if datetime.now() < datetime.fromisoformat(data["expires_at"]) else "❌ Expired"
            print(f"  {token[:12]}... - {data['user_id']} - {status}")
        
        print("="*60 + "\n")

def test_email_verification():
    """Test the email verification system."""
    print("🧪 Testing Email Verification System...")
    
    # Initialize system
    email_system = EmailVerificationSystem("logs/email_tokens/test_tokens.json")
    
    # Test token generation
    user_id = "u_1001"
    email = "test@example.com"
    token = email_system.generate_verification_token(user_id, email)
    print(f"✅ Token generated: {token}")
    
    # Test token verification
    result = email_system.verify_token(token)
    print(f"✅ Token verification: {'PASSED' if result['valid'] else 'FAILED'}")
    
    # Test invalid token
    invalid_result = email_system.verify_token("invalid_token")
    print(f"✅ Invalid token rejection: {'PASSED' if not invalid_result['valid'] else 'FAILED'}")
    
    # Test user status
    status = email_system.get_user_verification_status(user_id)
    print(f"✅ User status retrieved: {status}")
    
    # Display summary
    email_system.display_verification_summary()
    
    print("🎉 Email verification tests completed!")

if __name__ == "__main__":
    test_email_verification()
