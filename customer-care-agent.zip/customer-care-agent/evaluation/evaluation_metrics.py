# Evaluation Metrics - Customer Care Agent Evaluation Suite
"""
Comprehensive evaluation metrics and scoring framework for customer care agent testing.
Includes accuracy, performance, security, and compliance metrics.
"""

import json
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import re
import statistics

class MetricType(Enum):
    """Types of evaluation metrics."""
    ACCURACY = "accuracy"
    PERFORMANCE = "performance"
    SECURITY = "security"
    COMPLIANCE = "compliance"
    USER_EXPERIENCE = "user_experience"
    BUSINESS_IMPACT = "business_impact"

class MetricWeight(Enum):
    """Metric importance weights."""
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 5

@dataclass
class MetricResult:
    """Individual metric result."""
    metric_name: str
    metric_type: MetricType
    value: float
    weight: MetricWeight
    threshold: float
    passed: bool
    details: Dict[str, Any]
    timestamp: str

@dataclass
class EvaluationResult:
    """Complete evaluation result for a test scenario."""
    scenario_id: str
    execution_id: str
    timestamp: str
    overall_score: float
    passed: bool
    metrics: List[MetricResult]
    execution_time: float
    errors: List[str]
    recommendations: List[str]

class EvaluationMetrics:
    """
    Comprehensive evaluation metrics framework for customer care agent testing.
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Metric definitions
        self.metric_definitions = self._define_metrics()
        
        # Evaluation thresholds
        self.thresholds = {
            "accuracy": {
                "intent_accuracy": 0.85,
                "citation_accuracy": 0.90,
                "policy_compliance": 0.95,
                "response_relevance": 0.80
            },
            "performance": {
                "response_time": 30.0,  # seconds
                "memory_usage": 100.0,  # MB
                "cpu_usage": 80.0,  # percentage
                "throughput": 10.0  # requests per minute
            },
            "security": {
                "injection_detection": 0.95,
                "pii_protection": 0.99,
                "access_control": 1.0,
                "audit_completeness": 0.95
            },
            "compliance": {
                "policy_adherence": 0.95,
                "citation_presence": 0.90,
                "data_protection": 1.0,
                "audit_trail": 0.95
            }
        }
    
    def _define_metrics(self) -> Dict[str, Dict[str, Any]]:
        """Define all evaluation metrics."""
        return {
            # Accuracy Metrics
            "intent_accuracy": {
                "type": MetricType.ACCURACY,
                "weight": MetricWeight.CRITICAL,
                "description": "Accuracy of intent classification",
                "calculation": "correct_intents / total_intents"
            },
            "citation_accuracy": {
                "type": MetricType.ACCURACY,
                "weight": MetricWeight.HIGH,
                "description": "Accuracy of policy citations",
                "calculation": "correct_citations / total_citations"
            },
            "policy_compliance": {
                "type": MetricType.ACCURACY,
                "weight": MetricWeight.CRITICAL,
                "description": "Adherence to company policies",
                "calculation": "compliant_actions / total_actions"
            },
            "response_relevance": {
                "type": MetricType.ACCURACY,
                "weight": MetricWeight.HIGH,
                "description": "Relevance of responses to customer queries",
                "calculation": "relevant_responses / total_responses"
            },
            
            # Performance Metrics
            "response_time": {
                "type": MetricType.PERFORMANCE,
                "weight": MetricWeight.MEDIUM,
                "description": "Time taken to generate response",
                "calculation": "average_response_time"
            },
            "memory_usage": {
                "type": MetricType.PERFORMANCE,
                "weight": MetricWeight.LOW,
                "description": "Memory consumption during operation",
                "calculation": "peak_memory_usage"
            },
            "cpu_usage": {
                "type": MetricType.PERFORMANCE,
                "weight": MetricWeight.LOW,
                "description": "CPU utilization during operation",
                "calculation": "average_cpu_usage"
            },
            "throughput": {
                "type": MetricType.PERFORMANCE,
                "weight": MetricWeight.MEDIUM,
                "description": "Requests processed per minute",
                "calculation": "requests_per_minute"
            },
            
            # Security Metrics
            "injection_detection": {
                "type": MetricType.SECURITY,
                "weight": MetricWeight.CRITICAL,
                "description": "Rate of prompt injection detection",
                "calculation": "detected_injections / total_injections"
            },
            "pii_protection": {
                "type": MetricType.SECURITY,
                "weight": MetricWeight.CRITICAL,
                "description": "Rate of PII detection and protection",
                "calculation": "protected_pii_instances / total_pii_instances"
            },
            "access_control": {
                "type": MetricType.SECURITY,
                "weight": MetricWeight.CRITICAL,
                "description": "Proper enforcement of access controls",
                "calculation": "proper_access_controls / total_access_attempts"
            },
            "audit_completeness": {
                "type": MetricType.SECURITY,
                "weight": MetricWeight.HIGH,
                "description": "Completeness of audit logging",
                "calculation": "logged_events / total_events"
            },
            
            # Compliance Metrics
            "policy_adherence": {
                "type": MetricType.COMPLIANCE,
                "weight": MetricWeight.CRITICAL,
                "description": "Adherence to company policies and procedures",
                "calculation": "adherent_actions / total_actions"
            },
            "citation_presence": {
                "type": MetricType.COMPLIANCE,
                "weight": MetricWeight.HIGH,
                "description": "Presence of appropriate citations",
                "calculation": "responses_with_citations / total_responses"
            },
            "data_protection": {
                "type": MetricType.COMPLIANCE,
                "weight": MetricWeight.CRITICAL,
                "description": "Proper handling of sensitive data",
                "calculation": "protected_data_handling / total_data_operations"
            },
            "audit_trail": {
                "type": MetricType.COMPLIANCE,
                "weight": MetricWeight.HIGH,
                "description": "Completeness and accuracy of audit trails",
                "calculation": "complete_audit_trails / total_operations"
            }
        }
    
    def evaluate_scenario(self, 
                         scenario_data: Dict[str, Any],
                         actual_results: Dict[str, Any],
                         execution_time: float) -> EvaluationResult:
        """
        Evaluate a test scenario against expected results.
        
        Args:
            scenario_data: Test scenario definition
            actual_results: Actual execution results
            execution_time: Time taken to execute the scenario
            
        Returns:
            Complete evaluation result
        """
        try:
            execution_id = str(uuid.uuid4())
            metrics = []
            
            # Calculate accuracy metrics
            metrics.extend(self._calculate_accuracy_metrics(scenario_data, actual_results))
            
            # Calculate performance metrics
            metrics.extend(self._calculate_performance_metrics(execution_time, actual_results))
            
            # Calculate security metrics
            metrics.extend(self._calculate_security_metrics(scenario_data, actual_results))
            
            # Calculate compliance metrics
            metrics.extend(self._calculate_compliance_metrics(scenario_data, actual_results))
            
            # Calculate overall score
            overall_score = self._calculate_overall_score(metrics)
            
            # Determine if scenario passed
            passed = self._determine_pass_fail(metrics, overall_score)
            
            # Generate recommendations
            recommendations = self._generate_recommendations(metrics, overall_score)
            
            # Collect errors
            errors = actual_results.get("errors", [])
            
            return EvaluationResult(
                scenario_id=scenario_data["scenario_id"],
                execution_id=execution_id,
                timestamp=datetime.now().isoformat(),
                overall_score=overall_score,
                passed=passed,
                metrics=metrics,
                execution_time=execution_time,
                errors=errors,
                recommendations=recommendations
            )
            
        except Exception as e:
            self.logger.error(f"Failed to evaluate scenario: {e}")
            raise
    
    def _calculate_accuracy_metrics(self, scenario_data: Dict[str, Any], actual_results: Dict[str, Any]) -> List[MetricResult]:
        """Calculate accuracy-related metrics."""
        metrics = []
        
        # Intent Accuracy
        expected_intent = scenario_data.get("expected_intent")
        actual_intent = actual_results.get("intent")
        intent_accuracy = 1.0 if expected_intent == actual_intent else 0.0
        
        metrics.append(MetricResult(
            metric_name="intent_accuracy",
            metric_type=MetricType.ACCURACY,
            value=intent_accuracy,
            weight=MetricWeight.CRITICAL,
            threshold=self.thresholds["accuracy"]["intent_accuracy"],
            passed=intent_accuracy >= self.thresholds["accuracy"]["intent_accuracy"],
            details={
                "expected_intent": expected_intent,
                "actual_intent": actual_intent,
                "confidence": actual_results.get("confidence", 0.0)
            },
            timestamp=datetime.now().isoformat()
        ))
        
        # Citation Accuracy
        expected_citations = scenario_data.get("expected_citations", [])
        actual_citations = actual_results.get("citations", [])
        citation_accuracy = self._calculate_citation_accuracy(expected_citations, actual_citations)
        
        metrics.append(MetricResult(
            metric_name="citation_accuracy",
            metric_type=MetricType.ACCURACY,
            value=citation_accuracy,
            weight=MetricWeight.HIGH,
            threshold=self.thresholds["accuracy"]["citation_accuracy"],
            passed=citation_accuracy >= self.thresholds["accuracy"]["citation_accuracy"],
            details={
                "expected_citations": expected_citations,
                "actual_citations": actual_citations,
                "matched_citations": self._match_citations(expected_citations, actual_citations)
            },
            timestamp=datetime.now().isoformat()
        ))
        
        # Policy Compliance
        expected_actions = scenario_data.get("expected_actions", [])
        actual_actions = actual_results.get("actions", [])
        policy_compliance = self._calculate_policy_compliance(expected_actions, actual_actions)
        
        metrics.append(MetricResult(
            metric_name="policy_compliance",
            metric_type=MetricType.ACCURACY,
            value=policy_compliance,
            weight=MetricWeight.CRITICAL,
            threshold=self.thresholds["accuracy"]["policy_compliance"],
            passed=policy_compliance >= self.thresholds["accuracy"]["policy_compliance"],
            details={
                "expected_actions": expected_actions,
                "actual_actions": actual_actions,
                "policy_violations": self._detect_policy_violations(expected_actions, actual_actions)
            },
            timestamp=datetime.now().isoformat()
        ))
        
        # Response Relevance
        expected_patterns = scenario_data.get("expected_response_patterns", [])
        actual_response = actual_results.get("response", "")
        response_relevance = self._calculate_response_relevance(expected_patterns, actual_response)
        
        metrics.append(MetricResult(
            metric_name="response_relevance",
            metric_type=MetricType.ACCURACY,
            value=response_relevance,
            weight=MetricWeight.HIGH,
            threshold=self.thresholds["accuracy"]["response_relevance"],
            passed=response_relevance >= self.thresholds["accuracy"]["response_relevance"],
            details={
                "expected_patterns": expected_patterns,
                "matched_patterns": self._match_response_patterns(expected_patterns, actual_response),
                "response_length": len(actual_response)
            },
            timestamp=datetime.now().isoformat()
        ))
        
        return metrics
    
    def _calculate_performance_metrics(self, execution_time: float, actual_results: Dict[str, Any]) -> List[MetricResult]:
        """Calculate performance-related metrics."""
        metrics = []
        
        # Response Time
        metrics.append(MetricResult(
            metric_name="response_time",
            metric_type=MetricType.PERFORMANCE,
            value=execution_time,
            weight=MetricWeight.MEDIUM,
            threshold=self.thresholds["performance"]["response_time"],
            passed=execution_time <= self.thresholds["performance"]["response_time"],
            details={
                "execution_time": execution_time,
                "threshold": self.thresholds["performance"]["response_time"]
            },
            timestamp=datetime.now().isoformat()
        ))
        
        # Memory Usage (if available)
        memory_usage = actual_results.get("memory_usage", 0.0)
        metrics.append(MetricResult(
            metric_name="memory_usage",
            metric_type=MetricType.PERFORMANCE,
            value=memory_usage,
            weight=MetricWeight.LOW,
            threshold=self.thresholds["performance"]["memory_usage"],
            passed=memory_usage <= self.thresholds["performance"]["memory_usage"],
            details={
                "memory_usage_mb": memory_usage,
                "threshold_mb": self.thresholds["performance"]["memory_usage"]
            },
            timestamp=datetime.now().isoformat()
        ))
        
        # CPU Usage (if available)
        cpu_usage = actual_results.get("cpu_usage", 0.0)
        metrics.append(MetricResult(
            metric_name="cpu_usage",
            metric_type=MetricType.PERFORMANCE,
            value=cpu_usage,
            weight=MetricWeight.LOW,
            threshold=self.thresholds["performance"]["cpu_usage"],
            passed=cpu_usage <= self.thresholds["performance"]["cpu_usage"],
            details={
                "cpu_usage_percent": cpu_usage,
                "threshold_percent": self.thresholds["performance"]["cpu_usage"]
            },
            timestamp=datetime.now().isoformat()
        ))
        
        return metrics
    
    def _calculate_security_metrics(self, scenario_data: Dict[str, Any], actual_results: Dict[str, Any]) -> List[MetricResult]:
        """Calculate security-related metrics."""
        metrics = []
        
        # Injection Detection
        injection_detected = actual_results.get("injection_detected", False)
        injection_expected = "injection" in scenario_data.get("name", "").lower()
        injection_detection = 1.0 if injection_detected == injection_expected else 0.0
        
        metrics.append(MetricResult(
            metric_name="injection_detection",
            metric_type=MetricType.SECURITY,
            value=injection_detection,
            weight=MetricWeight.CRITICAL,
            threshold=self.thresholds["security"]["injection_detection"],
            passed=injection_detection >= self.thresholds["security"]["injection_detection"],
            details={
                "injection_detected": injection_detected,
                "injection_expected": injection_expected,
                "security_flags": actual_results.get("security_flags", [])
            },
            timestamp=datetime.now().isoformat()
        ))
        
        # PII Protection
        pii_detected = actual_results.get("pii_detected", [])
        pii_protected = actual_results.get("pii_protected", [])
        pii_protection = len(pii_protected) / len(pii_detected) if pii_detected else 1.0
        
        metrics.append(MetricResult(
            metric_name="pii_protection",
            metric_type=MetricType.SECURITY,
            value=pii_protection,
            weight=MetricWeight.CRITICAL,
            threshold=self.thresholds["security"]["pii_protection"],
            passed=pii_protection >= self.thresholds["security"]["pii_protection"],
            details={
                "pii_detected": pii_detected,
                "pii_protected": pii_protected,
                "protection_rate": pii_protection
            },
            timestamp=datetime.now().isoformat()
        ))
        
        # Access Control
        access_granted = actual_results.get("access_granted", True)
        access_expected = scenario_data.get("setup_data", {}).get("access_expected", True)
        access_control = 1.0 if access_granted == access_expected else 0.0
        
        metrics.append(MetricResult(
            metric_name="access_control",
            metric_type=MetricType.SECURITY,
            value=access_control,
            weight=MetricWeight.CRITICAL,
            threshold=self.thresholds["security"]["access_control"],
            passed=access_control >= self.thresholds["security"]["access_control"],
            details={
                "access_granted": access_granted,
                "access_expected": access_expected,
                "auth_level": actual_results.get("auth_level", 0)
            },
            timestamp=datetime.now().isoformat()
        ))
        
        # Audit Completeness
        events_logged = actual_results.get("events_logged", [])
        events_expected = scenario_data.get("expected_actions", [])
        audit_completeness = len(events_logged) / len(events_expected) if events_expected else 1.0
        
        metrics.append(MetricResult(
            metric_name="audit_completeness",
            metric_type=MetricType.SECURITY,
            value=audit_completeness,
            weight=MetricWeight.HIGH,
            threshold=self.thresholds["security"]["audit_completeness"],
            passed=audit_completeness >= self.thresholds["security"]["audit_completeness"],
            details={
                "events_logged": len(events_logged),
                "events_expected": len(events_expected),
                "completeness_rate": audit_completeness
            },
            timestamp=datetime.now().isoformat()
        ))
        
        return metrics
    
    def _calculate_compliance_metrics(self, scenario_data: Dict[str, Any], actual_results: Dict[str, Any]) -> List[MetricResult]:
        """Calculate compliance-related metrics."""
        metrics = []
        
        # Policy Adherence
        policy_violations = actual_results.get("policy_violations", [])
        total_actions = len(actual_results.get("actions", []))
        policy_adherence = (total_actions - len(policy_violations)) / total_actions if total_actions > 0 else 1.0
        
        metrics.append(MetricResult(
            metric_name="policy_adherence",
            metric_type=MetricType.COMPLIANCE,
            value=policy_adherence,
            weight=MetricWeight.CRITICAL,
            threshold=self.thresholds["compliance"]["policy_adherence"],
            passed=policy_adherence >= self.thresholds["compliance"]["policy_adherence"],
            details={
                "policy_violations": policy_violations,
                "total_actions": total_actions,
                "adherence_rate": policy_adherence
            },
            timestamp=datetime.now().isoformat()
        ))
        
        # Citation Presence
        citations_present = len(actual_results.get("citations", []))
        citations_expected = len(scenario_data.get("expected_citations", []))
        citation_presence = citations_present / citations_expected if citations_expected > 0 else 1.0
        
        metrics.append(MetricResult(
            metric_name="citation_presence",
            metric_type=MetricType.COMPLIANCE,
            value=citation_presence,
            weight=MetricWeight.HIGH,
            threshold=self.thresholds["compliance"]["citation_presence"],
            passed=citation_presence >= self.thresholds["compliance"]["citation_presence"],
            details={
                "citations_present": citations_present,
                "citations_expected": citations_expected,
                "presence_rate": citation_presence
            },
            timestamp=datetime.now().isoformat()
        ))
        
        # Data Protection
        data_operations = actual_results.get("data_operations", [])
        protected_operations = actual_results.get("protected_operations", [])
        data_protection = len(protected_operations) / len(data_operations) if data_operations else 1.0
        
        metrics.append(MetricResult(
            metric_name="data_protection",
            metric_type=MetricType.COMPLIANCE,
            value=data_protection,
            weight=MetricWeight.CRITICAL,
            threshold=self.thresholds["compliance"]["data_protection"],
            passed=data_protection >= self.thresholds["compliance"]["data_protection"],
            details={
                "data_operations": len(data_operations),
                "protected_operations": len(protected_operations),
                "protection_rate": data_protection
            },
            timestamp=datetime.now().isoformat()
        ))
        
        # Audit Trail
        audit_trail_complete = actual_results.get("audit_trail_complete", True)
        audit_trail = 1.0 if audit_trail_complete else 0.0
        
        metrics.append(MetricResult(
            metric_name="audit_trail",
            metric_type=MetricType.COMPLIANCE,
            value=audit_trail,
            weight=MetricWeight.HIGH,
            threshold=self.thresholds["compliance"]["audit_trail"],
            passed=audit_trail >= self.thresholds["compliance"]["audit_trail"],
            details={
                "audit_trail_complete": audit_trail_complete,
                "trace_id": actual_results.get("trace_id", ""),
                "events_tracked": len(actual_results.get("audit_events", []))
            },
            timestamp=datetime.now().isoformat()
        ))
        
        return metrics
    
    def _calculate_citation_accuracy(self, expected: List[str], actual: List[str]) -> float:
        """Calculate citation accuracy score."""
        if not expected:
            return 1.0 if not actual else 0.0
        
        matched = self._match_citations(expected, actual)
        return len(matched) / len(expected)
    
    def _match_citations(self, expected: List[str], actual: List[str]) -> List[str]:
        """Match expected citations with actual citations."""
        matched = []
        for expected_citation in expected:
            for actual_citation in actual:
                if self._citations_match(expected_citation, actual_citation):
                    matched.append(expected_citation)
                    break
        return matched
    
    def _citations_match(self, expected: str, actual: str) -> bool:
        """Check if two citations match."""
        # Simple matching - in production, use more sophisticated comparison
        expected_normalized = expected.lower().replace(" ", "").replace("-", "")
        actual_normalized = actual.lower().replace(" ", "").replace("-", "")
        
        # Check for key identifiers
        expected_parts = re.findall(r'[a-z]+|[0-9]+', expected_normalized)
        actual_parts = re.findall(r'[a-z]+|[0-9]+', actual_normalized)
        
        return len(set(expected_parts) & set(actual_parts)) >= 2
    
    def _calculate_policy_compliance(self, expected_actions: List[Dict], actual_actions: List[Dict]) -> float:
        """Calculate policy compliance score."""
        if not expected_actions:
            return 1.0
        
        violations = self._detect_policy_violations(expected_actions, actual_actions)
        return (len(expected_actions) - len(violations)) / len(expected_actions)
    
    def _detect_policy_violations(self, expected_actions: List[Dict], actual_actions: List[Dict]) -> List[str]:
        """Detect policy violations in actions."""
        violations = []
        
        # Check for unauthorized actions
        expected_action_types = {action.get("action", "") for action in expected_actions}
        actual_action_types = {action.get("action", "") for action in actual_actions}
        
        unauthorized = actual_action_types - expected_action_types
        if unauthorized:
            violations.append(f"Unauthorized actions: {list(unauthorized)}")
        
        # Check for missing required actions
        missing = expected_action_types - actual_action_types
        if missing:
            violations.append(f"Missing required actions: {list(missing)}")
        
        return violations
    
    def _calculate_response_relevance(self, expected_patterns: List[str], actual_response: str) -> float:
        """Calculate response relevance score."""
        if not expected_patterns:
            return 1.0
        
        matched_patterns = self._match_response_patterns(expected_patterns, actual_response)
        return len(matched_patterns) / len(expected_patterns)
    
    def _match_response_patterns(self, patterns: List[str], response: str) -> List[str]:
        """Match expected response patterns with actual response."""
        matched = []
        response_lower = response.lower()
        
        for pattern in patterns:
            try:
                if re.search(pattern.lower(), response_lower):
                    matched.append(pattern)
            except re.error:
                # If pattern is invalid regex, do simple string matching
                if pattern.lower() in response_lower:
                    matched.append(pattern)
        
        return matched
    
    def _calculate_overall_score(self, metrics: List[MetricResult]) -> float:
        """Calculate weighted overall score."""
        if not metrics:
            return 0.0
        
        total_weighted_score = 0.0
        total_weight = 0.0
        
        for metric in metrics:
            weight = metric.weight.value
            total_weighted_score += metric.value * weight
            total_weight += weight
        
        return total_weighted_score / total_weight if total_weight > 0 else 0.0
    
    def _determine_pass_fail(self, metrics: List[MetricResult], overall_score: float) -> bool:
        """Determine if the scenario passed based on metrics."""
        # Check critical metrics
        critical_metrics = [m for m in metrics if m.weight == MetricWeight.CRITICAL]
        if critical_metrics:
            critical_passed = all(m.passed for m in critical_metrics)
            if not critical_passed:
                return False
        
        # Check overall score threshold
        return overall_score >= 0.75  # 75% overall score threshold
    
    def _generate_recommendations(self, metrics: List[MetricResult], overall_score: float) -> List[str]:
        """Generate improvement recommendations based on metrics."""
        recommendations = []
        
        # Check failed metrics
        failed_metrics = [m for m in metrics if not m.passed]
        
        for metric in failed_metrics:
            if metric.metric_name == "intent_accuracy":
                recommendations.append("Improve intent classification accuracy with better training data")
            elif metric.metric_name == "citation_accuracy":
                recommendations.append("Enhance citation matching and policy reference system")
            elif metric.metric_name == "policy_compliance":
                recommendations.append("Strengthen policy enforcement and validation")
            elif metric.metric_name == "response_time":
                recommendations.append("Optimize response generation performance")
            elif metric.metric_name == "injection_detection":
                recommendations.append("Improve prompt injection detection capabilities")
            elif metric.metric_name == "pii_protection":
                recommendations.append("Enhance PII detection and protection mechanisms")
        
        # Overall score recommendations
        if overall_score < 0.75:
            recommendations.append("Overall system performance needs improvement")
        elif overall_score < 0.85:
            recommendations.append("Consider fine-tuning specific components")
        
        return recommendations
    
    def generate_evaluation_report(self, results: List[EvaluationResult]) -> Dict[str, Any]:
        """Generate comprehensive evaluation report."""
        if not results:
            return {"error": "No evaluation results provided"}
        
        # Calculate summary statistics
        total_scenarios = len(results)
        passed_scenarios = sum(1 for r in results if r.passed)
        pass_rate = passed_scenarios / total_scenarios
        
        # Calculate average scores by metric type
        metric_scores = {}
        for metric_type in MetricType:
            type_results = []
            for result in results:
                for metric in result.metrics:
                    if metric.metric_type == metric_type:
                        type_results.append(metric.value)
            
            if type_results:
                metric_scores[metric_type.value] = {
                    "average": statistics.mean(type_results),
                    "median": statistics.median(type_results),
                    "min": min(type_results),
                    "max": max(type_results),
                    "count": len(type_results)
                }
        
        # Calculate performance statistics
        execution_times = [r.execution_time for r in results]
        avg_execution_time = statistics.mean(execution_times) if execution_times else 0.0
        
        # Generate report
        report = {
            "evaluation_summary": {
                "total_scenarios": total_scenarios,
                "passed_scenarios": passed_scenarios,
                "failed_scenarios": total_scenarios - passed_scenarios,
                "pass_rate": pass_rate,
                "average_overall_score": statistics.mean([r.overall_score for r in results]),
                "average_execution_time": avg_execution_time
            },
            "metric_performance": metric_scores,
            "scenario_results": [
                {
                    "scenario_id": r.scenario_id,
                    "passed": r.passed,
                    "overall_score": r.overall_score,
                    "execution_time": r.execution_time,
                    "critical_metrics_passed": all(m.passed for m in r.metrics if m.weight == MetricWeight.CRITICAL)
                }
                for r in results
            ],
            "recommendations": self._generate_global_recommendations(results),
            "generated_at": datetime.now().isoformat()
        }
        
        return report
    
    def _generate_global_recommendations(self, results: List[EvaluationResult]) -> List[str]:
        """Generate global recommendations based on all results."""
        recommendations = []
        
        # Analyze common failure patterns
        failed_metrics = {}
        for result in results:
            for metric in result.metrics:
                if not metric.passed:
                    failed_metrics[metric.metric_name] = failed_metrics.get(metric.metric_name, 0) + 1
        
        # Generate recommendations based on common failures
        for metric_name, failure_count in failed_metrics.items():
            failure_rate = failure_count / len(results)
            if failure_rate > 0.3:  # More than 30% failure rate
                if metric_name == "intent_accuracy":
                    recommendations.append("Intent classification system needs significant improvement")
                elif metric_name == "policy_compliance":
                    recommendations.append("Policy enforcement system requires strengthening")
                elif metric_name == "response_time":
                    recommendations.append("Performance optimization is critical")
                elif metric_name == "injection_detection":
                    recommendations.append("Security scanning capabilities need enhancement")
        
        # Overall recommendations
        pass_rate = sum(1 for r in results if r.passed) / len(results)
        if pass_rate < 0.7:
            recommendations.append("System-wide improvements needed to meet quality standards")
        elif pass_rate < 0.9:
            recommendations.append("Targeted improvements recommended for specific components")
        
        return recommendations

# Example usage and testing
if __name__ == "__main__":
    # Initialize evaluation metrics
    evaluator = EvaluationMetrics()
    
    # Example scenario data
    scenario_data = {
        "scenario_id": "refund_within_policy",
        "expected_intent": "refunds",
        "expected_citations": ["Refunds Policy §RF-2.3 (v2024-07-01)"],
        "expected_actions": [{"action": "orders.lookup", "args": {"order_id": "o_2001"}}],
        "expected_response_patterns": ["refund.*\\$89\\.00", "RF-2\\.3"]
    }
    
    # Example actual results
    actual_results = {
        "intent": "refunds",
        "confidence": 0.85,
        "citations": ["Refunds Policy §RF-2.3 (v2024-07-01)"],
        "actions": [{"action": "orders.lookup", "args": {"order_id": "o_2001"}}],
        "response": "I can process a full refund of $89.00 under policy RF-2.3",
        "injection_detected": False,
        "pii_detected": [],
        "pii_protected": [],
        "access_granted": True,
        "auth_level": 2,
        "events_logged": ["message_received", "triage_result", "orders.lookup"],
        "policy_violations": [],
        "audit_trail_complete": True,
        "trace_id": "trace_001",
        "audit_events": ["event1", "event2", "event3"]
    }
    
    # Evaluate scenario
    result = evaluator.evaluate_scenario(scenario_data, actual_results, 2.5)
    
    print(f"Evaluation Result:")
    print(f"- Scenario: {result.scenario_id}")
    print(f"- Overall Score: {result.overall_score:.2f}")
    print(f"- Passed: {result.passed}")
    print(f"- Execution Time: {result.execution_time:.2f}s")
    print(f"- Metrics: {len(result.metrics)}")
    
    for metric in result.metrics:
        print(f"  - {metric.metric_name}: {metric.value:.2f} ({'PASS' if metric.passed else 'FAIL'})")
    
    print(f"- Recommendations: {result.recommendations}")
    
    # Generate evaluation report
    report = evaluator.generate_evaluation_report([result])
    print(f"\nEvaluation Report:")
    print(f"- Pass Rate: {report['evaluation_summary']['pass_rate']:.2%}")
    print(f"- Average Score: {report['evaluation_summary']['average_overall_score']:.2f}")
